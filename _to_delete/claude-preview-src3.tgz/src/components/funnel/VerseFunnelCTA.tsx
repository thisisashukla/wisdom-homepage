'use client'

import { useEffect, useState } from 'react'
import { appStoreUrl, detectPlatform, type Platform } from '@/lib/app'
import { trackLinkClick } from '@/lib/mixpanel'
import './funnel-cta.css'

/**
 * Sitewide bridge from reading to the funnel (replaces the old Scripture AI
 * waitlist block on verse, chapter and blog pages). Everyone gets "Find my
 * verse" (the homepage hero); iPhone visitors also get the App Store.
 */

type Props = {
  variant: 'verse' | 'chapter' | 'inline'
  locale?: 'en' | 'hi'
  verse?: { chapter: number; verse: number } | null
  chapter?: { number: number; enName?: string; hiName?: string } | null
  pageName?: string
}

const COPY = {
  en: {
    eyebrow: 'Wisdom',
    verseHead: (c: number, v: number) => `Is ${c}.${v} about you? Find the verse for what you're going through.`,
    head: "Find the Gita verse for what you're going through.",
    sub: "Tap what's on your mind and read the verse that speaks to it, in Sanskrit and plain English.",
    cta: 'Find my verse',
    ios: 'On iPhone, the app walks seven days with it, read aloud. Week 1 is free.',
    iosCta: 'Get the app',
  },
  hi: {
    eyebrow: 'Wisdom · आपके जीवन के लिए गीता',
    verseHead: (c: number, v: number) => `क्या ${c}.${v} आपके बारे में है? अपनी स्थिति के लिए श्लोक पाएं।`,
    head: 'आज आप जिस बात से गुज़र रहे हैं, उसके लिए गीता का श्लोक पाएं।',
    sub: 'बताइए आप कैसा महसूस कर रहे हैं। आपके जीवन के लिए चुना गया एक श्लोक, संस्कृत और अर्थ के साथ।',
    cta: 'मेरा श्लोक दिखाएं →',
    ios: 'iPhone पर: 7 दिन की ऑडियो योजना और लॉक स्क्रीन पर आज का श्लोक।',
    iosCta: 'ऐप पाएं',
  },
}

export default function VerseFunnelCTA({ variant, locale = 'en', verse, chapter, pageName }: Props) {
  const [platform, setPlatform] = useState<Platform>('desktop')
  useEffect(() => setPlatform(detectPlatform()), [])
  const t = COPY[locale]
  const where = `${variant}${verse ? `_${verse.chapter}_${verse.verse}` : ''}${chapter ? `_ch${chapter.number}` : ''}`
  const page = pageName ?? `gita_${locale}_${where}`
  const href = `/?ref=${encodeURIComponent(where)}#your-verse`
  const appHref = appStoreUrl(`web_${variant}_${locale}`)
  const head = variant === 'verse' && verse ? t.verseHead(verse.chapter, verse.verse) : t.head

  return (
    <aside className={`vfc vfc-${variant}`} aria-label={head}>
      <div className="vfc-eyebrow">{t.eyebrow}</div>
      <p className="vfc-head">{head}</p>
      {variant !== 'inline' && <p className="vfc-sub">{t.sub}</p>}
      <div className="vfc-actions">
        <a className="vfc-btn" href={href} onClick={() => trackLinkClick(page, `funnel_cta_${where}`, href)}>
          {t.cta}
        </a>
        {platform === 'ios' && (
          <a
            className="vfc-btn vfc-btn-ghost"
            href={appHref}
            target="_blank"
            rel="noopener"
            onClick={() => trackLinkClick(page, `funnel_cta_app_${where}`, appHref)}
          >
            {t.iosCta}
          </a>
        )}
      </div>
      {platform === 'ios' && variant !== 'inline' && <p className="vfc-fine">{t.ios}</p>}
    </aside>
  )
}

