# Gate 2: copy

Status: run once on Ankur's instruction. 05-copy.md is the source of truth, and the implementation must match it (checked with scripts/copy_check.py). Points to confirm:
1. H1: "The Bhagavad Gita verse for what you're going through." (Alternative #2, "Can't stop overthinking?…", scored higher but narrows the page to one pain.)
2. The three-notes section shows real, unedited backend output for three test notes, labelled as such.
3. Price language: "Your bank tells you before every charge." This relies on RBI e-mandate pre-debit notices; confirm Razorpay subscriptions are set up as an e-mandate.
4. Tele-MANAS 14416 appears in the FAQ and the footer.
