# 04 · Structure (homepage)

## Awareness
Traffic is mixed: Google searches for "bhagavad gita online" (product-aware for the Gita, unaware of Wisdom), Instagram and Reddit links (problem-aware, already in the knot), and internal verse pages (reading). The hero has to work for problem-aware visitors without losing readers. So: lead with the problem and the finder, and keep "read online" one line away.

Behaviour constraint (Mixpanel): only 13% of visitors scroll past a quarter of the page. The hero must carry the whole argument. Everything below it is for the minority who keep reading, and for SEO.

## Sections
| id | Purpose (one) | SB7 beat | Pain / objection answered | Keyword | Proof | CTA | Max words | Visual |
|---|---|---|---|---|---|---|---|---|
| hero | Let them name the knot and get a verse now | Character + problem + direct CTA | Pain 1–5 ("which verse is for this?") | bhagavad gita online (sub) | The verse itself | Find my verse | 60 + chips | Existing Krishna art |
| three-notes | Show the tuning is real, not canned | Guide: authority | AI slop; "generic quotes" | — | Unedited backend output for 2.47 | No | 120 + 3 cards | Notes and replies as cards (real text) |
| seven-days | Explain what happens after the verse, and what it costs | Plan: process + agreement | Paywall and autopay trap; "what next?" | bhagavad gita app | Store screenshot; real price | Yes (split by device) | 140 | store-2 screenshot |
| sources | Answer "whose Gita is this?" | Guide: empathy + authority | ISKCON bias; preachy; AI mangling | bhagavad gita in english/hindi | Commentators named; one real review | No | 120 | None |
| gita-for | Route problem-aware visitors to the deep pages | Problem (named) | Pains 1–5 by name | bhagavad gita on overthinking, etc. | Verse counts | Links | 30 + 14 tiles | None |
| today | Give the low-commitment daily return | Transitional CTA | "a little bit of the Gita every day" | gita verse of the day | Real audio | Read in full | 30 | Existing player |
| library | Serve readers and keep the reader keywords | Transitional CTA | Language; "where do I start" | bhagavad gita online / in hindi | 18 chapters | Start at 1.1 | 60 | Chapter tiles (existing) |
| faq | Close the remaining objections, and carry PAA queries | Plan: agreement | Free? Hindi? Translation? Cost? Therapy? | 6 PAA questions | — | No | 260 | None |
| final | One more chance to act, with the stakes | Failure vs success + direct CTA | Pain 1 | — | — | Find my verse | 40 | None |

## Deletion test
- **Proof bar** (old): nothing is left unanswered if removed; the hero eyebrow carries "700 verses · Sanskrit, Hindi, English". **Deleted.**
- **"Three lives" (invented lines)**: replaced by three-notes with real output. Without it, the AI-slop objection has no answer.
- **"Wisdom for iPhone" three-card block**: merged into seven-days. Its only job was the plan and the offer.
- **Blog row**: kept inside library; it carries the best-translation query, which is the top non-India entry page.
- **sources**: removing it leaves the ISKCON and AI objections unanswered. **Kept.**

Total body budget: about 860 words plus FAQ answers.

## Quality bar
- Top 5 pains: hero chips and the gita-for tiles. Top objections: three-notes (AI), sources (sect, preachy), seven-days (paywall), faq (free, Hindi, therapy).
- The CTA "Find my verse" appears in the hero and the final section.
