"""p10: every "Create my plan" goes to the App Store on iPhone and to /start elsewhere; no sign-in on the homepage.
Idempotent. Usage: python3 p10_cta_rewire.py <frontend src dir>"""
import os, re, sys
S = sys.argv[1]
P = lambda *a: os.path.join(S, *a)

def edit(path, pairs):
    s = open(path, encoding='utf-8').read()
    o = s
    for old, new in pairs:
        if new in s and old not in s:
            continue
        assert old in s, f'{path}: missing {old[:80]!r}'
        s = s.replace(old, new)
    if s != o:
        open(path, 'w', encoding='utf-8').write(s)
        print('edited', path)

# Homepage
edit(P('app', 'page.tsx'), [
    ("import YourVerse from '@/components/funnel/YourVerse'\n", "import HeroPlanCTA from '@/components/funnel/HeroPlanCTA'\nimport CreatePlanLink from '@/components/funnel/CreatePlanLink'\n"),
    ('<YourVerse source="hero" pageName="Home" />', '<HeroPlanCTA />'),
    ("<p>Pick what&apos;s weighing on you. Your first verse is ready in 30 seconds.</p>", "<p>A few questions, about two minutes. Your first verse is free.</p>"),
    ('<a href="#your-verse" className="btn-read-gita btn-read-gita-primary" data-mp-location="final_cta_find_verse">Create my 7-day Gita plan</a>',
     '<CreatePlanLink className="btn-read-gita btn-read-gita-primary" campaign="web_final_band" location="final_cta_create_plan">Create my 7-day Gita plan</CreatePlanLink>'),
])

# Plan preview: the tab's situation travels to /start (?s=) or the App Store on iPhone
pp = P('components', 'funnel', 'PlanPreview.tsx')
s = open(pp, encoding='utf-8').read()
if 'CreatePlanLink' not in s:
    s = s.replace("import { trackEvent } from '@/lib/mixpanel'", "import { trackEvent } from '@/lib/mixpanel'\nimport CreatePlanLink from './CreatePlanLink'")
    s = s.replace(""" * makes for it, then create your own. The button hands the situation to the
 * hero widget (YourVerse listens for `yv:choose`), so one tap there starts it.
 * Without JS the link still lands on /?s=<situation>#your-verse.""", """ * makes for it, then create your own. The button opens the onboarding with the
 * tab's situation (/start?s=…), or the App Store on iPhone.""")
    a = s.index('  const create = (e: React.MouseEvent<HTMLAnchorElement>) => {')
    b = s.index('  return (', a)
    s = s[:a] + s[b:]
    a = s.index('        <a\n          href={`/?s=${plan.situation}#your-verse`}')
    b = s.index('        </a>', a) + len('        </a>')
    s = s[:a] + """        <CreatePlanLink
          className="btn-read-gita btn-read-gita-primary"
          campaign="web_plan_preview"
          refTag={`plan_preview_${plan.id}`}
          situation={plan.situation}
          location={`home_plan_preview_create_${plan.id}`}
          pageName={pageName}
        >
          Create my 7-day Gita plan
        </CreatePlanLink>""" + s[b:]
    open(pp, 'w', encoding='utf-8').write(s)
    print('edited', pp)

# Devices: the web panel's button opens /start (App Store if it's an iPhone after all)
dp = P('components', 'funnel', 'DevicePlans.tsx')
s = open(dp, encoding='utf-8').read()
if 'CreatePlanLink' not in s:
    s = s.replace("import { trackEvent, trackLinkClick } from '@/lib/mixpanel'", "import { trackEvent, trackLinkClick } from '@/lib/mixpanel'\nimport CreatePlanLink from './CreatePlanLink'")
    a = s.index('  const createPlan = (e: React.MouseEvent<HTMLAnchorElement>) => {')
    b = s.index('  return (', a)
    s = s[:a] + s[b:]
    a = s.index('          <a\n            href="/#your-verse"')
    b = s.index('          </a>', a) + len('          </a>')
    s = s[:a] + """          <CreatePlanLink className="btn-read-gita btn-read-gita-primary" campaign="web_home_devices" location="home_devices_create_plan" pageName={pageName}>
            Create my 7-day Gita plan
          </CreatePlanLink>""" + s[b:]
    open(dp, 'w', encoding='utf-8').write(s)
    print('edited', dp)
edit(dp, [("Write what&apos;s going on in your own words. The seven verses are chosen for it.",
           "Answer a few questions and say what&apos;s going on in your own words. The seven verses are chosen for it.")])

# Nav button and mobile menu
edit(P('components', 'funnel', 'GetAppButton.tsx'), [
    ("import { appStoreUrl, detectPlatform, type Platform } from '@/lib/app'", "import { appStoreUrl, detectPlatform, startUrl, type Platform } from '@/lib/app'"),
    ("/** Nav CTA: iPhone → App Store; everyone else → the \"your verse\" hero. */", "/** Nav CTA: iPhone → App Store; everyone else → /start (the app's onboarding on the web). */"),
    ("const href = ios ? appStoreUrl('web_nav') : '/#your-verse'", "const href = ios ? appStoreUrl('web_nav') : startUrl({ ref: 'nav' })"),
])
edit(P('components', 'MobileNavToggle.tsx'), [("{ href: '/#your-verse', label: 'Create my 7-day Gita plan' },", "{ href: '/start?ref=menu', label: 'Create my 7-day Gita plan' },")])

# Sitewide block on verse, chapter and blog pages
edit(P('components', 'funnel', 'VerseFunnelCTA.tsx'), [
    ("import { appStoreUrl, detectPlatform, type Platform } from '@/lib/app'", "import { appStoreUrl, detectPlatform, startUrl, type Platform } from '@/lib/app'"),
    ("  const href = `/?ref=${encodeURIComponent(where)}#your-verse`\n  const appHref = appStoreUrl(`web_${variant}_${locale}`)",
     "  const appHref = appStoreUrl(`web_${variant}_${locale}`)\n  const ios = platform === 'ios'\n  const href = ios ? appHref : startUrl({ ref: where })"),
    ("""        <a className="vfc-btn" href={href} onClick={() => trackLinkClick(page, `funnel_cta_${where}`, href)}>
          {t.cta}
        </a>
        {platform === 'ios' && (
          <a
            className="vfc-btn vfc-btn-ghost"
            href={appHref}
            target="_blank"
            rel="noopener"
            onClick={() => trackLinkClick(page, `funnel_cta_app_${where}`, appHref)}
          >
            {t.iosCta}
          </a>
        )}""",
     """        <a
          className="vfc-btn"
          href={href}
          target={ios ? '_blank' : undefined}
          rel={ios ? 'noopener' : undefined}
          onClick={() => trackLinkClick(page, ios ? `funnel_cta_app_${where}` : `funnel_cta_${where}`, href)}
        >
          {t.cta}
        </a>"""),
])

# /app page
edit(P('app', 'app', 'page.tsx'), [
    ('<a href="/#your-verse" className="btn-hero-secondary" data-mp-location="app_hero_try_web">', '<a href="/start?ref=app_page" className="btn-hero-secondary" data-mp-location="app_hero_try_web">'),
    ('<a href="/#your-verse" style={{ color: \'var(--gold-light)\', fontWeight: 600 }} data-mp-location="app_final_android">', '<a href="/start?ref=app_page_final" style={{ color: \'var(--gold-light)\', fontWeight: 600 }} data-mp-location="app_final_android">'),
])

# /gita-for pages: the inline widget (with its Google gate) becomes the same button
gi = P('app', 'gita-for', 'page.tsx')
edit(gi, [
    ("import YourVerse from '@/components/funnel/YourVerse'", "import HeroPlanCTA from '@/components/funnel/HeroPlanCTA'"),
    ('<YourVerse source="gita-for-index" pageName="Gita For Index" />', '<div id="your-verse"><HeroPlanCTA campaign="web_gita_for_index" location="gita_for_index_create_plan" pageName="Gita For Index" /></div>'),
])
gs = P('app', 'gita-for', '[slug]', 'page.tsx')
s = open(gs, encoding='utf-8').read()
if 'HeroPlanCTA' not in s:
    s = s.replace("import YourVerse from '@/components/funnel/YourVerse'", "import HeroPlanCTA from '@/components/funnel/HeroPlanCTA'")
    a = s.index('            <YourVerse')
    a = s.rindex('\n', 0, a) + 1
    b = s.index('/>', a) + 2
    block = s[a:b]
    sit = re.search(r'initialSituation=\{([^}]*)\}', block)
    s = s[:a] + ('            <div id="your-verse"><HeroPlanCTA campaign={`web_gita_for_${page.slug}`} location={`gita_for_${page.slug}_create_plan`} pageName="Gita For"'
                 + (f' situation={{{sit.group(1)}}}' if sit else '') + ' /></div>') + s[b:]
    open(gs, 'w', encoding='utf-8').write(s)
    print('edited', gs)
print('p10 done')

# Mobile menu: the plan item follows the same rule
mn = P('components', 'MobileNavToggle.tsx')
s = open(mn, encoding='utf-8').read()
if 'detectPlatform' not in s:
    s = s.replace("import { useEffect, useState } from 'react'", "import { useEffect, useState } from 'react'\nimport { appStoreUrl, detectPlatform } from '@/lib/app'")
    s = s.replace("  const [open, setOpen] = useState(false)\n", "  const [open, setOpen] = useState(false)\n  const [ios, setIos] = useState(false)\n  useEffect(() => setIos(detectPlatform() === 'ios'), [])\n", 1)
    s = s.replace("""              <a href={l.href} onClick={() => setOpen(false)}>""", """              <a
                href={ios && l.href.startsWith('/start') ? appStoreUrl('web_menu') : l.href}
                target={ios && l.href.startsWith('/start') ? '_blank' : undefined}
                rel={ios && l.href.startsWith('/start') ? 'noopener' : undefined}
                onClick={() => setOpen(false)}
              >""")
    open(mn, 'w', encoding='utf-8').write(s)
    print('edited', mn)
