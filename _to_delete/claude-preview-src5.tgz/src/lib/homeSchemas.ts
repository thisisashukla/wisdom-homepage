// Structured data for the homepage — the free Bhagavad Gita web reader.
// The MobileApplication schema has moved to appSchemas.ts (used on /app).
const schemas = [
  {
    '@context': 'https://schema.org',
    '@graph': [
      {
        '@type': 'WebSite',
        name: 'Wisdom — Bhagavad Gita Online',
        url: 'https://wisdomquotes.in',
        description:
          'Read the complete Bhagavad Gita online — all 18 chapters, 700 verses in Sanskrit, Hindi and English. Free. No login. One verse per page with simple meaning and detailed commentary.',
        publisher: {
          '@type': 'Organization',
          name: 'Wisdom',
          url: 'https://wisdomquotes.in',
          logo: 'https://wisdomquotes.in/assets/new-light-logo.webp',
        },
        potentialAction: {
          '@type': 'SearchAction',
          target: 'https://wisdomquotes.in/gita?q={search_term_string}',
          'query-input': 'required name=search_term_string',
        },
      },
      {
        '@type': 'Book',
        name: 'Bhagavad Gita',
        alternateName: ['Bhagavat Gita', 'Bhagwat Geeta', 'भगवद्गीता'],
        author: { '@type': 'Person', name: 'Vyasa' },
        inLanguage: ['sa', 'hi', 'en'],
        numberOfPages: 700,
        bookFormat: 'https://schema.org/EBook',
        isAccessibleForFree: true,
        url: 'https://wisdomquotes.in/gita',
        description:
          'The Bhagavad Gita — 18 chapters, 700 verses spoken by Krishna to Arjuna on the battlefield of Kurukshetra. Available here in Sanskrit Devanagari, Hindi anuvad, and English translation with detailed commentary. Free to read online.',
      },
      {
        '@type': 'Organization',
        name: 'Wisdom',
        url: 'https://wisdomquotes.in',
        logo: 'https://wisdomquotes.in/assets/new-light-logo.webp',
        description:
          'Wisdom tunes the Bhagavad Gita to your life. The website has every verse in Sanskrit, Hindi and English with meaning and commentary, and picks a verse for how you feel today. The iPhone app builds a 7-day audio plan around your situation.',
        sameAs: [
          'https://apps.apple.com/app/id6747684125',
          'https://www.instagram.com/wisdomquoteapp/',
          'https://wisdomquotes.in',
        ],
      },
      {
        '@type': 'FAQPage',
        mainEntity: [
          {
            '@type': 'Question',
            name: 'Can I read the Bhagavad Gita online for free?',
            acceptedAnswer: { '@type': 'Answer', text: 'Yes. All 18 chapters and 700 verses, in Sanskrit, Hindi and English with meaning and commentary, are free on wisdomquotes.in. No login and no ads.' },
          },
          {
            '@type': 'Question',
            name: 'How does the Wisdom reading plan work?',
            acceptedAnswer: { '@type': 'Answer', text: "You tell us what's on your mind in one tap. Wisdom picks seven verses for it from a library of 1,743 across the Gita, Ramayana, Mahabharata and Upanishads: one a day, each with the Sanskrit and what it means for you. Day 1 is free. On iPhone the rest of week 1 is free in the app; on Android and computers it is ₹89 a week." },
          },
          {
            '@type': 'Question',
            name: 'Which Bhagavad Gita translation does Wisdom use? Is it ISKCON?',
            acceptedAnswer: { '@type': 'Answer', text: "No. The Sanskrit and Hindi come from traditional sources. English is Wisdom's own, checked against Shankara, Ramanuja and modern acharyas rather than one tradition. The Methodology page explains how." },
          },
          {
            '@type': 'Question',
            name: 'Is the Bhagavad Gita available in Hindi?',
            acceptedAnswer: { '@type': 'Answer', text: 'Yes. Every verse has a Hindi-first page at wisdomquotes.in/hi/gita with the shloka, Hindi anuvad and vistrit arth.' },
          },
          {
            '@type': 'Question',
            name: 'Which verse of the Bhagavad Gita should I read first?',
            acceptedAnswer: { '@type': 'Answer', text: "If something is on your mind, start with the verse Wisdom picks for it. If you want the whole text, begin at 1.1; Arjuna's despair in chapter 1 is where Krishna's teaching starts. The most quoted verse is 2.47." },
          },
          {
            '@type': 'Question',
            name: 'Is there a Bhagavad Gita app with audio?',
            acceptedAnswer: { '@type': 'Answer', text: 'Yes. Wisdom for iPhone builds a 7-day plan around your situation, one verse a day read aloud with the Sanskrit woven in. Week 1 is free. On Android or a computer the same plan is ₹89 a week on wisdomquotes.in.' },
          },
        ],
      },
    ],
  },
]
export default schemas
