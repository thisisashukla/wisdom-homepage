import type { Metadata } from 'next'
import BlogTracker from '@/components/BlogTracker'
import FeedbackWidget from '@/components/FeedbackWidget'
import ShlokaCard from '@/components/gita/ShlokaCard'
import VerseFunnelCTA from '@/components/funnel/VerseFunnelCTA'
import { appStoreUrl } from '@/lib/app'

export const metadata: Metadata = {
  title: "Krishna's Three Paths, Karma, Jnana, Bhakti | Bhagavad Gita's Three Yogas Explained",
  description: "Krishna lays out three paths in the Bhagavad Gita, Karma Yoga (action), Jnana Yoga (knowledge), Bhakti Yoga (devotion). Each suits a different temperament; all three converge on the same supreme reality. A deeply researched reading with verses 2.47, 3.30, 4.34, 7.17, 9.22, 12.12, 13.24, 18.66, parallels from Tulsidas's Ramcharitmanas, and modern psychology.",
  keywords: "krishna three paths, karma yoga, jnana yoga, bhakti yoga, bhagavad gita three paths, three yogas of bhagavad gita, paths of yoga, karm pradhan bisva kari rakha, hoihi soi jo rama rachi rakha, ramcharitmanas karma, tulsidas surrender, gita on devotion, gita on knowledge, gita on action, which path is mine bhagavad gita, krishna teachings on yoga, jnana karma bhakti difference, sarva dharman parityajya, nimitta matra arjuna, nishkama karma, jnani bhakta gita 7.17, kshetra kshetrajna, gita and mental health, ACT therapy bhagavad gita, attachment science bhakti, witness consciousness gita, why three paths in gita, which yoga is best",
  authors: [{ name: 'Ankur Shukla', url: 'https://wisdomquotes.in/about' }],
  creator: 'Ankur Shukla',
  publisher: 'Wisdom',
  category: 'Hindu Philosophy',
  openGraph: {
    title: "Krishna's Three Paths, Karma, Jnana, Bhakti | The Three Yogas of the Bhagavad Gita",
    description: "Krishna lays out three paths in the Bhagavad Gita, Action, Wisdom, Devotion, each shaped for a different temperament. A deep reading, grounded in the verses, with Tulsidas and modern psychology.",
    type: 'article',
    url: "https://wisdomquotes.in/blogs/krishna-three-paths-bhagavad-gita",
    siteName: 'Wisdom',
    locale: 'en_IN',
    publishedTime: '2026-05-24T00:00:00.000Z',
    modifiedTime: '2026-05-24T00:00:00.000Z',
    authors: ['https://wisdomquotes.in/about'],
    section: 'Bhagavad Gita',
    tags: ['Bhagavad Gita', 'Karma Yoga', 'Jnana Yoga', 'Bhakti Yoga', 'Three Paths', 'Krishna', 'Tulsidas', 'Hindu Philosophy', 'Mental Health'],
    images: [
      { url: 'https://wisdomquotes.in/assets/3paths.webp', width: 1536, height: 1024, alt: "Krishna's three paths, Wisdom, Action, Devotion, converging on Krishna as the supreme reality" },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: "Krishna's Three Paths, Karma, Jnana, Bhakti | The Three Yogas of the Bhagavad Gita",
    description: "Krishna lays out three paths in the Bhagavad Gita, Action, Wisdom, Devotion. A deep reading grounded in the verses, with Tulsidas and modern psychology.",
    images: ['https://wisdomquotes.in/assets/3paths.webp'],
    creator: '@thisisashukla',
    site: '@sansearchapp',
  },
  alternates: {
    canonical: "https://wisdomquotes.in/blogs/krishna-three-paths-bhagavad-gita",
    languages: {
      'en': "https://wisdomquotes.in/blogs/krishna-three-paths-bhagavad-gita",
      'en-IN': "https://wisdomquotes.in/blogs/krishna-three-paths-bhagavad-gita",
      'x-default': "https://wisdomquotes.in/blogs/krishna-three-paths-bhagavad-gita",
    },
  },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, 'max-image-preview': 'large', 'max-snippet': -1, 'max-video-preview': -1 },
  },
  other: {
    "article:published_time": "2026-05-24T00:00:00.000Z",
    "article:modified_time": "2026-05-24T00:00:00.000Z",
    "article:author": "Ankur Shukla",
    "article:section": "Bhagavad Gita",
  },
}

const pageCSS = `
        :root {
            --maroon: #3d0c0c;
            --maroon-mid: #5c1a1a;
            --gold: #c8881e;
            --gold-light: #f5c96a;
            --gold-pale: #fdf3dc;
            --gold-border: #e8c97a;
            --gold-dim: rgba(200,136,30,0.15);
            --text: #f5e8cc;
            --text-dim: rgba(245,232,204,0.65);
            --text-dimmer: rgba(245,232,204,0.35);
            --muted-2: rgba(245,232,204,0.35);
            --border: rgba(200,136,30,0.2);
            --bg: #120505;
            --bg-warm: #190707;
            --bg-alt: #0f0404;
            --bg-card: rgba(255,255,255,0.04);
            --bg-card-hover: rgba(255,255,255,0.07);
            --max: 780px;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            background: var(--bg);
            color: var(--text);
            font-family: 'Inter', sans-serif;
            line-height: 1.7;
            font-size: 16px;
        }

        .breadcrumb { background: var(--bg-alt); border-bottom: 1px solid var(--border); }
        .breadcrumb-inner {
            max-width: 1100px;
            margin: 0 auto;
            padding: 10px 28px;
            font-size: 12px;
            color: var(--text-dimmer);
            display: flex;
            gap: 8px;
            align-items: center;
        }
        .breadcrumb-inner a { color: var(--text-dimmer); transition: color 0.15s; text-decoration: none; }
        .breadcrumb-inner a:hover { color: var(--gold-light); }
        .bc-sep { opacity: 0.4; }

        .article-hero {
            background: var(--bg-warm);
            padding: 64px 28px 56px;
            border-bottom: 1px solid var(--border);
            position: relative;
            overflow: hidden;
        }
        .article-hero::before {
            content: "त्रिमार्ग";
            position: absolute;
            right: -10px;
            bottom: -30px;
            font-family: "Noto Sans Devanagari", serif;
            font-size: 180px;
            color: rgba(200, 136, 30, 0.04);
            line-height: 1;
            pointer-events: none;
            user-select: none;
        }
        .article-hero-inner { max-width: 1100px; margin: 0 auto; position: relative; z-index: 2; }
        .chapter-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: rgba(200, 136, 30, 0.1);
            border: 1px solid rgba(200, 136, 30, 0.28);
            color: var(--gold-light);
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 0.12em;
            text-transform: uppercase;
            padding: 5px 14px;
            border-radius: 100px;
            margin-bottom: 20px;
        }
        .chapter-badge-dot {
            width: 5px; height: 5px; border-radius: 50%;
            background: var(--gold); box-shadow: 0 0 6px var(--gold); flex-shrink: 0;
        }
        h1.article-title {
            font-family: "Playfair Display", Georgia, serif;
            font-size: clamp(28px, 4vw, 48px);
            font-weight: 700;
            color: var(--gold-light);
            line-height: 1.15;
            letter-spacing: -0.5px;
            margin-bottom: 14px;
        }
        h1.article-title em { font-style: italic; color: #fff; }
        .article-subtitle {
            font-size: 17px;
            color: var(--text-dim);
            font-weight: 300;
            margin-bottom: 32px;
            line-height: 1.65;
            max-width: 680px;
        }
        .article-meta { display: flex; align-items: center; gap: 16px; flex-wrap: wrap; }
        .meta-item { font-size: 12px; color: var(--text-dimmer); letter-spacing: 0.04em; }
        .meta-sep { color: var(--border); }

        .chapter-image {
            margin: 32px 0 36px;
            border-radius: 14px;
            overflow: hidden;
            border: 1px solid var(--border);
            box-shadow: 0 4px 32px rgba(0,0,0,0.4);
        }
        .chapter-image img {
            width: 100%; height: auto; display: block; object-fit: cover;
        }
        .chapter-image figcaption {
            padding: 10px 18px;
            background: var(--bg-card);
            font-size: 11.5px;
            color: var(--text-dimmer);
            letter-spacing: 0.04em;
            font-style: italic;
            border-top: 1px solid var(--border);
        }

        .content {
            max-width: var(--max);
            margin: 0 auto;
            padding: 0 2rem 4rem;
        }

        .lead {
            font-size: 1.1rem;
            color: var(--text-dim);
            margin-bottom: 2rem;
            line-height: 1.8;
        }

        h2 {
            font-family: 'Playfair Display', serif;
            font-size: 1.8rem;
            font-weight: 700;
            margin: 2.5rem 0 1.5rem 0;
            color: var(--gold);
            border-bottom: 2px solid var(--gold-dim);
            padding-bottom: 0.75rem;
        }

        h3 {
            font-family: 'Playfair Display', serif;
            font-size: 1.3rem;
            font-weight: 600;
            margin: 1.5rem 0 1rem 0;
            color: var(--text);
        }

        p { margin-bottom: 1.5rem; color: var(--text-dim); }

        .path-header {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin: 3rem 0 1.5rem;
        }
        .path-badge {
            display: inline-flex;
            align-items: center;
            background: rgba(200,136,30,0.12);
            border: 1px solid rgba(200,136,30,0.35);
            color: var(--gold-light);
            font-size: 11px;
            font-weight: 600;
            letter-spacing: 0.14em;
            text-transform: uppercase;
            padding: 5px 14px;
            border-radius: 20px;
            white-space: nowrap;
        }
        .path-title {
            font-family: 'Playfair Display', serif;
            font-size: 1.6rem;
            font-weight: 700;
            color: var(--gold);
            border-bottom: 2px solid var(--gold-dim);
            padding-bottom: 0.75rem;
            flex: 1;
            margin: 0;
        }

        .pull-quote {
            border-left: 4px solid var(--gold);
            padding-left: 2rem;
            margin: 2.5rem 0;
            font-size: 1.15rem;
            color: var(--gold-light);
            font-style: italic;
            line-height: 1.8;
        }

        .highlight-box {
            background: var(--gold-dim);
            border: 1px solid var(--gold-border);
            padding: 1.5rem;
            border-radius: 8px;
            margin: 2rem 0;
        }
        .highlight-box h3 { color: var(--gold); margin-top: 0; }
        .highlight-box p { color: var(--text); margin-bottom: 0.75rem; }
        .highlight-box p:last-child { margin-bottom: 0; }

        .tulsidas-card {
            background: linear-gradient(160deg, rgba(60,18,18,0.45) 0%, rgba(26,6,6,0.35) 100%);
            border: 1px solid rgba(200,136,30,0.25);
            border-radius: 10px;
            padding: 1.75rem 2rem;
            margin: 2rem 0;
        }
        .tulsidas-card .source-label {
            font-size: 0.75rem;
            color: var(--gold);
            text-transform: uppercase;
            font-weight: 600;
            letter-spacing: 0.12em;
            margin-bottom: 0.85rem;
        }
        .tulsidas-card .awadhi {
            font-family: 'Noto Sans Devanagari', sans-serif;
            font-size: 1.05rem;
            color: var(--gold-light);
            line-height: 1.8;
            margin-bottom: 0.85rem;
        }
        .tulsidas-card .roman {
            font-size: 0.9rem;
            font-style: italic;
            color: var(--text-dimmer);
            line-height: 1.6;
            margin-bottom: 0.85rem;
        }
        .tulsidas-card .gloss {
            color: var(--text);
            line-height: 1.7;
            font-size: 0.97rem;
        }

        .gita-index {
            background: var(--bg-card);
            border: 1px solid var(--gold-dim);
            border-radius: 8px;
            padding: 1.5rem 2rem;
            margin: 2rem 0;
        }
        .gita-index h3 {
            color: var(--gold);
            margin-top: 0;
            margin-bottom: 1rem;
            font-size: 1rem;
            text-transform: uppercase;
            letter-spacing: 0.08em;
        }
        .gita-index ol { list-style: none; padding: 0; counter-reset: gita-counter; }
        .gita-index ol li {
            counter-increment: gita-counter;
            display: flex;
            align-items: baseline;
            gap: 0.75rem;
            padding: 0.5rem 0;
            border-bottom: 1px solid var(--border);
            color: var(--text-dim);
            font-size: 0.95rem;
        }
        .gita-index ol li:last-child { border-bottom: none; }
        .gita-index ol li::before {
            content: counter(gita-counter);
            color: var(--gold);
            font-weight: 700;
            font-size: 0.8rem;
            min-width: 1.2rem;
        }
        .gita-index ol li strong { color: var(--text); }

        /* Path comparison grid */
        .paths-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 1rem;
            margin: 2rem 0;
        }
        .path-card {
            background: var(--bg-card);
            border: 1px solid var(--gold-dim);
            border-radius: 10px;
            padding: 1.25rem 1.1rem;
        }
        .path-card .glyph {
            font-family: "Noto Sans Devanagari", serif;
            font-size: 1.5rem;
            color: var(--gold);
            margin-bottom: 0.5rem;
        }
        .path-card .name {
            font-family: 'Playfair Display', serif;
            font-size: 1.05rem;
            font-weight: 700;
            color: var(--gold-light);
            margin-bottom: 0.35rem;
        }
        .path-card .sub {
            font-size: 0.8rem;
            color: var(--text-dimmer);
            letter-spacing: 0.05em;
            text-transform: uppercase;
            margin-bottom: 0.85rem;
        }
        .path-card .body { font-size: 0.92rem; color: var(--text-dim); line-height: 1.55; }
        @media (max-width: 720px) {
            .paths-grid { grid-template-columns: 1fr; }
        }

        /* FAQ */
        .faq-section { max-width: var(--max); margin: 3rem auto; padding: 0 2rem; }
        .faq-item { margin-bottom: 2rem; border-bottom: 1px solid var(--border); padding-bottom: 2rem; }
        .faq-item:last-child { border-bottom: none; }
        .faq-item strong { color: var(--gold-light); font-size: 1.05rem; }
        .faq-item p { margin-top: 0.75rem; }

        /* App CTA */
        .app-cta {
          background: linear-gradient(160deg, #2d0a0a 0%, #1a0606 100%);
          border: 1px solid rgba(200, 136, 30, 0.25);
          border-top: 3px solid var(--gold);
          border-radius: 20px;
          padding: 44px 48px 40px;
          margin: 48px 0 60px;
          text-align: center;
          position: relative;
          overflow: hidden;
        }
        .app-cta::before {
          content: "त्रिमार्ग";
          position: absolute;
          top: -14px;
          right: -8px;
          font-family: "Noto Sans Devanagari", sans-serif;
          font-size: 110px;
          color: rgba(200, 136, 30, 0.05);
          line-height: 1;
          pointer-events: none;
          user-select: none;
        }
        .app-cta-eyebrow {
          display: inline-flex;
          align-items: center;
          background: rgba(200, 136, 30, 0.12);
          border: 1px solid rgba(200, 136, 30, 0.35);
          color: var(--gold-light);
          font-size: 11px;
          font-weight: 600;
          letter-spacing: 0.14em;
          text-transform: uppercase;
          padding: 5px 14px;
          border-radius: 20px;
          margin-bottom: 20px;
        }
        .app-cta-headline {
          font-family: "Playfair Display", serif;
          font-size: clamp(22px, 3vw, 30px);
          font-weight: 700;
          color: var(--text);
          line-height: 1.25;
          margin-bottom: 14px;
        }
        .app-cta-desc {
          font-size: 15px;
          color: var(--text-dim);
          line-height: 1.7;
          max-width: 520px;
          margin: 0 auto 22px;
        }
        .app-cta-features {
          display: flex;
          gap: 6px 18px;
          justify-content: center;
          flex-wrap: wrap;
          margin-bottom: 28px;
        }
        .app-cta-features span { font-size: 13px; color: var(--gold-light); opacity: 0.85; }
        .app-cta-btn {
          display: inline-flex;
          align-items: center;
          gap: 10px;
          background: var(--gold);
          color: #120505;
          text-decoration: none;
          padding: 15px 34px;
          border-radius: 12px;
          font-size: 16px;
          font-weight: 700;
          letter-spacing: -0.01em;
          transition: all 0.2s;
          box-shadow: 0 4px 22px rgba(200, 136, 30, 0.3);
        }
        .app-cta-btn:hover {
          background: var(--gold-light);
          transform: translateY(-2px);
          box-shadow: 0 8px 32px rgba(200, 136, 30, 0.5);
        }
        .app-cta-sub {
          font-size: 12px;
          color: rgba(245, 232, 204, 0.35);
          margin-top: 14px;
          letter-spacing: 0.04em;
        }

        footer {
            background: var(--bg-warm);
            border-top: 1px solid var(--border);
            padding: 3rem 2rem;
            text-align: center;
            color: var(--text-dimmer);
            margin-top: 4rem;
        }
        footer a { color: var(--gold); text-decoration: none; }
        footer a:hover { text-decoration: underline; }

        @media (max-width: 768px) {
            .article-hero { padding: 44px 20px 40px; }
            h2 { font-size: 1.5rem; }
            .path-title { font-size: 1.35rem; }
            .app-cta { padding: 32px 24px 28px; }
            .tulsidas-card { padding: 1.35rem 1.4rem; }
        }
`

const schemas = [
  {
    "@context": "https://schema.org",
    "@type": ["Article", "LearningResource"],
    "@id": "https://wisdomquotes.in/blogs/krishna-three-paths-bhagavad-gita#article",
    "headline": "Krishna's Three Paths — Karma, Jnana, Bhakti and Why the Gita Offers Three Roads to the Same Reality",
    "alternativeHeadline": "The Three Yogas of the Bhagavad Gita — Action, Knowledge, Devotion",
    "description": "In the Bhagavad Gita, Krishna lays out three paths — Karma Yoga (action), Jnana Yoga (knowledge), and Bhakti Yoga (devotion). Each is shaped for a different temperament. All three converge on the same supreme reality. A deep reading grounded in the verses, with parallels from Tulsidas's Ramcharitmanas and modern psychology.",
    "image": {
      "@type": "ImageObject",
      "url": "https://wisdomquotes.in/assets/3paths.webp",
      "width": 1536,
      "height": 1024,
      "caption": "Three paths: Wisdom, Action, Devotion, converging on Krishna as the supreme reality"
    },
    "datePublished": "2026-05-24",
    "dateModified": "2026-05-24",
    "author": {
      "@type": "Person",
      "name": "Ankur Shukla",
      "url": "https://wisdomquotes.in/about",
      "sameAs": ["https://www.linkedin.com/in/thisisashukla/", "https://x.com/thisisashukla"]
    },
    "publisher": {
      "@type": "Organization",
      "name": "Wisdom",
      "url": "https://wisdomquotes.in",
      "logo": {
        "@type": "ImageObject",
        "url": "https://wisdomquotes.in/assets/new-light-logo.webp"
      }
    },
    "mainEntityOfPage": {
      "@type": "WebPage",
      "@id": "https://wisdomquotes.in/blogs/krishna-three-paths-bhagavad-gita"
    },
    "about": [
      { "@type": "Book", "name": "Bhagavad Gita", "author": { "@type": "Person", "name": "Ved Vyasa" }, "url": "https://wisdomquotes.in/gita" },
      { "@type": "Book", "name": "Ramcharitmanas", "author": { "@type": "Person", "name": "Goswami Tulsidas" }, "url": "https://en.wikipedia.org/wiki/Ramcharitmanas" },
      { "@type": "Person", "name": "Krishna", "url": "https://en.wikipedia.org/wiki/Krishna" },
      { "@type": "Person", "name": "Arjuna", "url": "https://en.wikipedia.org/wiki/Arjuna" },
      { "@type": "Person", "name": "Tulsidas", "url": "https://en.wikipedia.org/wiki/Tulsidas" },
      { "@type": "Thing", "name": "Karma Yoga", "url": "https://en.wikipedia.org/wiki/Karma_yoga" },
      { "@type": "Thing", "name": "Jnana Yoga", "url": "https://en.wikipedia.org/wiki/Jnana_yoga" },
      { "@type": "Thing", "name": "Bhakti Yoga", "url": "https://en.wikipedia.org/wiki/Bhakti_yoga" }
    ],
    "mentions": [
      { "@type": "CreativeWork", "name": "Bhagavad Gita 2.47", "url": "https://wisdomquotes.in/gita/chapter/2#verse-47" },
      { "@type": "CreativeWork", "name": "Bhagavad Gita 3.19", "url": "https://wisdomquotes.in/gita/chapter/3#verse-19" },
      { "@type": "CreativeWork", "name": "Bhagavad Gita 3.30", "url": "https://wisdomquotes.in/gita/chapter/3#verse-30" },
      { "@type": "CreativeWork", "name": "Bhagavad Gita 4.11", "url": "https://wisdomquotes.in/gita/chapter/4#verse-11" },
      { "@type": "CreativeWork", "name": "Bhagavad Gita 4.34", "url": "https://wisdomquotes.in/gita/chapter/4#verse-34" },
      { "@type": "CreativeWork", "name": "Bhagavad Gita 4.38", "url": "https://wisdomquotes.in/gita/chapter/4#verse-38" },
      { "@type": "CreativeWork", "name": "Bhagavad Gita 7.16", "url": "https://wisdomquotes.in/gita/chapter/7#verse-16" },
      { "@type": "CreativeWork", "name": "Bhagavad Gita 7.17", "url": "https://wisdomquotes.in/gita/chapter/7#verse-17" },
      { "@type": "CreativeWork", "name": "Bhagavad Gita 9.22", "url": "https://wisdomquotes.in/gita/chapter/9#verse-22" },
      { "@type": "CreativeWork", "name": "Bhagavad Gita 9.26", "url": "https://wisdomquotes.in/gita/chapter/9#verse-26" },
      { "@type": "CreativeWork", "name": "Bhagavad Gita 11.33", "url": "https://wisdomquotes.in/gita/chapter/11#verse-33" },
      { "@type": "CreativeWork", "name": "Bhagavad Gita 12.5", "url": "https://wisdomquotes.in/gita/chapter/12#verse-5" },
      { "@type": "CreativeWork", "name": "Bhagavad Gita 12.8", "url": "https://wisdomquotes.in/gita/chapter/12#verse-8" },
      { "@type": "CreativeWork", "name": "Bhagavad Gita 12.12", "url": "https://wisdomquotes.in/gita/chapter/12#verse-12" },
      { "@type": "CreativeWork", "name": "Bhagavad Gita 13.24", "url": "https://wisdomquotes.in/gita/chapter/13#verse-24" },
      { "@type": "CreativeWork", "name": "Bhagavad Gita 18.66", "url": "https://wisdomquotes.in/gita/chapter/18#verse-66" }
    ],
    "keywords": "krishna three paths, karma yoga, jnana yoga, bhakti yoga, bhagavad gita three paths, three yogas of bhagavad gita, karm pradhan bisva kari rakha, hoihi soi jo rama rachi rakha, ramcharitmanas tulsidas, sarva dharman parityajya, nimitta matra, nishkama karma, jnani bhakta, kshetra kshetrajna, gita and mental health, ACT therapy, attachment science, witness consciousness, which yoga is best",
    "articleSection": "Bhagavad Gita · Topic Guide · The Three Yogas",
    "wordCount": 4200,
    "timeRequired": "PT18M",
    "inLanguage": "en",
    "isAccessibleForFree": true,
    "learningResourceType": "Article",
    "educationalLevel": "General",
    "audience": { "@type": "Audience", "audienceType": "Seekers, students of Hindu philosophy, mental-health-aware readers" },
    "speakable": {
      "@type": "SpeakableSpecification",
      "cssSelector": [".lead", ".shloka-card .meaning-text", ".shloka-card .essence", ".tulsidas-card .gloss", ".highlight-box p", "h2", "h3"]
    }
  },
  {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [
      { "@type": "ListItem", "position": 1, "name": "Wisdom", "item": "https://wisdomquotes.in/" },
      { "@type": "ListItem", "position": 2, "name": "Blog", "item": "https://wisdomquotes.in/blogs" },
      { "@type": "ListItem", "position": 3, "name": "Krishna's Three Paths — Karma, Jnana, Bhakti", "item": "https://wisdomquotes.in/blogs/krishna-three-paths-bhagavad-gita" }
    ]
  },
  {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      { "@type": "Question", "name": "What are the three paths Krishna teaches in the Bhagavad Gita?", "acceptedAnswer": { "@type": "Answer", "text": "Krishna teaches three converging paths: Karma Yoga — the path of selfless action; Jnana Yoga — the path of knowledge and self-inquiry; and Bhakti Yoga — the path of devotion and surrender. All three lead to the same supreme reality, but each is shaped for a different temperament." } },
      { "@type": "Question", "name": "Why does Krishna give three paths instead of one?", "acceptedAnswer": { "@type": "Answer", "text": "Because human beings differ. Some are restless doers, some are restless thinkers, and some are restless feelers. Krishna meets each personality where it is. In 4.11 he says — 'In whatever way people approach me, in that way I respond to them.' The truth is one; the doors are many." } },
      { "@type": "Question", "name": "Which of the three paths is the highest?", "acceptedAnswer": { "@type": "Answer", "text": "Krishna does not establish a flat hierarchy. In 12.12 he names a sequence: practice, then knowledge, then meditation, then renunciation of the fruit of action — and from that renunciation, peace follows immediately. In 7.17 he calls the jnani-bhakta — the wise lover — dearest. In 18.66 he calls surrender the final teaching. The paths complete each other; they do not compete." } },
      { "@type": "Question", "name": "How does Tulsidas's 'karm pradhan' verse relate to the Gita's Karma Yoga?", "acceptedAnswer": { "@type": "Answer", "text": "Tulsidas writes: 'karam pradhan bisva kari rakha, jo jas karai so tas phalu chakha' — 'the world is governed by action; whatever you do, that is the fruit you taste.' This is the law of karma in Awadhi: the same teaching Krishna gives in 2.47, that action belongs to you and shapes you, even when the fruit does not." } },
      { "@type": "Question", "name": "What does 'hoihi soi jo Rama rachi rakha' mean and how does it connect to surrender in the Gita?", "acceptedAnswer": { "@type": "Answer", "text": "Tulsidas writes: 'hoihi soi jo rama rachi rakha, ko kari tarka badhavai sakha' — 'only that will happen which Rama has scripted; who can extend the branches of argument?' This is the Ramcharitmanas form of Krishna's teaching in 11.33 — 'they have already been killed by me; become only the instrument' — and in 18.66, 'take refuge in me alone.'" } },
      { "@type": "Question", "name": "How do the three paths connect to modern mental health?", "acceptedAnswer": { "@type": "Answer", "text": "Karma Yoga maps onto value-driven action over outcome-anxiety — closely related to ACT therapy. Jnana Yoga is the witness-perspective that breaks rumination, the foundation of metacognitive therapy and Buddhist mindfulness. Bhakti Yoga is surrender as a secure base — the experience of being held, which attachment science now confirms regulates the nervous system." } },
      { "@type": "Question", "name": "How do I know which path is mine?", "acceptedAnswer": { "@type": "Answer", "text": "Notice what your restlessness wants. If you cannot sit still and need to do — your path likely begins with action. If you cannot stop questioning and need to understand — your path begins with knowledge. If you feel deeply and need to be in relationship — your path begins with devotion. The path you naturally walk is the one that will carry you furthest." } }
    ]
  },
  {
    "@context": "https://schema.org",
    "@type": "Quotation",
    "@id": "https://wisdomquotes.in/blogs/krishna-three-paths-bhagavad-gita#verse-2-47",
    "text": "You have a right to action alone, never to its fruits. Do not become the cause of the result, and do not cling to inaction.",
    "spokenByCharacter": { "@type": "Person", "name": "Krishna" },
    "creator": { "@type": "Person", "name": "Krishna" },
    "isPartOf": { "@type": "Book", "name": "Bhagavad Gita, Chapter 2, Verse 47" },
    "inLanguage": ["sa", "en"],
    "alternateName": [
      "कर्मण्येवाधिकारस्ते मा फलेषु कदाचन । मा कर्मफलहेतुर्भूर्मा ते सङ्गोऽस्त्वकर्मणि ॥",
      "karmaṇyevādhikāraste mā phaleṣu kadācana | mā karmaphalahetur bhūr mā te saṅgo'stvakarmaṇi ||"
    ],
    "url": "https://wisdomquotes.in/blogs/krishna-three-paths-bhagavad-gita#verse-2-47"
  },
  {
    "@context": "https://schema.org",
    "@type": "Quotation",
    "@id": "https://wisdomquotes.in/blogs/krishna-three-paths-bhagavad-gita#verse-3-30",
    "text": "Surrender all actions to me with the disciplined mind. Free from desire, possessiveness, and sorrow — fight.",
    "spokenByCharacter": { "@type": "Person", "name": "Krishna" },
    "creator": { "@type": "Person", "name": "Krishna" },
    "isPartOf": { "@type": "Book", "name": "Bhagavad Gita, Chapter 3, Verse 30" },
    "inLanguage": ["sa", "en"],
    "alternateName": [
      "मयि सर्वाणि कर्माणि संन्यस्याध्यात्मचेतसा । निराशीर्निर्ममो भूत्वा युध्यस्व विगतज्वरः ॥",
      "mayi sarvāṇi karmāṇi saṃnyasyādhyātmacetasā | nirāśīrnirmamo bhūtvā yudhyasva vigatajvaraḥ ||"
    ],
    "url": "https://wisdomquotes.in/blogs/krishna-three-paths-bhagavad-gita#verse-3-30"
  },
  {
    "@context": "https://schema.org",
    "@type": "Quotation",
    "@id": "https://wisdomquotes.in/blogs/krishna-three-paths-bhagavad-gita#verse-4-34",
    "text": "Know that by prostration, by sincere questioning, and by service. The wise who see reality will teach you that knowledge.",
    "spokenByCharacter": { "@type": "Person", "name": "Krishna" },
    "creator": { "@type": "Person", "name": "Krishna" },
    "isPartOf": { "@type": "Book", "name": "Bhagavad Gita, Chapter 4, Verse 34" },
    "inLanguage": ["sa", "en"],
    "alternateName": [
      "तद्विद्धि प्रणिपातेन परिप्रश्नेन सेवया । उपदेक्ष्यन्ति ते ज्ञानं ज्ञानिनस्तत्त्वदर्शिनः ॥",
      "tadviddhi praṇipātena paripraśnena sevayā | upadekṣyanti te jñānaṃ jñāninastattvadarśinaḥ ||"
    ],
    "url": "https://wisdomquotes.in/blogs/krishna-three-paths-bhagavad-gita#verse-4-34"
  },
  {
    "@context": "https://schema.org",
    "@type": "Quotation",
    "@id": "https://wisdomquotes.in/blogs/krishna-three-paths-bhagavad-gita#verse-7-17",
    "text": "Among these four, the wise devotee — ever united, one-pointed — is distinguished. For I am exceedingly dear to the wise one, and the wise one is dear to me.",
    "spokenByCharacter": { "@type": "Person", "name": "Krishna" },
    "creator": { "@type": "Person", "name": "Krishna" },
    "isPartOf": { "@type": "Book", "name": "Bhagavad Gita, Chapter 7, Verse 17" },
    "inLanguage": ["sa", "en"],
    "alternateName": [
      "तेषां ज्ञानी नित्ययुक्त एकभक्तिर्विशिष्यते । प्रियो हि ज्ञानिनोऽत्यर्थमहं स च मम प्रियः ॥",
      "teṣāṃ jñānī nityayukta ekabhaktirviśiṣyate | priyo hi jñānino'tyarthamahaṃ sa ca mama priyaḥ ||"
    ],
    "url": "https://wisdomquotes.in/blogs/krishna-three-paths-bhagavad-gita#verse-7-17"
  },
  {
    "@context": "https://schema.org",
    "@type": "Quotation",
    "@id": "https://wisdomquotes.in/blogs/krishna-three-paths-bhagavad-gita#verse-9-22",
    "text": "Those who think of me alone and worship me with unwavering focus — I carry their welfare and security.",
    "spokenByCharacter": { "@type": "Person", "name": "Krishna" },
    "creator": { "@type": "Person", "name": "Krishna" },
    "isPartOf": { "@type": "Book", "name": "Bhagavad Gita, Chapter 9, Verse 22" },
    "inLanguage": ["sa", "en"],
    "alternateName": [
      "अनन्याश्चिन्तयन्तो मां ये जनाः पर्युपासते । तेषां नित्याभियुक्तानां योगक्षेमं वहाम्यहम् ॥",
      "ananyāścintayanto māṃ ye janāḥ paryupāsate | teṣāṃ nityābhiyuktānāṃ yogakṣemaṃ vahāmyaham ||"
    ],
    "url": "https://wisdomquotes.in/blogs/krishna-three-paths-bhagavad-gita#verse-9-22"
  },
  {
    "@context": "https://schema.org",
    "@type": "Quotation",
    "@id": "https://wisdomquotes.in/blogs/krishna-three-paths-bhagavad-gita#verse-18-66",
    "text": "Abandon all duties and take refuge in me alone. I will free you from all wrongdoing; do not grieve.",
    "spokenByCharacter": { "@type": "Person", "name": "Krishna" },
    "creator": { "@type": "Person", "name": "Krishna" },
    "isPartOf": { "@type": "Book", "name": "Bhagavad Gita, Chapter 18, Verse 66" },
    "inLanguage": ["sa", "en"],
    "alternateName": [
      "सर्वधर्मान्परित्यज्य मामेकं शरणं व्रज । अहं त्वा सर्वपापेभ्यो मोक्षयिष्यामि मा शुचः ॥",
      "sarvadharmān parityajya mām ekaṃ śaraṇaṃ vraja | ahaṃ tvā sarvapāpebhyo mokṣayiṣyāmi mā śucaḥ ||"
    ],
    "url": "https://wisdomquotes.in/blogs/krishna-three-paths-bhagavad-gita#verse-18-66"
  },
  {
    "@context": "https://schema.org",
    "@type": "Quotation",
    "@id": "https://wisdomquotes.in/blogs/krishna-three-paths-bhagavad-gita#tulsidas-karm-pradhan",
    "text": "The world is governed by action; whoever does whatever, tastes the fruit accordingly.",
    "spokenByCharacter": { "@type": "Person", "name": "Tulsidas" },
    "creator": { "@type": "Person", "name": "Tulsidas" },
    "isPartOf": { "@type": "Book", "name": "Ramcharitmanas, Ayodhya Kand, Doha 218" },
    "inLanguage": ["awa", "en"],
    "alternateName": [
      "करम प्रधान बिस्व करि राखा। जो जस करइ सो तस फलु चाखा॥",
      "karam pradhāna bisva kari rākhā, jo jasa karai so tasa phalu chākhā."
    ],
    "url": "https://wisdomquotes.in/blogs/krishna-three-paths-bhagavad-gita#tulsidas-karm-pradhan"
  },
  {
    "@context": "https://schema.org",
    "@type": "Quotation",
    "@id": "https://wisdomquotes.in/blogs/krishna-three-paths-bhagavad-gita#tulsidas-hoihi-soi",
    "text": "Only that will happen which Rama has already scripted; who can extend the branches of argument?",
    "spokenByCharacter": { "@type": "Person", "name": "Shiva" },
    "creator": { "@type": "Person", "name": "Tulsidas" },
    "isPartOf": { "@type": "Book", "name": "Ramcharitmanas, Bal Kand, Doha 190" },
    "inLanguage": ["awa", "en"],
    "alternateName": [
      "होइहि सोइ जो राम रचि राखा। को करि तर्क बढ़ावै साखा॥",
      "hoihi soi jo rāma rachi rākhā, ko kari tarka ba.dhāvai sākhā."
    ],
    "url": "https://wisdomquotes.in/blogs/krishna-three-paths-bhagavad-gita#tulsidas-hoihi-soi"
  }
]

export default function KrishnaThreePathsPage() {
  return (
    <>
      <style dangerouslySetInnerHTML={{ __html: pageCSS }} />
      {schemas.map((s, i) => (
        <script key={i} type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(s) }} />
      ))}

      <div className="breadcrumb">
        <div className="breadcrumb-inner">
          <a href="/">Wisdom</a>
          <span className="bc-sep">/</span>
          <a href="/blogs">Blog</a>
          <span className="bc-sep">/</span>
          Krishna&apos;s Three Paths
        </div>
      </div>

      <article itemScope itemType="https://schema.org/Article">
      <div className="article-hero">
        <div className="article-hero-inner">
          <div className="chapter-badge">
            <div className="chapter-badge-dot"></div>
            Topic Guide · The Three Yogas
            <div className="chapter-badge-dot"></div>
          </div>
          <h1 className="article-title">
            Krishna&apos;s Three Paths:<br />
            <em>Karma, Jnana, Bhakti and Why the Gita Offers Three Roads to the Same Reality</em>
          </h1>
          <p className="article-subtitle">
            Krishna does not say there is one way. He lays out three (Action, Wisdom, Devotion) and tells Arjuna each one will carry him home. A deep reading, grounded in the verses, with parallels from Tulsidas&apos;s Ramcharitmanas and what modern psychology has begun to confirm.
          </p>
          <div className="article-meta">
            <span className="meta-item">By <a href="/about" rel="author" data-mp-location="byline_author" style={{ color: 'var(--gold-light)', borderBottom: '1px solid rgba(200,136,30,0.35)' }}>Ankur Shukla</a></span>
            <span className="meta-sep">·</span>
            <span className="meta-item">Topic Guide · Three Yogas</span>
            <span className="meta-sep">·</span>
            <span className="meta-item">~18 min read</span>
          </div>
          <span className="meta-sep">·</span>
          <span className="meta-item" style={{ fontStyle: 'italic' }}>Wisdom translation, edited by Ankur Shukla. Commentary AI-drafted, human-reviewed. Reviewed June 2026. <a href="/methodology" style={{ color: 'var(--gold-light)', borderBottom: '1px solid rgba(200,136,30,0.3)' }}>Methodology →</a></span>
        </div>
      </div>

      <div className="content">
        <figure className="chapter-image">
          <img
            src="/assets/3paths.webp"
            alt="Krishna at the summit: the three paths of Wisdom, Action and Devotion converge on the supreme reality"
            width={1536}
            height={1024}
            loading="eager"
            fetchPriority="high"
          />
          <figcaption>Three paths. One summit. The seeker chooses the road; the destination is already chosen.</figcaption>
        </figure>

        <p className="lead">
          Somewhere on a battlefield in Kurukshetra, a man asks the oldest question in human spiritual life: <em>What am I supposed to do with myself?</em> Arjuna is not asking only about the war. He is asking what the rest of us also ask, in our own way, in our own decades: how does a person actually live? What is the right relationship between thinking, doing, and feeling? Krishna&apos;s answer is the Bhagavad Gita. And his answer is not one path. It is three.
        </p>

        <p>
          This is the part of the Gita most people miss. The Gita does not say: <em>here is the one true method; everyone, do this</em>. It says: <em>here are three doors into the same room; walk through the one that fits your nature, and the others will open from inside</em>. The three doors have names. Krishna calls them <strong>Karma Yoga</strong> (the path of action, the focus of <a href="/blogs/bhagwat-geeta-chapter-3" style={{ color: 'var(--gold-light)', borderBottom: '1px solid rgba(200,136,30,0.35)' }}>Chapter 3</a>); <strong>Jnana Yoga</strong> (the path of knowledge, the focus of <a href="/blogs/bhagwat-geeta-chapter-4" style={{ color: 'var(--gold-light)', borderBottom: '1px solid rgba(200,136,30,0.35)' }}>Chapter 4</a>); and <strong>Bhakti Yoga</strong> (the path of devotion, given its most compressed expression in <a href="/blogs/bhagwat-geeta-chapter-12" style={{ color: 'var(--gold-light)', borderBottom: '1px solid rgba(200,136,30,0.35)' }}>Chapter 12</a>). In chapter 13, verse 24, Krishna himself lays out the spectrum: <em>some realize the Self through meditation, some through Sankhya yoga, and some through karma yoga</em> (BG 13.24).
        </p>

        <div className="paths-grid">
          <div className="path-card">
            <div className="glyph">कर्म</div>
            <div className="name">Karma Yoga</div>
            <div className="sub">The Path of Action</div>
            <div className="body">For those who cannot sit still. Do your work, fully, but stop demanding that life pay you for it.</div>
          </div>
          <div className="path-card">
            <div className="glyph">ज्ञान</div>
            <div className="name">Jnana Yoga</div>
            <div className="sub">The Path of Knowledge</div>
            <div className="body">For those who cannot stop asking. Look long enough at what you are not, and what you are becomes obvious.</div>
          </div>
          <div className="path-card">
            <div className="glyph">भक्ति</div>
            <div className="name">Bhakti Yoga</div>
            <div className="sub">The Path of Devotion</div>
            <div className="body">For those who feel deeply. Stop carrying yourself. Hand it over to something larger and let it carry you.</div>
          </div>
        </div>

        <p>
          The premise underneath all three is the same. The names are different (Krishna, Brahman, Atman, the Supreme) but the destination is one. What changes is the road, because the people walking are different. The Gita is psychologically honest in a way most spiritual texts are not: it admits that human beings are not uniform. Some of us live in our hands. Some live in our minds. Some live in our hearts. Krishna does not ask any of us to leave the place we live. He asks us to use that place as a door.
        </p>

        <div className="gita-index">
          <h3>What this article covers</h3>
          <ol>
            <li><strong>Karma Yoga</strong>: action without attachment, and the surprising relief of not owning the result</li>
            <li><strong>Jnana Yoga</strong>: the knowledge that ends seeking, and why it cuts rumination at the root</li>
            <li><strong>Bhakti Yoga</strong>: devotion as the easiest path, and the science of surrender</li>
            <li><strong>Where they meet</strong>: the four kinds of seekers, the summit verse, and Tulsidas&apos;s same teaching in different words</li>
            <li><strong>Which path is yours</strong>: and how the Wisdom app places you on it</li>
          </ol>
        </div>

        {/* ── KARMA YOGA ── */}
        <div className="path-header">
          <span className="path-badge">Path 1 of 3</span>
          <h2 className="path-title" id="karma-yoga">Karma Yoga, Act, but Stop Owning the Outcome</h2>
        </div>

        <p>
          The Gita&apos;s most quoted verse belongs to this path. It is the answer Krishna gives in chapter 2 when Arjuna&apos;s collapse has reached its lowest point, when the warrior has put down his bow and is ready to leave the field. Krishna does not console him. He does not say <em>you do not have to fight</em>. He gives him a different relationship with the act of fighting:
        </p>

                <ShlokaCard
          verseRef="Bhagavad Gita 2.47"
          sanskrit="कर्मण्येवाधिकारस्ते मा फलेषु कदाचन । मा कर्मफलहेतुर्भूर्मा ते सङ्गोऽस्त्वकर्मणि ॥"
          iast="karmaṇyevādhikāraste mā phaleṣu kadācana | mā karmaphalahetur bhūr mā te saṅgo'stvakarmaṇi ||"
          meaningLabel="Translation"
          meaning="You have a right to action alone, never to its fruits. Do not become the cause of the result, and do not cling to inaction."
          insightLabel="What this actually says"
          insight="Most people read this as a teaching about renunciation. It is not. It is a teaching about ownership. Krishna is not saying do not want anything. He is saying you have authority over one thing (the act) and you do not have authority over the second thing (the fruit). The fruit is shaped by a thousand causes, of which your effort is one. When you try to control what was never yours to control, you suffer. When you do your work fully and release the fruit, you finally do the work well."
          essence="Action belongs to you. The result does not."
        />

        <p>
          The reason this teaching survives across three millennia is that it solves a very specific psychological problem. We are wired to act for outcomes. We pour effort in and we expect proportional return. When the return does not come, or when it comes late, or in the wrong currency, we collapse, we blame, we burn out. Krishna&apos;s teaching is not <em>care less</em>. It is <em>care fully, but separate the caring from the demanding</em>. He repeats it a chapter later, more directly:
        </p>

                <ShlokaCard
          verseRef="Bhagavad Gita 3.19"
          sanskrit="तस्मादसक्तः सततं कार्यं कर्म समाचर । असक्तो ह्याचरन्कर्म परमाप्नोति पूरुषः ॥"
          iast="tasmādasaktaḥ satataṃ kāryaṃ karma samācara | asakto hyācarankarma paramāpnoti pūruṣaḥ ||"
          meaningLabel="Translation"
          meaning="Therefore, always perform your duty without attachment; by acting without attachment, a person reaches the supreme."
          insightLabel="Why this is the path, not just a tactic"
          insight="Krishna's claim is large. He says unattached action is not just a healthier way to work: it is itself the road to the supreme. Action becomes spiritual when it stops being transactional. The craftsman who shapes the stone without demanding to see the temple completed is, at that moment, doing the same inner work as the contemplative who has renounced the world."
          essence="Action done without grasping is itself the path."
        />

        <p>
          And then, in chapter 3, Krishna gives the verse that turns Karma Yoga from a personal discipline into something cosmic, an offering:
        </p>

                <ShlokaCard
          verseRef="Bhagavad Gita 3.30"
          sanskrit="मयि सर्वाणि कर्माणि संन्यस्याध्यात्मचेतसा । निराशीर्निर्ममो भूत्वा युध्यस्व विगतज्वरः ॥"
          iast="mayi sarvāṇi karmāṇi saṃnyasyādhyātmacetasā | nirāśīrnirmamo bhūtvā yudhyasva vigatajvaraḥ ||"
          meaningLabel="Translation"
          meaning="Surrender all actions to me with the disciplined mind. Free from desire, possessiveness, and sorrow, fight."
          insightLabel="Vigata-jvara: the fever has left"
          insight="The last word, vigatajvarah, is precise. Jvara is fever. Krishna is naming the experience of acting from anxiety: that low-grade feverishness most modern lives are conducted in. He says the cure is not less action; it is offered action. When you give the act to something larger than your private ledger of wins and losses, the fever lifts. You can still fight. You just no longer need the fight to define you."
          essence="When the act is offered, the fever leaves."
        />

        <h3>Tulsidas, eight hundred years later, in different words</h3>

        <p>
          Krishna&apos;s Karma Yoga did not stay sealed in Sanskrit. It walked out into the bhakti era and into common languages. Tulsidas, writing the Ramcharitmanas in Awadhi in the sixteenth century, delivered the same teaching in a chaupai that is still recited across northern India. (We have a separate piece on <a href="/blogs/bhagavad-gita-karma-meaning" style={{ color: 'var(--gold-light)', borderBottom: '1px solid rgba(200,136,30,0.35)' }}>what karma actually means in the Gita</a>. The cliché version most people carry is wrong in instructive ways.)
        </p>

        <div className="tulsidas-card" id="tulsidas-karm-pradhan">
          <div className="source-label">Ramcharitmanas · Ayodhya Kand · 2.218</div>
          <div className="awadhi">करम प्रधान बिस्व करि राखा।{'\n'}जो जस करइ सो तस फलु चाखा॥</div>
          <div className="roman">karam pradhāna bisva kari rākhā,{'\n'}jo jasa karai so tasa phalu chākhā.</div>
          <div className="gloss">
            <strong>The world is governed by action; whoever does whatever, tastes the fruit accordingly.</strong> Tulsidas, in the voice of his own narration, gives the law of karma in twenty syllables. It is the same teaching Krishna gives in 2.47: that action is the lever, that you cannot opt out of it, that the universe is responsive to what you actually do. The Sanskrit pandit&apos;s argument and the village reciter&apos;s couplet are saying the same thing.
          </div>
        </div>

        <p>
          The Gita does not say karma is mechanical fate. It says karma is real cause. Your actions shape what comes back, not always in the form you expect, not always on the schedule you wanted, but they do. Karma Yoga&apos;s teaching is what you do with that fact: you take it seriously enough to act well, and you take it gently enough not to obsess over the receipt.
        </p>

        <h3>Modern parallel, the value-driven life</h3>

        <p>
          Contemporary psychology has, in the last twenty years, arrived at something remarkably close to Karma Yoga from a completely different direction. Acceptance and Commitment Therapy (ACT) distinguishes between <em>outcome-driven</em> living (I will be happy when X happens) and <em>value-driven</em> living (I will act in line with what matters to me, regardless of whether X happens). The first is fragile; it requires the world to comply. The second is portable; it works on a Tuesday morning when nothing in the world has cooperated. Krishna is teaching value-driven action, three thousand years earlier, in Sanskrit verse. The clinical research is now catching up to the chaupai.
        </p>

        <div className="highlight-box">
          <h3>Karma Yoga in one sentence</h3>
          <p>
            Do the work fully. Hand the result over. The fever leaves, and the action, done from this place, becomes the thing that finally carries you somewhere.
          </p>
        </div>

        {/* ── JNANA YOGA ── */}
        <div className="path-header">
          <span className="path-badge">Path 2 of 3</span>
          <h2 className="path-title" id="jnana-yoga">Jnana Yoga, Knowledge as the Fire That Burns Confusion</h2>
        </div>

        <p>
          The second path is for a different kind of restlessness. The Karma Yogi cannot sit still; the Jnana Yogi cannot stop asking. For this seeker, the relief comes not from doing the right thing but from seeing the right thing clearly, finally, without the haze that ordinary thought leaves behind. Krishna&apos;s claim in chapter 4 is unusually large:
        </p>

                <ShlokaCard
          verseRef="Bhagavad Gita 4.38"
          sanskrit="न हि ज्ञानेन सदृशं पवित्रमिह विद्यते । तत्स्वयं योगसंसिद्धः कालेनात्मनि विन्दति ॥"
          iast="na hi jñānena sadṛśaṃ pavitramiha vidyate | tatsvayaṃ yogasaṃsiddhaḥ kālenātmani vindati ||"
          meaningLabel="Translation"
          meaning="No purifier compares to knowledge in this world. The one perfected in yoga finds that knowledge within the self, in time."
          insightLabel="Knowledge that purifies, not knowledge that informs"
          insight="Krishna is not talking about facts. He is talking about jnana: direct understanding of what is real and what is appearance. The knowledge of who you are, beneath the conditioning. When this kind of knowing happens, it does not just add information; it removes confusion. That is what pavitra means here: purifier. Wrong-seeing leaves the system the way clean water removes silt."
          essence="Nothing purifies like knowledge. Wrong-seeing is the only real dirt."
        />

        <p>
          But this knowledge is not bought cheaply. The Gita has very specific instructions for how it is approached:
        </p>

                <ShlokaCard
          verseRef="Bhagavad Gita 4.34"
          sanskrit="तद्विद्धि प्रणिपातेन परिप्रश्नेन सेवया । उपदेक्ष्यन्ति ते ज्ञानं ज्ञानिनस्तत्त्वदर्शिनः ॥"
          iast="tadviddhi praṇipātena paripraśnena sevayā | upadekṣyanti te jñānaṃ jñāninastattvadarśinaḥ ||"
          meaningLabel="Translation"
          meaning="Know that by prostration, by sincere questioning, and by service. The wise who see reality will teach you that knowledge."
          insightLabel="Three movements, in this exact order"
          insight="Bowing first, asking second, serving third. The order matters. Most modern learners start with the question and skip the humility. As a result, the question itself comes out distorted by the ego asking it. Krishna's sequence assumes the learner has first put down the need to be right. Only then does the real question become possible. And only then does the answer have a place to land."
          essence="Bow, then ask, then serve. Knowledge enters in that order."
        />

        <p>
          The content of this knowledge (what the Jnani actually comes to see) is laid out across the middle chapters of the Gita, and most cleanly in chapter 13. Here Krishna draws the central distinction of the entire tradition: between <em>kshetra</em> (the field: the body, the mind, the emotions, all observable experience) and <em>kshetrajna</em> (the knower of the field: pure awareness, watching). Almost everything we suffer about is in the field. The knower has never been wounded.
        </p>

                <ShlokaCard
          verseRef="Bhagavad Gita 13.24"
          sanskrit="य एवं वेत्ति पुरुषं प्रकृतिं च गुणैःसह । सर्वथा वर्तमानोऽपि न स भूयोऽभिजायते ॥"
          iast="ya evaṃ vetti puruṣaṃ prakṛtiṃ ca guṇaiḥsaha | sarvathā vartamāno'pi na sa bhūyo'bhijāyate ||"
          meaningLabel="Translation"
          meaning="Whoever thus knows the purusha and prakriti together with the qualities is not born again, even while living and acting in every way."
          insightLabel="Liberation that doesn&apos;t require renunciation"
          insight="The crucial phrase is sarvatha vartamano'pi: even while living and acting in every way. Krishna is not asking the Jnani to leave the world. He is saying: once you have seen the difference between the field and the knower, you can do anything in the field (work a job, raise children, fight a war) and not be bound by it. Liberation is a shift in identity, not a change of address."
          essence="Clear seeing frees you while life still continues."
        />

        <h3>The Upanishadic root, neti, neti</h3>

        <p>
          Jnana Yoga did not begin with Krishna. He inherited it from the Upanishads, whose central method, <em>neti, neti</em> (&ldquo;not this, not this&rdquo;), is the original Jnana practice. The sage Yajnavalkya in the Brihadaranyaka Upanishad teaches that the self cannot be grasped as an object, because it is what is doing the grasping. You proceed by eliminating: you are not the body, because you can observe the body. You are not the mind, because you can observe the mind. What remains, when everything you can observe has been set aside, is what you have been all along. The <a href="/blogs/beyond-bhagavad-gita-quotes-mental-spiritual-health" style={{ color: 'var(--gold-light)', borderBottom: '1px solid rgba(200,136,30,0.35)' }}>Ashtavakra Gita, the Avadhuta Gita, and other lesser-known Gitas</a> carry this method to its furthest expression. Krishna&apos;s gift in chapter 13 was to compress it into a structure ordinary people could actually use.
        </p>

        <h3>Modern parallel, metacognition and the witness</h3>

        <p>
          Cognitive science has, in the last thirty years, identified rumination (the repetitive recycling of negative thought) as one of the strongest predictors of depression and chronic anxiety. The most successful interventions for rumination are not techniques to think better thoughts. They are techniques to <em>watch</em> thoughts, to develop what psychologists call &ldquo;metacognitive awareness,&rdquo; the capacity to notice that you are thinking, without being identical to the thought. This is, almost word for word, the Jnana practice of distinguishing kshetra from kshetrajna. The witness is therapeutic precisely because it is true.
        </p>

        <p className="pull-quote">
          The thought arises in you, but you are not the thought. Notice this once, and the day softens. Notice it consistently, and the architecture of suffering begins to come apart.
        </p>

        {/* ── BHAKTI YOGA ── */}
        <div className="path-header">
          <span className="path-badge">Path 3 of 3</span>
          <h2 className="path-title" id="bhakti-yoga">Bhakti Yoga, Devotion as the Easiest, and the Hardest, Path</h2>
        </div>

        <p>
          The third path begins where the second ends. Jnana Yoga asks you to see clearly, but Krishna, with disarming honesty, admits in chapter 12 that this is hard:
        </p>

                <ShlokaCard
          verseRef="Bhagavad Gita 12.5"
          sanskrit="क्लेशोऽधिकतरस्तेषामव्यक्तासक्तचेतसाम् । अव्यक्ता हि गतिर्दुःखं देहवद्भिरवाप्यते ॥"
          iast="kleśo'dhikatarasteṣāmavyaktāsaktacetasām | avyaktā hi gatirduḥkhaṃ dehavadbhiravāpyate ||"
          meaningLabel="Translation"
          meaning="For those whose minds cling to the unmanifest, the struggle is greater. The unmanifest path is hard to reach for embodied beings."
          insightLabel="Krishna&apos;s honesty about the abstract"
          insight="Pure Jnana, meditation on the formless, unmanifest reality, is not impossible. It is just brutally hard for human beings, because human beings are bodies, and bodies live in relationship to forms. Krishna does not shame anyone for finding the abstract path difficult. He offers an alternative that meets us where we actually live: in feeling, in form, in relationship."
          essence="The subtlest path is hardest for a body-bound mind. There is another way."
        />

        <p>
          That alternative is Bhakti. Where Jnana asks <em>what is real?</em>, Bhakti asks <em>whom do I love?</em>. The answer is the same (the Supreme) but the route is utterly different. Bhakti uses what is already in the human heart: the capacity for attachment, longing, surrender. It does not eliminate emotion; it reorients it. The same energy that gets spent on a hundred small attachments is gathered up and turned toward the one source from which all attachment seemed to come in the first place.
        </p>

                <ShlokaCard
          verseRef="Bhagavad Gita 12.8"
          sanskrit="मय्येव मन आधत्स्व मयि बुद्धिं निवेशय । निवसिष्यसि मय्येव अत ऊर्ध्वं न संशयः ॥"
          iast="mayyeva mana ādhatsva mayi buddhiṃ niveśaya | nivasiṣyasi mayyeva ata ūrdhvaṃ na saṃśayaḥ ||"
          meaningLabel="Translation"
          meaning="Fix your mind on me alone. Place your discerning mind in me, and you will live in me, beyond doubt."
          insightLabel="A divided mind is the disease"
          insight="Most psychological suffering is the suffering of fragmentation. Part of you wants this, part of you wants that, part of you is criticizing both parts. Krishna's instruction is not think more carefully. It is gather both your thought and your feeling into one focus. The mind, when finally pointed at one thing it loves, stops splitting itself. The peace is not the reward; the gathering is the peace."
          essence="A divided mind settles when both thought and feeling rest in one place."
        />

        <p>
          And then, in chapter 9, Krishna gives the verse that has comforted more sufferers than possibly any other line in the book, the promise underneath the entire path:
        </p>

                <ShlokaCard
          verseRef="Bhagavad Gita 9.22"
          sanskrit="अनन्याश्चिन्तयन्तो मां ये जनाः पर्युपासते । तेषां नित्याभियुक्तानां योगक्षेमं वहाम्यहम् ॥"
          iast="ananyāścintayanto māṃ ye janāḥ paryupāsate | teṣāṃ nityābhiyuktānāṃ yogakṣemaṃ vahāmyaham ||"
          meaningLabel="Translation"
          meaning="Those who think of me alone and worship me with unwavering focus, I carry their welfare and security."
          insightLabel="Yoga-kshema: getting and keeping"
          insight="The compound word yoga-kshema is precise. Yoga is acquiring what you do not yet have. Kshema is preserving what you already have. Krishna takes both burdens. The devotee's job is not to engineer outcomes; it is to remain devoted. Read this verse on a hard morning. It does not promise that life will be easy. It promises that the load is not yours alone."
          essence="Unwavering devotion is met by unwavering support."
        />

        <p>
          The most beautiful thing about Bhakti is the smallness of the offering it requires. There is no minimum donation. There is no spiritual qualification. Krishna says this directly:
        </p>

                <ShlokaCard
          verseRef="Bhagavad Gita 9.26"
          sanskrit="पत्रं पुष्पं फलं तोयं यो मे भक्त्या प्रयच्छति । तदहं भक्त्युपहृतमश्नामि प्रयतात्मनः ॥"
          iast="patraṃ puṣpaṃ phalaṃ toyaṃ yo me bhaktyā prayacchati | tadahaṃ bhaktyupahṛtamaśnāmi prayatātmanaḥ ||"
          meaningLabel="Translation"
          meaning="Whoever offers me a leaf, a flower, a fruit, or water with devotion, I accept that devoted offering from the pure-hearted."
          insightLabel="It is the devotion, not the object"
          insight="A leaf. A flower. A fruit. Water. The cheapest things on earth. Krishna chose the items deliberately, to make it clear that Bhakti is not about wealth or ritual or scholarship. It is about what fills the offering. A glass of water given from the heart contains more than an elaborate ceremony given from obligation. This is the great democratization of the spiritual life."
          essence="A small offering becomes complete when devotion fills it."
        />

        <h3>Tulsidas, surrender in Awadhi verse</h3>

        <p>
          If Krishna&apos;s Karma teaching reached Tulsidas as <em>karam pradhan bisva kari rakha</em>, his Bhakti teaching reached Tulsidas as a different chaupai entirely, spoken by Shiva in the Bal Kand after Sati&apos;s collapse, when nothing more can be argued:
        </p>

        <div className="tulsidas-card" id="tulsidas-hoihi-soi">
          <div className="source-label">Ramcharitmanas · Bal Kand · 1.190</div>
          <div className="awadhi">होइहि सोइ जो राम रचि राखा।{'\n'}को करि तर्क बढ़ावै साखा॥</div>
          <div className="roman">hoihi soi jo rāma rachi rākhā,{'\n'}ko kari tarka ba.dhāvai sākhā.</div>
          <div className="gloss">
            <strong>Only that will happen which Rama has already scripted; who can extend the branches of argument?</strong> This is the Ramcharitmanas form of Krishna&apos;s teaching in 11.33 (<em>they have already been killed by me; you become only the instrument</em>) and in 18.66, his final word: <em>take refuge in me alone</em>. The argument is exhausted; the surrender begins. Tulsidas places this line precisely at the moment when intellect has run out of room. Bhakti starts where logic stops.
          </div>
        </div>

                <ShlokaCard
          verseRef="Bhagavad Gita 11.33"
          sanskrit="तस्मात्त्वमुत्तिष्ठ यशो लभस्व ... मयैवैते निहताः पूर्वमेव निमित्तमात्रं भव सव्यसाचिन् ॥"
          iast="tasmāttvamuttiṣṭha yaśo labhasva ... mayaivaite nihatāḥ pūrvameva nimittamātraṃ bhava savyasācin ||"
          meaningLabel="Translation"
          meaning="Therefore rise and win fame. They have already been slain by me; become only the instrument, Arjuna."
          insightLabel="Karma Yoga and Bhakti Yoga, fused in one verse"
          insight="This verse is the seam where the paths meet. Krishna does not tell Arjuna not to act. He tells him to act fully (uttishtha, rise). But he also relieves him of the metaphysical burden of being the doer. Nimitta-matra: only the instrument. You bring the bow. The larger movement of things has already decided where the arrow lands. This is the same instruction Tulsidas distilled into hoihi soi jo rama rachi rakha."
          essence="Act fully. Let the larger order carry the result."
        />

        <p>
          And then, the verse that closes the entire Gita, the line Krishna calls the most secret teaching of all:
        </p>

                <ShlokaCard
          verseRef="Bhagavad Gita 18.66: the final teaching"
          sanskrit="सर्वधर्मान्परित्यज्य मामेकं शरणं व्रज । अहं त्वा सर्वपापेभ्यो मोक्षयिष्यामि मा शुचः ॥"
          iast="sarvadharmān parityajya mām ekaṃ śaraṇaṃ vraja | ahaṃ tvā sarvapāpebhyo mokṣayiṣyāmi mā śucaḥ ||"
          meaningLabel="Translation"
          meaning="Abandon all duties and take refuge in me alone. I will free you from all wrongdoing; do not grieve."
          insightLabel="Ma shuchah: do not grieve"
          insight="After seventeen chapters of teaching (every framework, every distinction, every yoga) Krishna ends with the simplest possible instruction. Drop the burden of getting it right. Hand the load to me. The last two words, ma shuchah, are tender: do not grieve. The Gita that began with Arjuna's grief ends with Krishna's promise that the grief has nowhere left to live."
          essence="Total refuge ends the burden of fear."
        />

        <h3>Modern parallel, surrender as a regulated nervous system</h3>

        <p>
          What does Bhakti actually do, physiologically? Modern attachment science has begun to answer this. A secure attachment relationship (the felt sense of being held by something larger and reliable) is what regulates the human nervous system. Infants who experience this consistently develop the capacity to self-soothe. Adults who experience this in relationships are measurably calmer, more flexible, more resilient. Bhakti is the spiritual version of this experience: the felt sense that you are held by something that does not let go. It works on the same neural machinery. The devotee who can genuinely place the day in Krishna&apos;s hands is doing what attachment researchers call <em>co-regulation</em>, and it works precisely as it works in a healthy human bond.
        </p>

        <div className="highlight-box">
          <h3>Why Krishna calls Bhakti the easiest path</h3>
          <p>
            Because it does not require you to renounce anything you already have. It does not require silence. It does not require scholarship. It does not require you to fix yourself first. It asks only that you turn, and turn again, toward what you most love. The leaf, the flower, the fruit, the water. The same psyche that was scattered across a hundred small attachments becomes whole when finally pointed at one large one.
          </p>
        </div>

        {/* ── CONVERGENCE ── */}
        <h2 id="where-three-paths-meet">Where the Three Paths Meet</h2>

        <p>
          Once you see all three paths in front of you, the obvious question becomes: are they really separate? Or are they three faces of one thing? Krishna&apos;s answer, across the Gita, is both. They are different enough that a person should not try to walk all three at once. Start with the one that fits your nature. And they are united enough that the deeper you go, the more they begin to flow into each other.
        </p>

        <p>
          The clearest single statement of this is in chapter 7, where Krishna describes the four kinds of people who turn toward him:
        </p>

                <ShlokaCard
          verseRef="Bhagavad Gita 7.16"
          sanskrit="चतुर्विधा भजन्ते मां जनाः सुकृतिनोऽर्जुन । आर्तो जिज्ञासुरर्थार्थी ज्ञानी च भरतर्षभ ॥"
          iast="caturvidhā bhajante māṃ janāḥ sukṛtino'rjuna | ārto jijñāsurarthārthī jñānī ca bharatarṣabha ||"
          meaningLabel="Translation"
          meaning="Four kinds of virtuous people worship me, Arjuna: the distressed, the seeker of knowledge, the one who wants material good, and the wise one, best of the Bharatas."
          insightLabel="All four count"
          insight="Krishna does not say only the wise should approach him. He names the suffering person who comes because the suffering has nowhere else to go. The curious one who comes because the question will not let them rest. The person who wants something concrete and comes asking for it. And the one who has already understood, and comes simply because that is what understanding does. All four are called sukritina: virtuous. The door, Krishna is saying, has many handles, and any of them will open it."
          essence="Different needs lead to one real turning."
        />

        <p>
          And immediately after, Krishna admits something tender: that of these four, one is dearer than the others. Not because the others are unworthy, but because in this one the paths have already fused:
        </p>

                <ShlokaCard
          verseRef="Bhagavad Gita 7.17"
          sanskrit="तेषां ज्ञानी नित्ययुक्त एकभक्तिर्विशिष्यते । प्रियो हि ज्ञानिनोऽत्यर्थमहं स च मम प्रियः ॥"
          iast="teṣāṃ jñānī nityayukta ekabhaktirviśiṣyate | priyo hi jñānino'tyarthamahaṃ sa ca mama priyaḥ ||"
          meaningLabel="Translation"
          meaning="Among these four, the wise devotee, ever united, one-pointed, is distinguished. For I am exceedingly dear to the wise one, and the wise one is dear to me."
          insightLabel="Jnani-bhakta: the wise lover"
          insight="The phrase jnani-bhakta is doing enormous work. It is the seeker in whom Jnana and Bhakti have stopped being separate paths and become one disposition: clear seeing combined with devoted love. Krishna does not name this as a fourth path. He names it as what happens at the end of the other two. Wisdom turns into love; love refines into wisdom. The summit looks the same whether you arrived from the north face or the south."
          essence="Deep knowing and devoted love become a mutual bond."
        />

        <p>
          And in chapter 4, one of the most pluralistic verses Krishna ever delivers, a single line that has carried more spiritual generosity than perhaps any other:
        </p>

                <ShlokaCard
          verseRef="Bhagavad Gita 4.11"
          sanskrit="ये यथा मां प्रपद्यन्ते तांस्तथैव भजाम्यहम् । मम वर्त्मानुवर्तन्ते मनुष्याः पार्थ सर्वशः ॥"
          iast="ye yathā māṃ prapadyante tāṃstathaiva bhajāmyaham | mama vartmānuvartante manuṣyāḥ pārtha sarvaśaḥ ||"
          meaningLabel="Translation"
          meaning="As people approach me, so I respond to them. All people, in every way, follow my path."
          insightLabel="The path adapts to the seeker"
          insight="Krishna is saying: the destination does not change, but the door does. Approach with intellect, and you will be answered with insight. Approach with love, and you will be answered with presence. Approach with work, and the work itself will become your teacher. There is no wrong way in. There is only the way you actually arrive."
          essence="The path you walk is the one that walks back to meet you."
        />

        <p>
          And finally, in chapter 12, the great verse that some have read as a ranking and others as a sequence, but is best read as a description of where each path naturally settles:
        </p>

                <ShlokaCard
          verseRef="Bhagavad Gita 12.12"
          sanskrit="श्रेयो हि ज्ञानमभ्यासाज्ज्ञानाद्ध्यानं विशिष्यते । ध्यानात्कर्मफलत्यागस्त्यागाच्छान्तिरनन्तरम् ॥"
          iast="śreyo hi jñānamabhyāsājjñānāddhyānaṃ viśiṣyate | dhyānātkarmaphalatyāgastyāgācchāntiranantaram ||"
          meaningLabel="Translation"
          meaning="Knowledge is better than mere practice; meditation is better than knowledge. Better than meditation is renouncing the fruits of action. From that renunciation, peace follows at once."
          insightLabel="All three paths in one verse"
          insight="Notice what Krishna does. He moves from abhyasa (practice: Karma Yoga's discipline), to jnana (knowledge: the Jnani's insight), to dhyana (meditation: the inner one-pointedness all three paths develop), to karma-phala-tyaga (renouncing the fruit of action, which is itself the highest form of Karma Yoga, ripened by both Jnana and Bhakti). And the result is not progress; it is shanti anantaram — peace, immediately. The paths are not really competing. They are completing each other."
          essence="Peace begins when you stop clinging to what your action produces. All three paths help you get there."
        />

        <p className="pull-quote">
          The path you can actually walk is more important than the path that sounds most impressive. Krishna&apos;s genius is to have laid out three real roads, and to have said, in his own voice, that he is at the end of every one.
        </p>

        {/* ── MODERN MENTAL HEALTH ── */}
        <h2 id="modern-mental-health">Three Paths, Three Modern Wounds</h2>

        <p>
          The reason Krishna&apos;s three-path structure has survived three millennia is that it is psychologically accurate. Human beings are not uniform, and the things that go wrong inside us are also not uniform. Each of the three paths is a precise response to a recognizable form of modern suffering.
        </p>

        <p>
          <strong>Karma Yoga is the antidote to outcome-anxiety</strong>: the chronic, low-grade fever of needing the next thing to go well before you can breathe. This is the texture of most contemporary professional life. Krishna&apos;s prescription is not to care less; it is to care without holding the result hostage. ACT therapy calls this <em>values clarification</em> and <em>defusion from outcomes</em>. The Gita called it <em>nishkama karma</em> (desireless action) and asked you to fight, but without the fever.
        </p>

        <p>
          <strong>Jnana Yoga is the antidote to rumination</strong>: the looping, self-attacking thought that has become the signature wound of the over-educated, over-introspective modern psyche. The Jnana practice is to step out of the loop by recognizing the watcher. You are not the thought. The thought is something you notice. This is the foundation of metacognitive therapy, the foundation of mindfulness-based cognitive therapy, the foundation of every modern approach that has shown durable results in chronic depression. Krishna gave it the name <em>kshetrajna</em> (the knower of the field) and said clearly that this knowing frees you while life continues.
        </p>

        <p>
          <strong>Bhakti Yoga is the antidote to disconnection</strong>: the loneliness epidemic, the sense of being unheld in the universe, the orphan-feeling of a culture that no longer has a shared sacred. Bhakti is the felt experience of being held. Attachment science now confirms what bhakti traditions always knew: that nervous systems regulate themselves in the presence of secure connection, and that this regulation is not optional. It is a biological requirement for sustained well-being. Krishna&apos;s offer of <em>yogakshema vahami aham</em> (&ldquo;I carry your welfare and security&rdquo;) is not poetry. It is, for those who can receive it, a form of co-regulation that the body responds to. (For a focused reading on what the Gita says about <a href="/blogs/bhagavad-gita-anxiety-mental-peace" style={{ color: 'var(--gold-light)', borderBottom: '1px solid rgba(200,136,30,0.35)' }}>anxiety and mental peace</a>, we have a separate piece.)
        </p>

        <p>
          The Gita does not say one of these wounds is more important. It says they are different wounds, in different people, and that the medicine has to fit. The mistake most spiritual seekers make, and most therapists make, and most teachers make, is to assume one answer for everyone. Krishna&apos;s answer is more honest: three answers, depending on who is asking.
        </p>

        {/* ── WHICH PATH IS YOURS ── */}
        <h2 id="which-path-is-yours">Which Path Is Yours?</h2>

        <p>
          A useful diagnostic, drawn from how the Gita itself describes the temperaments: notice what your restlessness wants.
        </p>

        <p>
          If your restlessness wants to <em>do</em>, if sitting still is the hardest thing, if your relief comes from solving something, building something, finishing something, your path likely begins with <strong>Karma Yoga</strong>. The discipline is not to do less. It is to keep doing, fully, while progressively letting go of the part of you that demands a particular result. The verse to live with is 2.47.
        </p>

        <p>
          If your restlessness wants to <em>understand</em>, if you cannot put a question down until it has been answered properly, if your relief comes from a model that finally fits, from a piece of language that finally lands, your path likely begins with <strong>Jnana Yoga</strong>. The discipline is to keep questioning, but to turn the question inward at the questioner. The verse to live with is 13.24.
        </p>

        <p>
          If your restlessness wants to <em>belong</em>, if you feel deeply, if connection is what makes you feel real, if you are most yourself when you are in love with something or someone, your path likely begins with <strong>Bhakti Yoga</strong>. The discipline is to refine that love until it lands on something that can actually hold it. The verse to live with is 9.22.
        </p>

        <p>
          And then, as Krishna promises in 4.11, the path you walk will start to walk back to meet you. The Karma Yogi will, in time, find that their work has become contemplative. The Jnani will find that their clarity has become tender. The Bhakta will find that their love has become wise. The three paths converge, not because you forced them to, but because at the summit, the view from any side is the same.
        </p>

        {/* ── WISDOM APP CONNECTION ── */}
        <h2 id="wisdom-app-three-paths">The Three Paths, Rebuilt for a Modern Practice</h2>

        <p>
          Everything above is theory until you do something with it. The Wisdom app exists because Krishna&apos;s three paths are too important to leave in the abstract, and because the modern reader rarely has a guru to ask which path is theirs.
        </p>

        <p>
          Inside Wisdom, the three paths are not just an idea. They are the structure of the app. When you begin, you are placed on the path that fits your temperament: the Path of Action, the Path of Wisdom, or the Path of Devotion. Each path is a sequence of nodes: Stillness, Witness and Gyan Mastery on the Path of Wisdom; Trust, Devotion and Bhakti Mastery on the Path of Devotion; the corresponding discipline nodes on the Path of Action. Each node is a short daily practice, a verse from the Bhagavad Gita or a related scripture paired with a two-minute reflection, that moves you a little further along the road Krishna laid out.
        </p>

        <p>
          You begin with the path that fits you. As you deepen, you can move between paths, because, as Krishna himself says in 7.17, the seeker who has gathered both wisdom and devotion is the one closest to him. The architecture of the app is not invented. It is the architecture of the Gita itself, made walkable.
        </p>

        <VerseFunnelCTA variant="chapter" locale="en" pageName={"Krishna Three Paths"} />

        <h2>A Closing Thought</h2>

        <p>
          The Gita does not end with chapter 18 because Krishna ran out of things to say. It ends because at some point, the seeker has to put the book down and walk. The three paths are not a menu to study; they are roads to walk. The road you choose matters less than the walking itself. Krishna&apos;s assurance, and the assurance of Tulsidas eight centuries later and of every teacher in this tradition, is the same: the destination is real, the paths to it are many, and the one who walks any of them with sincerity does not arrive alone.
        </p>

        <p>
          <em>Hoihi soi jo Rama rachi rakha.</em> Whatever will happen, has already been scripted. Your job is only to walk, and to choose the road on which the walking feels most like yourself.
        </p>

        <h2 id="related-reading">Related Reading on the Three Paths</h2>
        <p>If you want to go deeper into any one of the three paths individually, the long-form chapter studies and topic guides below pick up where this overview leaves off.</p>
        <ul style={{ listStyle: 'none', padding: 0, marginBottom: '2rem' }}>
          <li style={{ padding: '0.7rem 0', borderBottom: '1px solid var(--border)' }}>
            <a href="/blogs/bhagwat-geeta-chapter-3" style={{ color: 'var(--gold-light)', fontWeight: 600 }}>Bhagavad Gita Chapter 3, Karma Yoga, &ldquo;Why You Cannot Run&rdquo;</a>
            <span style={{ color: 'var(--text-dim)', fontSize: '0.92rem', display: 'block', marginTop: '0.25rem' }}>The full chapter on action: yajna, lokasamgraha, and why desire is the real enemy.</span>
          </li>
          <li style={{ padding: '0.7rem 0', borderBottom: '1px solid var(--border)' }}>
            <a href="/blogs/bhagwat-geeta-chapter-4" style={{ color: 'var(--gold-light)', fontWeight: 600 }}>Bhagavad Gita Chapter 4, Jnana Yoga, &ldquo;The Fire That Burns Karma&rdquo;</a>
            <span style={{ color: 'var(--text-dim)', fontSize: '0.92rem', display: 'block', marginTop: '0.25rem' }}>Knowledge as the highest offering, and the Gita&apos;s model for how to learn from a real teacher.</span>
          </li>
          <li style={{ padding: '0.7rem 0', borderBottom: '1px solid var(--border)' }}>
            <a href="/blogs/bhagwat-geeta-chapter-12" style={{ color: 'var(--gold-light)', fontWeight: 600 }}>Bhagavad Gita Chapter 12, Bhakti Yoga, &ldquo;How a Devotee Actually Lives&rdquo;</a>
            <span style={{ color: 'var(--text-dim)', fontSize: '0.92rem', display: 'block', marginTop: '0.25rem' }}>The shortest chapter, and one of the most practical. The four-step ladder for when meditation is too hard.</span>
          </li>
          <li style={{ padding: '0.7rem 0', borderBottom: '1px solid var(--border)' }}>
            <a href="/blogs/bhagwat-geeta-chapter-18" style={{ color: 'var(--gold-light)', fontWeight: 600 }}>Bhagavad Gita Chapter 18, Moksha Sannyasa Yoga</a>
            <span style={{ color: 'var(--text-dim)', fontSize: '0.92rem', display: 'block', marginTop: '0.25rem' }}>The closing chapter, including 18.66, the Gita&apos;s final teaching on surrender.</span>
          </li>
          <li style={{ padding: '0.7rem 0', borderBottom: '1px solid var(--border)' }}>
            <a href="/blogs/bhagavad-gita-karma-meaning" style={{ color: 'var(--gold-light)', fontWeight: 600 }}>What Karma Actually Means in the Bhagavad Gita</a>
            <span style={{ color: 'var(--text-dim)', fontSize: '0.92rem', display: 'block', marginTop: '0.25rem' }}>Karma doesn&apos;t mean &ldquo;what goes around comes around.&rdquo; Here is the real definition.</span>
          </li>
          <li style={{ padding: '0.7rem 0', borderBottom: '1px solid var(--border)' }}>
            <a href="/blogs/bhagavad-gita-anxiety-mental-peace" style={{ color: 'var(--gold-light)', fontWeight: 600 }}>What the Gita Says About Anxiety &amp; Mental Peace</a>
            <span style={{ color: 'var(--text-dim)', fontSize: '0.92rem', display: 'block', marginTop: '0.25rem' }}>A focused reading for those approaching the Gita through the door of psychological suffering.</span>
          </li>
          <li style={{ padding: '0.7rem 0', borderBottom: '1px solid var(--border)' }}>
            <a href="/blogs/beyond-bhagavad-gita-quotes-mental-spiritual-health" style={{ color: 'var(--gold-light)', fontWeight: 600 }}>Beyond the Bhagavad Gita, 7 Lesser-Known Gitas on Inner Peace</a>
            <span style={{ color: 'var(--text-dim)', fontSize: '0.92rem', display: 'block', marginTop: '0.25rem' }}>Ashtavakra, Avadhuta, Ram Gita and more: the wider Jnana tradition the chapter above draws from.</span>
          </li>
          <li style={{ padding: '0.7rem 0', borderBottom: '1px solid var(--border)' }}>
            <a href="/blogs/bhagavad-gita-complete-structure-all-chapters" style={{ color: 'var(--gold-light)', fontWeight: 600 }}>The Bhagavad Gita as a Story, How Krishna Builds His Argument</a>
            <span style={{ color: 'var(--text-dim)', fontSize: '0.92rem', display: 'block', marginTop: '0.25rem' }}>The structural arc of all 18 chapters, how the three paths unfold across the text.</span>
          </li>
          <li style={{ padding: '0.7rem 0' }}>
            <a href="/blogs/bhagavad-gita-for-beginners" style={{ color: 'var(--gold-light)', fontWeight: 600 }}>Bhagavad Gita for Beginners, Where to Start</a>
            <span style={{ color: 'var(--text-dim)', fontSize: '0.92rem', display: 'block', marginTop: '0.25rem' }}>700 verses, 18 chapters. A no-nonsense guide for the first-time reader.</span>
          </li>
        </ul>
      </div>

      </article>

      {/* FAQ */}

      <FeedbackWidget pageType="blog" />
      <section className="faq-section" itemScope itemType="https://schema.org/FAQPage" aria-labelledby="faq-heading">
        <h2 id="faq-heading">Frequently Asked Questions</h2>

        <div className="faq-item">
          <strong>What are the three paths Krishna teaches in the Bhagavad Gita?</strong>
          <p>Krishna lays out three converging paths: <em>Karma Yoga</em> (the path of selfless action); <em>Jnana Yoga</em> (the path of knowledge and self-inquiry); and <em>Bhakti Yoga</em> (the path of devotion and surrender). All three lead to the same supreme reality, but each is shaped for a different temperament. The doer, the thinker, and the lover each have their own road home.</p>
        </div>

        <div className="faq-item">
          <strong>Why does Krishna give three paths instead of one?</strong>
          <p>Because human beings differ. Some are restless doers, some restless thinkers, some restless feelers. Krishna meets each personality where it is. In 4.11 he says directly: <em>in whatever way people approach me, in that way I respond to them</em>. The truth is one; the doors are many.</p>
        </div>

        <div className="faq-item">
          <strong>Which of the three paths is the highest?</strong>
          <p>Krishna does not establish a flat hierarchy. In 12.12 he names a sequence (practice, knowledge, meditation, renunciation of fruit) and says peace follows immediately from that renunciation. In 7.17 he calls the <em>jnani-bhakta</em>, the wise lover, dearest. In 18.66 he calls surrender the final teaching. The paths complete each other; they do not compete.</p>
        </div>

        <div className="faq-item">
          <strong>How does Tulsidas&apos;s &ldquo;karm pradhan&rdquo; verse relate to the Gita&apos;s Karma Yoga?</strong>
          <p>Tulsidas writes <em>karam pradhan bisva kari rakha, jo jas karai so tas phalu chakha</em>: the world is governed by action; whoever does what, tastes the fruit accordingly. This is the law of karma in Awadhi. It is the same teaching Krishna gives in 2.47: action belongs to you and shapes you, even when the fruit does not. Tulsidas&apos;s couplet and Krishna&apos;s sutra are saying the same thing in different languages, eight centuries apart.</p>
        </div>

        <div className="faq-item">
          <strong>What does &ldquo;hoihi soi jo Rama rachi rakha&rdquo; mean and how does it connect to surrender in the Gita?</strong>
          <p>Tulsidas writes <em>hoihi soi jo rama rachi rakha, ko kari tarka badhavai sakha</em>: only that will happen which Rama has scripted; who can extend the branches of argument? This is the Ramcharitmanas form of Krishna&apos;s teaching in 11.33 (<em>they have already been killed by me; become only the instrument</em>) and in 18.66, <em>take refuge in me alone</em>. Argument ends; surrender begins. The same teaching, in two scriptures.</p>
        </div>

        <div className="faq-item">
          <strong>How do the three paths connect to modern mental health?</strong>
          <p>Karma Yoga maps onto value-driven action over outcome-anxiety, the central insight of Acceptance and Commitment Therapy. Jnana Yoga is the witness-perspective that breaks rumination, the foundation of metacognitive therapy and Buddhist mindfulness. Bhakti Yoga is surrender as a secure base, the experience of being held, which modern attachment science now confirms regulates the nervous system. Each path addresses a different modern wound.</p>
        </div>

        <div className="faq-item">
          <strong>How do I know which path is mine?</strong>
          <p>Notice what your restlessness wants. If you cannot sit still and need to <em>do</em>, your path likely begins with action. If you cannot stop questioning and need to <em>understand</em>, your path begins with knowledge. If you feel deeply and need to be in <em>relationship</em>, your path begins with devotion. The path you naturally walk is the one that will carry you furthest. And, as Krishna says, the deeper you go, the more the other two will open from inside.</p>
        </div>
      </section>

      <footer>
        <p>© 2026 Wisdom App. Three paths, one summit. Bhagavad Gita, tuned to your life.</p>
        <p><a href="https://wisdomquotes.in">Home</a> · <a href="https://wisdomquotes.in/blogs">Blog</a> · <a href={appStoreUrl('web_blog_footer')} target="_blank" rel="noopener" data-mp-location="footer">Download</a></p>
      </footer>

      <BlogTracker pageName="Krishna Three Paths" />
    </>
  )
}
