import type { Metadata } from 'next'
import BlogTracker from '@/components/BlogTracker'
import FeedbackWidget from '@/components/FeedbackWidget'
import ShlokaCard from '@/components/gita/ShlokaCard'
import VerseFunnelCTA from '@/components/funnel/VerseFunnelCTA'
import { appStoreUrl } from '@/lib/app'

export const metadata: Metadata = {
  title: "Dharma in the Bhagavad Gita: What It Means and Why It's Not What You Think",
  description: "Dharma doesn't mean duty or religion. In the Gita, it's closer to 'your own nature, acted on.' Svadharma, the dharma of the self, is Krishna's answer to Arjuna's paralysis. Here's what the Gita actually says.",
  keywords: "dharma meaning bhagavad gita, what is dharma in gita, svadharma meaning, dharma in hinduism gita, types of dharma bhagavad gita, dharma vs adharma gita, bhagavad gita 3.35 svadharma, bhagavad gita 4.7 dharma, bhagavad gita 18.47 svadharma, dharma definition hindi",
  openGraph: {
    title: "Dharma in the Bhagavad Gita: What It Means and Why It's Not What You Think | Wisdom",
    description: "Dharma doesn't mean duty or religion. In the Gita, it's closer to 'your own nature, acted on.' Svadharma is Krishna's answer to Arjuna's paralysis. Here's what the Gita actually says.",
    type: 'article',
    url: "https://wisdomquotes.in/blogs/dharma-meaning-bhagavad-gita",
    siteName: 'Wisdom',
    images: [{ url: 'https://wisdomquotes.in/og-image.webp', width: 1200, height: 630 }],
  },
  twitter: {
    card: 'summary_large_image',
    site: '@sansearchapp',
    creator: '@thisisashukla',
    title: "Dharma in the Bhagavad Gita: What It Means and Why It's Not What You Think | Wisdom",
    description: "Dharma doesn't mean duty or religion. In the Gita, it's closer to 'your own nature, acted on.' Svadharma is Krishna's answer to Arjuna's paralysis. Here's what the Gita actually says.",
    images: ['https://wisdomquotes.in/og-image.webp'],
  },
  alternates: {
    canonical: "https://wisdomquotes.in/blogs/dharma-meaning-bhagavad-gita",
    languages: {
      'en': "https://wisdomquotes.in/blogs/dharma-meaning-bhagavad-gita",
      'en-IN': "https://wisdomquotes.in/blogs/dharma-meaning-bhagavad-gita",
      'x-default': "https://wisdomquotes.in/blogs/dharma-meaning-bhagavad-gita",
    },
  },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, 'max-image-preview': 'large', 'max-snippet': -1 },
  },
}

const pageCSS = `

        :root {
            --maroon: #3d0c0c;
            --maroon-mid: #5c1a1a;
            --gold: #c8881e;
            --gold-light: #f5c96a;
            --gold-pale: #fdf3dc;
            --gold-border: #e8c97a;
            --gold-dim: rgba(200,136,30,0.15);
            --text: #f5e8cc;
            --text-dim: rgba(245,232,204,0.65);
            --text-dimmer: rgba(245,232,204,0.35);
            --muted-2: rgba(245,232,204,0.35);
            --border: rgba(200,136,30,0.2);
            --bg: #120505;
            --bg-warm: #190707;
            --bg-alt: #0f0404;
            --bg-card: rgba(255,255,255,0.04);
            --bg-card-hover: rgba(255,255,255,0.07);
            --max: 780px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: var(--bg);
            color: var(--text);
            font-family: 'Inter', sans-serif;
            line-height: 1.7;
            font-size: 16px;
        }

        /* ── BREADCRUMB ── */
        .breadcrumb {
            background: var(--bg-alt);
            border-bottom: 1px solid var(--border);
        }
        .breadcrumb-inner {
            max-width: 1100px;
            margin: 0 auto;
            padding: 10px 28px;
            font-size: 12px;
            color: var(--text-dimmer);
            display: flex;
            gap: 8px;
            align-items: center;
        }
        .breadcrumb-inner a { color: var(--text-dimmer); transition: color 0.15s; }
        .breadcrumb-inner a:hover { color: var(--gold-light); }
        .bc-sep { opacity: 0.4; }

        /* ── ARTICLE HERO ── */
        .article-hero {
            background: var(--bg-warm);
            padding: 64px 28px 56px;
            border-bottom: 1px solid var(--border);
            position: relative;
            overflow: hidden;
        }
        .article-hero::before {
            content: "धर्म";
            position: absolute;
            right: -10px;
            bottom: -30px;
            font-family: "Noto Sans Devanagari", serif;
            font-size: 220px;
            color: rgba(200, 136, 30, 0.04);
            line-height: 1;
            pointer-events: none;
            user-select: none;
        }
        .article-hero-inner { max-width: 1100px; margin: 0 auto; position: relative; z-index: 2; }
        .chapter-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: rgba(200, 136, 30, 0.1);
            border: 1px solid rgba(200, 136, 30, 0.28);
            color: var(--gold-light);
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 0.12em;
            text-transform: uppercase;
            padding: 5px 14px;
            border-radius: 100px;
            margin-bottom: 20px;
        }
        .chapter-badge-dot {
            width: 5px;
            height: 5px;
            border-radius: 50%;
            background: var(--gold);
            box-shadow: 0 0 6px var(--gold);
            flex-shrink: 0;
        }
        h1.article-title {
            font-family: "Playfair Display", Georgia, serif;
            font-size: clamp(28px, 4vw, 48px);
            font-weight: 700;
            color: var(--gold-light);
            line-height: 1.15;
            letter-spacing: -0.5px;
            margin-bottom: 14px;
        }
        h1.article-title em { font-style: italic; color: #fff; }
        .article-subtitle {
            font-size: 17px;
            color: var(--text-dim);
            font-weight: 300;
            margin-bottom: 32px;
            line-height: 1.65;
            max-width: 620px;
        }
        .article-meta { display: flex; align-items: center; gap: 16px; flex-wrap: wrap; }
        .meta-item { font-size: 12px; color: var(--text-dimmer); letter-spacing: 0.04em; }
        .meta-sep { color: var(--border); }

        .lead {
            font-size: 1.1rem;
            color: var(--text-dim);
            margin-bottom: 2rem;
            line-height: 1.8;
        }

        /* CHAPTER IMAGE */
        .chapter-image {
            margin: 32px 0 36px;
            border-radius: 14px;
            overflow: hidden;
            border: 1px solid var(--border);
            box-shadow: 0 4px 32px rgba(0,0,0,0.4);
        }
        .chapter-image img {
            width: 100%;
            height: auto;
            display: block;
            object-fit: cover;
        }
        .chapter-image figcaption {
            padding: 10px 18px;
            background: var(--bg-card);
            font-size: 11.5px;
            color: var(--text-dimmer);
            letter-spacing: 0.04em;
            font-style: italic;
            border-top: 1px solid var(--border);
        }

        /* Main Content */
        .content {
            max-width: var(--max);
            margin: 0 auto;
            padding: 0 2rem 4rem;
        }

        h2 {
            font-family: 'Playfair Display', serif;
            font-size: 1.8rem;
            font-weight: 700;
            margin: 2.5rem 0 1.5rem 0;
            color: var(--gold);
            border-bottom: 2px solid var(--gold-dim);
            padding-bottom: 0.75rem;
        }

        h3 {
            font-family: 'Playfair Display', serif;
            font-size: 1.3rem;
            font-weight: 600;
            margin: 1.5rem 0 1rem 0;
            color: var(--text);
        }

        p {
            margin-bottom: 1.5rem;
            color: var(--text-dim);
        }

        /* Pull Quote */
        .pull-quote {
            border-left: 4px solid var(--gold);
            padding-left: 2rem;
            margin: 2.5rem 0;
            font-size: 1.15rem;
            color: var(--gold-light);
            font-style: italic;
            line-height: 1.8;
        }

        /* Highlight Box */
        .highlight-box {
            background: var(--gold-dim);
            border: 1px solid var(--gold-border);
            padding: 1.5rem;
            border-radius: 8px;
            margin: 2rem 0;
        }

        .highlight-box h3 {
            color: var(--gold);
            margin-top: 0;
        }

        .highlight-box p {
            color: var(--text);
            margin-bottom: 0.75rem;
        }

        /* FAQ Section */
        .faq-section {
            max-width: var(--max);
            margin: 3rem auto;
            padding: 0 2rem;
        }

        .faq-item {
            margin-bottom: 2rem;
            border-bottom: 1px solid var(--border);
            padding-bottom: 2rem;
        }

        .faq-item:last-child {
            border-bottom: none;
        }

        .faq-item strong {
            color: var(--gold-light);
            font-size: 1.05rem;
        }

        .faq-item p {
            margin-top: 0.75rem;
        }

        /* ── APP CTA ── */
        .app-cta {
          background: linear-gradient(160deg, #2d0a0a 0%, #1a0606 100%);
          border: 1px solid rgba(200, 136, 30, 0.25);
          border-top: 3px solid var(--gold);
          border-radius: 20px;
          padding: 44px 48px 40px;
          margin: 48px 0 60px;
          text-align: center;
          position: relative;
          overflow: hidden;
        }
        .app-cta::before {
          content: "ज्ञान";
          position: absolute;
          top: -14px;
          right: -8px;
          font-family: "Noto Sans Devanagari", sans-serif;
          font-size: 130px;
          color: rgba(200, 136, 30, 0.05);
          line-height: 1;
          pointer-events: none;
          user-select: none;
        }
        .app-cta-eyebrow {
          display: inline-flex;
          align-items: center;
          background: rgba(200, 136, 30, 0.12);
          border: 1px solid rgba(200, 136, 30, 0.35);
          color: var(--gold-light);
          font-size: 11px;
          font-weight: 600;
          letter-spacing: 0.14em;
          text-transform: uppercase;
          padding: 5px 14px;
          border-radius: 20px;
          margin-bottom: 20px;
        }
        .app-cta-headline {
          font-family: "Playfair Display", serif;
          font-size: clamp(22px, 3vw, 30px);
          font-weight: 700;
          color: var(--text);
          line-height: 1.25;
          margin-bottom: 14px;
        }
        .app-cta-desc {
          font-size: 15px;
          color: var(--text-dim);
          line-height: 1.7;
          max-width: 480px;
          margin: 0 auto 22px;
        }
        .app-cta-features {
          display: flex;
          gap: 6px 18px;
          justify-content: center;
          flex-wrap: wrap;
          margin-bottom: 28px;
        }
        .app-cta-features span {
          font-size: 13px;
          color: var(--gold-light);
          opacity: 0.8;
        }
        .app-cta-btn {
          display: inline-flex;
          align-items: center;
          gap: 10px;
          background: var(--gold);
          color: #120505;
          text-decoration: none;
          padding: 15px 34px;
          border-radius: 12px;
          font-size: 16px;
          font-weight: 700;
          letter-spacing: -0.01em;
          transition: all 0.2s;
          box-shadow: 0 4px 22px rgba(200, 136, 30, 0.3);
        }
        .app-cta-btn:hover {
          background: var(--gold-light);
          transform: translateY(-2px);
          box-shadow: 0 8px 32px rgba(200, 136, 30, 0.5);
        }
        .app-cta-sub {
          font-size: 12px;
          color: rgba(245, 232, 204, 0.35);
          margin-top: 14px;
          letter-spacing: 0.04em;
        }

        /* Footer */
        footer {
            background: var(--bg-warm);
            border-top: 1px solid var(--border);
            padding: 3rem 2rem;
            text-align: center;
            color: var(--text-dimmer);
            margin-top: 4rem;
        }

        footer a {
            color: var(--gold);
            text-decoration: none;
        }

        footer a:hover {
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            .article-hero { padding: 44px 20px 40px; }

            h2 {
                font-size: 1.5rem;
            }

        }

`

const schemas = [
  {
    "@context": "https://schema.org",
    "@type": "Article",
    "headline": "Dharma in the Bhagavad Gita: What It Means and Why It's Not What You Think | Wisdom",
    "description": "Dharma doesn't mean duty or religion. In the Gita, it's closer to your own nature, acted on. Svadharma is Krishna's answer to Arjuna's paralysis.",
    "datePublished": "2026-06-12",
    "dateModified": "2026-08-01",
    "mainEntityOfPage": { "@type": "WebPage", "@id": "https://wisdomquotes.in/blogs/dharma-meaning-bhagavad-gita" },
    "author": {
      "@type": "Person",
      "name": "Ankur Shukla",
      "url": "https://wisdomquotes.in/about",
      "sameAs": [
        "https://www.linkedin.com/in/thisisashukla/",
        "https://x.com/thisisashukla"
      ]
    },
    "publisher": {
      "@type": "Organization",
      "name": "Wisdom",
      "url": "https://wisdomquotes.in",
      "logo": { "@type": "ImageObject", "url": "https://wisdomquotes.in/assets/new-light-logo.webp" }
    }
  },
  {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [
      { "@type": "ListItem", "position": 1, "name": "Wisdom", "item": "https://wisdomquotes.in" },
      { "@type": "ListItem", "position": 2, "name": "Blog", "item": "https://wisdomquotes.in/blogs" },
      { "@type": "ListItem", "position": 3, "name": "Dharma in the Bhagavad Gita", "item": "https://wisdomquotes.in/blogs/dharma-meaning-bhagavad-gita" }
    ]
  },
  {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": "What is dharma in the Bhagavad Gita?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Dharma in the Gita comes from the Sanskrit root dhr, to hold or sustain. It is what holds a thing's essential nature in place. The Gita uses it in several registers: cosmic order (rita), universal law (sanatana dharma), social role-based duties (varna dharma), and individual nature-based duty (svadharma). Most of the Gita's practical teaching is about svadharma: the path that arises from your own nature."
        }
      },
      {
        "@type": "Question",
        "name": "What is svadharma?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Svadharma means your own dharma, the action and way of life that accords with your own nature (svabhava). BG 3.35 and BG 18.47 both state that it is better to perform your own dharma imperfectly than another's perfectly. Svadharma is not a career or a role assigned from outside. It is the quality of action that arises when you act from your deepest nature rather than from imitation or fear."
        }
      },
      {
        "@type": "Question",
        "name": "What does the Bhagavad Gita say about dharma and adharma?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "The Gita opens on dharma-kshetra, the field of dharma. Adharma is what opposes or erodes dharma. BG 4.7 says that whenever dharma declines and adharma rises, Krishna takes form to restore balance. The Gita's framing is that dharma needs to be actively upheld, and that when it weakens, correction comes. Arjuna's paralysis at the start of the Gita is itself a form of adharma: a warrior refusing the action his nature and position require."
        }
      },
      {
        "@type": "Question",
        "name": "Is dharma the same as duty?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Duty is a common English translation but it carries the wrong connotations. Duty implies an external obligation, something imposed from outside that you must fulfill regardless of your nature. Dharma is closer to your nature's requirement: what you must do because of what you are, not because someone told you to. A fire's dharma is to burn upward. Water's dharma is to flow downward. These are not duties imposed on fire and water. They are expressions of their nature."
        }
      },
      {
        "@type": "Question",
        "name": "What does dharma-kshetra mean in the Bhagavad Gita?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Dharma-kshetra is the first word of the Gita: the field of dharma. Kurukshetra, the battlefield, is called dharma-kshetra. The choice of this word at the opening is deliberate. The Gita is framing the entire conflict not as a battle over territory or inheritance but as a confrontation over dharma. The battlefield is the place where dharma gets tested, decided, and either upheld or abandoned."
        }
      }
    ]
  }
]

export default function DharmaMeaningPage() {
  return (
    <>
      <style dangerouslySetInnerHTML={{ __html: pageCSS }} />
      {schemas.map((s, i) => (
        <script key={i} type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(s) }} />
      ))}

      <div className="breadcrumb">
        <div className="breadcrumb-inner">
          <a href="/">Wisdom</a>
          <span className="bc-sep">/</span>
          <a href="/blogs">Blog</a>
          <span className="bc-sep">/</span>
          Dharma in the Gita
        </div>
      </div>

      <div className="article-hero">
        <div className="article-hero-inner">
          <div className="chapter-badge">
            <div className="chapter-badge-dot"></div>
            Bhagavad Gita · Core Teaching
            <div className="chapter-badge-dot"></div>
          </div>
          <h1 className="article-title">
            Dharma: What the Gita Means by It<br />
            <em>(And What It Doesn&apos;t)</em>
          </h1>
          <p className="article-subtitle">
            The word dharma appears 72 times in the Gita. It never quite means &ldquo;duty.&rdquo; It is closer to: what holds. What sustains the structure of things. And for each person, what their own nature requires of them.
          </p>
          <div className="article-meta">
            <span className="meta-item">By <a href="/about" rel="author" data-mp-location="byline_author" style={{ color: 'var(--gold-light)', borderBottom: '1px solid rgba(200,136,30,0.35)' }}>Ankur Shukla</a></span>
            <span className="meta-sep">·</span>
            <span className="meta-item">Core Teaching · Dharma</span>
            <span className="meta-sep">·</span>
            <span className="meta-item">~6 min read</span>
            <span className="meta-sep">·</span>
            <span className="meta-item">Chapters 1, 3, 4 & 18</span>
            <span className="meta-sep">·</span>
            <span className="meta-item" style={{ fontStyle: 'italic' }}>Wisdom translation, edited by Ankur Shukla. Commentary AI-drafted, human-reviewed. Reviewed June 2026. <a href="/methodology" style={{ color: 'var(--gold-light)', borderBottom: '1px solid rgba(200,136,30,0.3)' }}>Methodology →</a></span>
          </div>
        </div>
      </div>

      <div className="content">
        <figure className="chapter-image">
          <img
            src="/assets/chapter4.webp"
            alt="Krishna teaching Arjuna about dharma on the battlefield of Kurukshetra"
            width="1200"
            height="675"
            loading="eager"
            fetchPriority="high"
          />
          <figcaption>Dharma: the teaching that holds the Gita together</figcaption>
        </figure>

        <p className="lead">
          The word dharma comes from the Sanskrit root dhr, to hold or sustain. Dharma is what holds. What maintains the structure of things. It is the nature of water to flow downward. It is the nature of fire to burn upward. That is dharma. The Gita uses the word in at least four different registers, and most of the confusion about what it means comes from collapsing all four into one.
        </p>

        <h2>Why &ldquo;Duty&rdquo; Is the Wrong Translation</h2>
        <p>
          The standard English rendering of dharma is &ldquo;duty,&rdquo; and it causes real damage to the text. Duty implies an external obligation: something imposed from outside, a rule you must follow, a role assigned to you by someone else. If you perform your duty, you have done what you were told. If you shirk it, you have failed.
        </p>
        <p>
          Dharma works differently. A fire&apos;s dharma is to burn upward. This is not a rule imposed on fire. It is a description of fire&apos;s nature. Fire that burned downward would not be failing its duty. It would be a different kind of thing entirely, or nothing at all. The dharma of a thing is what that thing genuinely is, expressed in action.
        </p>
        <p>
          For a person, this gets more complex. Dharma is not static. It shifts with role, stage of life, circumstance. But at its core, the Gita is asking: what does your actual nature require of you? That is closer to dharma than any external obligation is.
        </p>

        <div className="highlight-box">
          <h3>The Four Registers of Dharma in the Gita</h3>
          <p>
            Sanatana dharma is universal moral and cosmic order, the laws that hold the universe in coherence. Rita dharma is the rhythm of natural law. Varna dharma is role-based duty tied to social function and stage of life. Svadharma is the dharma specific to you, arising from your own nature and not transferable to anyone else.
          </p>
          <p>
            The Gita is interested in all four but most urgently in the last one. Arjuna&apos;s crisis is a svadharma crisis. And Krishna&apos;s answer is a svadharma answer.
          </p>
        </div>

        <h2>Sanatana Dharma vs. Svadharma</h2>
        <p>
          Sanatana dharma is sometimes translated as &ldquo;eternal religion&rdquo; or &ldquo;universal law.&rdquo; It describes the underlying moral structure of the cosmos, the principles that apply regardless of time, place, or person. Honesty is part of sanatana dharma. Non-cruelty is part of sanatana dharma. These are not negotiable on the basis of circumstance.
        </p>
        <p>
          Svadharma is different. It is specific. It is yours. The Gita&apos;s word for your own nature is svabhava, and svadharma flows from svabhava. If your svabhava tends toward precision, care, and structure, your svadharma probably looks different from someone whose svabhava tends toward boldness, confrontation, and leadership. Same cosmic order. Different individual expressions.
        </p>
        <p>
          The tension the Gita keeps returning to is between these two: what does your individual nature require, versus what does the universal order require? In most cases they align. When they appear to conflict, the Gita&apos;s instruction is usually to go deeper into svadharma, not to abandon it for a borrowed version of virtue.
        </p>

        <h2>BG 3.35: Better Your Own Path, Imperfect</h2>
        <p>
          The clearest statement of svadharma in the Gita comes in Chapter 3. It is blunt. It admits imperfection. It does not promise that walking your own path will produce better results.
        </p>

                <ShlokaCard
          verseRef="Bhagavad Gita 3.35"
          sanskrit="श्रेयान्स्वधर्मो विगुणः परधर्मात्स्वनुष्ठितात् । स्वधर्मे निधनं श्रेयः परधर्मो भयावहः ॥"
          iast="śreyānsvadharmo viguṇaḥ paradharmātsvanuṣṭhitāt | svadharme nidhanaṃ śreyaḥ paradharmo bhayāvahaḥ ||"
          meaningLabel="Translation"
          meaning="It is better to perform your own dharma, even if imperfectly, than to carry out another's dharma perfectly. Dying while following your own dharma is better, because living by another's dharma brings fear."
          insightLabel="What This Teaches"
          insight="The verse uses the word viguna: deficient in qualities, imperfect. The Gita is not saying follow your dharma because you will do it better than anyone else. It is saying follow it even when you are not doing it well. Even a flawed walk down your own path is better than a flawless performance of someone else's. The reason it gives is fear. Paradharma, living another's path, generates bhaya. Fear. The fear of being found out. The fear of not measuring up. The fear of a life that doesn't actually fit."
          essence="Walk your own path, for it alone leads to lasting well-being."
        />

        <p>
          This is striking in a culture that values visible success. The verse is not measuring outcomes. It is measuring the quality of the life from the inside. A life spent performing another&apos;s dharma well produces a particular kind of interior damage: you become skilled at something that was never yours, and you live in constant low-level fear of the gap between your performance and your actual nature.
        </p>

        <h2>Dharma as the Battleground: BG 1.1</h2>
        <p>
          The Gita&apos;s very first word is dharmakshetra: the field of dharma. The battlefield at Kurukshetra is named this way. The choice is deliberate. What is about to happen is not simply a war over territory or inheritance. It is a confrontation over dharma itself.
        </p>
        <p>
          Dhritarashtra&apos;s question at the opening &mdash; what did the sons of Pandu and my people do on the dharma-field? &mdash; is not merely logistical. He is asking: on the field where dharma gets decided, who is standing and who is falling? The answer he will receive is the entire Bhagavad Gita.
        </p>
        <p>
          The setting matters because it locates the Gita&apos;s teaching in the most extreme version of a dharma crisis. Arjuna is a warrior. His role, his training, his entire life up to this moment have been preparation for this kind of situation. And at the moment of actual combat, he puts down his bow. This is not cowardice in the ordinary sense. Arjuna is fully capable of fighting. He is refusing because he cannot see his way to a dharma that covers what he is being asked to do.
        </p>

        <div className="pull-quote">
          The battlefield is not incidental to the teaching. The teaching happens here because this is where dharma gets tested, not in comfortable conditions.
        </div>

        <h2>When Dharma Declines: BG 4.7 and 4.8</h2>
        <p>
          Chapter 4 introduces the cosmic dimension of dharma. Krishna describes a pattern that operates across ages: dharma declines, adharma rises, and Krishna takes form to restore the balance.
        </p>

                <ShlokaCard
          verseRef="Bhagavad Gita 4.7"
          sanskrit="यदा यदा हि धर्मस्य ग्लानिर्भवति भारत । अभ्युत्थानमधर्मस्य तदाऽऽत्मानं सृजाम्यहम् ॥"
          iast="yadā yadā hi dharmasya glānirbhavati bhārata | abhyutthānamadharmasya tadā''tmānaṃ sṛjāmyaham ||"
          meaningLabel="Translation"
          meaning="Whenever dharma weakens and adharma increases, O Arjuna, I manifest myself in visible form."
          insightLabel="What This Teaches"
          insight="The word glani means deterioration, weakness, fatigue. Dharma can get tired. It can be worn down by sustained adharma until it loses its coherence as a force in the world. Krishna's response is not to send a message or a law. He comes himself. This is the theology of the avatar: when the situation requires it, the divine takes on the limitation of form in order to act within the specific conditions of the world."
          essence="Whenever dharma weakens, renewal comes. Trust in the cycle of restoration."
        />

                <ShlokaCard
          verseRef="Bhagavad Gita 4.8"
          sanskrit="परित्राणाय साधूनां विनाशाय च दुष्कृताम् । धर्मसंस्थापनार्थाय संभवामि युगे युगे ॥"
          iast="paritrāṇāya sādhūnāṃ vināśāya ca duṣkṛtām | dharmasaṃsthāpanārthāya saṃbhavāmi yuge yuge ||"
          meaningLabel="Translation"
          meaning="To protect those who uphold dharma, to destroy those who create harm, and to firmly re-establish dharma: I arise in every age."
          insightLabel="What This Teaches"
          insight="The phrase yuge yuge, in every age, carries a particular weight. This is not a single historical event. It is a recurring pattern. The Gita is saying that the restoration of dharma is not a one-time achievement. It requires active, recurring renewal. Dharma left alone does not maintain itself. It requires those who uphold it, and periodically something larger that corrects the course when individual effort is not enough."
          essence="Dharma is always supported and restored, no matter the era."
        />

        <p>
          These two verses are frequently quoted as comfort in difficult times: things are bad, but correction will come. That reading is not wrong, but it is incomplete. The verses are also making a structural claim about how the cosmos works. Dharma is not self-sustaining. It requires both human effort and something beyond human effort. Both are real and both are necessary.
        </p>

        <h2>BG 18.47: The Teaching on Svadharma, Restated</h2>
        <p>
          The teaching from BG 3.35 is essentially repeated in Chapter 18 at a higher register. By the time we reach Chapter 18, Arjuna and the reader have been through the full arc of the Gita. The restatement here is not accidental. It is the Gita confirming that this teaching belongs at both the beginning and the end of the path.
        </p>

                <ShlokaCard
          verseRef="Bhagavad Gita 18.47"
          sanskrit="श्रेयान्स्वधर्मो विगुणः परधर्मात्स्वनुष्ठितात् । स्वभावनियतं कर्म कुर्वन्नाप्नोति किल्बिषम् ॥"
          iast="śreyānsvadharmo viguṇaḥ paradharmātsvanuṣṭhitāt | svabhāvaniyataṃ karma kurvannāpnoti kilbiṣam ||"
          meaningLabel="Translation"
          meaning="Doing your own work, even if imperfect, is better than doing someone else's work perfectly. You do not create wrong when you live by your natural duties."
          insightLabel="What This Teaches"
          insight="The key phrase here is svabhava-niyatam: determined by one's own nature. The work that flows from svabhava is not chosen. It is discerned. You find it by looking at what your actual nature is, not by choosing what looks prestigious or virtuous from the outside. The verse then says that acting from svabhava does not produce kilbisha, wrongdoing or sin. There is a protection in authentic action that is not available in imitation."
          essence="Walking your own path, true to your nature, brings real peace and protects you from inner trouble."
        />

        <p>
          The difference between BG 3.35 and BG 18.47 is in the framing. In Chapter 3, the teaching is framed against the danger of paradharma. In Chapter 18, it is framed positively: act from svabhava, and you are protected. The teaching has moved from warning to affirmation. After 15 chapters of instruction, the Gita is saying: this is still it. This is the core of what I was saying from the beginning.
        </p>

        <h2>The Surrender: BG 18.66</h2>
        <p>
          The last teaching of the Gita appears to contradict everything that came before. After spending 17 chapters building the case for dharma, svadharma, and right action, BG 18.66 says: abandon all dharma. Come to me alone.
        </p>

                <ShlokaCard
          verseRef="Bhagavad Gita 18.66"
          sanskrit="सर्वधर्मान्परित्यज्य मामेकं शरणं व्रज । अहं त्वा सर्वपापेभ्यो मोक्षयिष्यामि मा शुचः ॥"
          iast="sarvadharmānparityajya māmekaṃ śaraṇaṃ vraja | ahaṃ tvā sarvapāpebhyo mokṣayiṣyāmi mā śucaḥ ||"
          meaningLabel="Translation"
          meaning="Set aside all dharmas and take refuge in me alone. I will free you from all wrongdoing. Do not be afraid."
          insightLabel="What This Teaches"
          insight="The apparent paradox dissolves when you see what is being abandoned. Sarva-dharman, all dharmas. Not specific dharmas, but the entire framework of dharma as self-managed obligation. The teaching is not stop acting rightly. It is: stop relating to right action as something you are managing and maintaining through your own effort. The matured student of the Gita arrives at the point where the very category of dharma as personal project falls away, and what remains is action arising directly from surrender to the divine. The action is the same. The source has shifted."
          essence="Let go and trust fully. Freedom and peace will follow."
        />

        <p>
          This verse is sometimes used to argue that the Gita ultimately dismisses all ethical frameworks as obstacles to pure devotion. That reading requires ignoring the 700 verses that precede it. The verse is not canceling the dharma teaching. It is describing what happens at its completion. You do not arrive at surrender by skipping the work of dharma. You arrive at it by doing that work until the clinging to it as personal achievement falls away.
        </p>

        <h2>Dharma in Practice: What Arjuna&apos;s Dilemma Teaches</h2>
        <p>
          Arjuna&apos;s specific crisis at the opening of the Gita is a collision between two dharmas. As a kshatriya (warrior), his role-dharma is to fight a righteous war. As a family member, his relational dharma is loyalty and affection toward his own people. Both are real. Both are legitimate. And they are pointing in opposite directions.
        </p>
        <p>
          Krishna&apos;s answer is not to resolve the collision by declaring one dharma superior to the other. He goes deeper. He moves the question from role-based dharma to the level of the atman itself. Once Arjuna understands what he actually is (and what cannot be killed), the collision between warrior-dharma and family-dharma does not disappear, but it is seen from a different vantage. The action required by his position and nature becomes clear, not because the conflict was resolved, but because the framework expanded.
        </p>
        <p>
          This is the Gita&apos;s model for navigating dharma conflicts: go deeper, not sideways. When two dharmas collide at the role level, look for what your svadharma requires at the level of actual nature, not performed function.
        </p>

        <h2>What &ldquo;Follow Your Dharma&rdquo; Actually Means</h2>
        <p>
          The phrase has become a kind of wellness-culture slogan, meaning roughly &ldquo;follow your passion&rdquo; or &ldquo;live authentically.&rdquo; The Gita&apos;s version is harder than that.
        </p>

        <div className="highlight-box">
          <h3>Svadharma Is Not a Career</h3>
          <p>
            Svadharma is not what you enjoy doing. It is not what makes you feel good. It is what your nature requires of you, which sometimes means doing difficult things you would rather avoid, in the way that only you can do them, without borrowing someone else&apos;s method or measuring yourself against someone else&apos;s standard.
          </p>
          <p>
            Arjuna did not want to fight. His svadharma required it anyway. The Gita is not saying do what feels right. It is saying act from what you actually are. These sometimes align and sometimes cost considerably.
          </p>
        </div>

        <p>
          The Gita&apos;s final position on dharma is something like this: understand what you are. Act from that understanding. Let the fruits go where they go. Do not pretend to be something you are not in order to perform someone else&apos;s dharma more impressively. And at the end of all of that, when the teaching has gone as deep as it can go, arrive at the place where even the architecture of dharma is held lightly, because what is underneath it is bigger than any framework can contain.
        </p>
        <p>
          This is the actual scale of the Gita&apos;s teaching on dharma. It is not a rule. It is a direction. And the direction is always inward.
        </p>
      </div>


      <FeedbackWidget pageType="blog" />
      <div className="faq-section">
        <h2>Frequently Asked Questions</h2>

        <div className="faq-item">
          <strong>What is dharma in the Bhagavad Gita?</strong>
          <p>
            Dharma in the Gita comes from the Sanskrit root dhr, to hold or sustain. It is what holds a thing&apos;s essential nature in place. The Gita uses it in several registers: cosmic order, universal law, social role-based duties, and individual nature-based duty (svadharma). Most of the Gita&apos;s practical teaching is about svadharma: the path that arises from your own nature, not borrowed from someone else.
          </p>
        </div>

        <div className="faq-item">
          <strong>What is svadharma?</strong>
          <p>
            Svadharma means your own dharma, the action and way of life that accords with your own nature (svabhava). BG 3.35 and BG 18.47 both state that it is better to perform your own dharma imperfectly than another&apos;s perfectly. Svadharma is not a career or a role assigned from outside. It is the quality of action that arises when you act from your deepest nature rather than from imitation or fear. The Gita says that acting from svabhava does not create wrongdoing, while paradharma (living another&apos;s path) generates bhaya: fear.
          </p>
        </div>

        <div className="faq-item">
          <strong>What does the Bhagavad Gita say about dharma and adharma?</strong>
          <p>
            The Gita opens on dharma-kshetra, the field of dharma. Adharma is what opposes or erodes dharma. BG 4.7 says that whenever dharma declines and adharma rises, Krishna takes form to restore balance. The Gita&apos;s framing is that dharma needs to be actively upheld, and that when it weakens, correction comes. Arjuna&apos;s paralysis at the start of the Gita is itself a form of adharma: a warrior refusing the action his nature and position require.
          </p>
        </div>

        <div className="faq-item">
          <strong>Is dharma the same as duty?</strong>
          <p>
            Duty is a common English translation but it carries the wrong connotations. Duty implies an external obligation, something imposed from outside that you must fulfill regardless of your nature. Dharma is closer to your nature&apos;s requirement: what you must do because of what you are. A fire&apos;s dharma is to burn upward. This is not a rule imposed on fire. It is a description of fire&apos;s nature. For a person, dharma means what your actual nature requires of you in action, which is more demanding and more personal than any external rule.
          </p>
        </div>

        <div className="faq-item">
          <strong>What does dharma-kshetra mean in the Bhagavad Gita?</strong>
          <p>
            Dharma-kshetra is the first word of the Gita: the field of dharma. The battlefield at Kurukshetra is named this way. The choice is deliberate. The Gita is framing the entire conflict not as a battle over territory or inheritance but as a confrontation over dharma. The battlefield is the place where dharma gets tested and either upheld or abandoned. This framing explains why the teaching that follows is not military strategy or political philosophy. It is a teaching about what to do when your dharma becomes genuinely difficult to see.
          </p>
        </div>
      </div>

      <VerseFunnelCTA variant="chapter" locale="en" pageName={"Dharma Meaning Bhagavad Gita"} />

      <footer>
        <p>© 2026 Wisdom App. Bhagavad Gita, tuned to your life.</p>
        <p><a href="https://wisdomquotes.in">Home</a> — <a href="https://wisdomquotes.in/blogs">Blog</a> — <a href={appStoreUrl('web_blog_footer')} target="_blank" rel="noopener" data-mp-location="footer">Download</a></p>
      </footer>

      <BlogTracker pageName="Dharma Meaning Bhagavad Gita" />
    </>
  )
}
