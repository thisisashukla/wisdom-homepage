import type { Metadata } from 'next'
import BlogTracker from '@/components/BlogTracker'
import FeedbackWidget from '@/components/FeedbackWidget'
import ShlokaCard from '@/components/gita/ShlokaCard'
import VerseFunnelCTA from '@/components/funnel/VerseFunnelCTA'
import { appStoreUrl } from '@/lib/app'

export const metadata: Metadata = {
  title: "Bhagavad Gita Chapter 1 Summary \u2013 Key Verses & Meaning (Arjuna Vishada Yoga)",
  description: "Bhagavad Gita Chapter 1 (Arjuna Vishada Yoga) \u2014 47 verses on the despair of Arjuna at Kurukshetra, when the greatest archer in history put down his bow.",
  keywords: "bhagwat geeta chapter 1, bhagwat geeta adhyay 1, arjuna vishada yoga, bhagavad gita chapter 1 shlok, bhagwat geeta chapter 1 in hindi, arjuna grief bhagavad gita, kurukshetra battlefield, dhritarashtra uvacha, arjuna refuses to fight, gita chapter 1 summary, Arjuna Vishada Yoga meaning, Bhagavad Gita 1.1 dharmakshetre kurukshetre, why Arjuna put down his bow, moral crisis Bhagavad Gita",
  openGraph: {
    title: "Bhagavad Gita Chapter 1 Summary \u2013 Key Verses & Meaning (Arjuna Vishada Yoga)",
    description: "All 47 verses of Bhagavad Gita Chapter 1 \u2014 a great warrior paralysed not by cowardice, but by conscience. The most psychologically honest chapter in the Gita.",
    type: 'article',
    url: "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-1",
    siteName: 'Wisdom',
    locale: 'en_IN',
    images: [{ url: "https://wisdomquotes.in/assets/chapter1.webp", width: 1200, height: 675, alt: "Arjuna collapsed on his chariot at Kurukshetra, bow lowered, gaze on his teachers and kin \u2014 Chapter 1 of the Bhagavad Gita, Arjuna Vishada Yoga, captures the moment grief and dharma collide." }],
  },
  twitter: {
    card: 'summary_large_image',
    title: "Bhagavad Gita Chapter 1 Summary \u2013 Key Verses & Meaning (Arjuna Vishada Yoga)",
    description: "All 47 verses of Bhagavad Gita Chapter 1 \u2014 a great warrior paralysed not by cowardice, but by conscience.",
    images: ["https://wisdomquotes.in/assets/chapter1.webp"],
  },
  alternates: {
    canonical: "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-1",
    languages: {
      'x-default': "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-1",
      'en': "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-1",
      'en-IN': "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-1",
    },
  },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, 'max-image-preview': 'large', 'max-snippet': -1 },
  },
  other: { "rel=next": "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-2" },
}

const pageCSS = `

      :root {
        --maroon: #3d0c0c;
        --maroon-mid: #5c1a1a;
        --gold: #c8881e;
        --gold-light: #f5c96a;
        --gold-pale: #fdf3dc;
        --gold-border: #e8c97a;
        --gold-dim: rgba(200, 136, 30, 0.15);
        --text: #f5e8cc;
        --text-dim: rgba(245, 232, 204, 0.65);
        --text-dimmer: rgba(245, 232, 204, 0.35);
        --muted-2: rgba(245, 232, 204, 0.35);
        --border: rgba(200, 136, 30, 0.2);
        --bg: #120505;
        --bg-warm: #190707;
        --bg-alt: #0f0404;
        --bg-card: rgba(255, 255, 255, 0.04);
        --bg-card-hover: rgba(255, 255, 255, 0.07);
        --max: 780px;
      }

      *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
      html {
        scroll-behavior: smooth;
        scroll-padding-top: 88px;
      }

      body {
        font-family: "Inter", system-ui, -apple-system, sans-serif;
        background: var(--bg);
        color: var(--text);
        line-height: 1.7;
        -webkit-font-smoothing: antialiased;
      }

      a { color: inherit; text-decoration: none; }
      img { display: block; max-width: 100%; }

      /* ── BREADCRUMB ── */
      .breadcrumb {
        background: var(--bg-alt);
        border-bottom: 1px solid var(--border);
      }
      .breadcrumb-inner {
        max-width: 1100px;
        margin: 0 auto;
        padding: 10px 28px;
        font-size: 12px;
        color: var(--text-dimmer);
        display: flex;
        gap: 8px;
        align-items: center;
      }
      .breadcrumb-inner a { color: var(--text-dimmer); transition: color 0.15s; }
      .breadcrumb-inner a:hover { color: var(--gold-light); }
      .bc-sep { opacity: 0.4; }

      /* ── ARTICLE HERO ── */
      .article-hero {
        background: var(--bg-warm);
        padding: 64px 28px 56px;
        border-bottom: 1px solid var(--border);
        position: relative;
        overflow: hidden;
      }
      .article-hero::before {
        content: "अध्याय १";
        position: absolute;
        right: -10px;
        bottom: -20px;
        font-family: "Noto Sans Devanagari", serif;
        font-size: 180px;
        color: rgba(200, 136, 30, 0.04);
        line-height: 1;
        pointer-events: none;
        user-select: none;
      }
      .article-hero-inner { max-width: 1100px; margin: 0 auto; position: relative; z-index: 2; }

      .chapter-badge {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        background: rgba(200, 136, 30, 0.1);
        border: 1px solid rgba(200, 136, 30, 0.28);
        color: var(--gold-light);
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 0.12em;
        text-transform: uppercase;
        padding: 5px 14px;
        border-radius: 100px;
        margin-bottom: 20px;
      }
      .chapter-badge-dot {
        width: 5px;
        height: 5px;
        border-radius: 50%;
        background: var(--gold);
        box-shadow: 0 0 6px var(--gold);
        flex-shrink: 0;
      }
      .article-title {
        font-family: "Playfair Display", Georgia, serif;
        font-size: clamp(28px, 4vw, 48px);
        font-weight: 700;
        color: var(--gold-light);
        line-height: 1.15;
        letter-spacing: -0.5px;
        margin-bottom: 12px;
      }
      .article-title em { font-style: italic; color: #fff; }
      .article-subtitle {
        font-size: 17px;
        color: var(--text-dim);
        font-weight: 300;
        margin-bottom: 32px;
        line-height: 1.65;
        max-width: 580px;
      }
      .article-meta { display: flex; align-items: center; gap: 16px; flex-wrap: wrap; }
      .meta-item { font-size: 12px; color: var(--text-dimmer); letter-spacing: 0.04em; }
      .meta-sep { color: var(--border); }

      /* ── ARTICLE BODY ── */
      .article-wrap { max-width: var(--max); margin: 0 auto; padding: 60px 28px 80px; }

      .chapter-image {
        margin: 0 0 36px;
        border-radius: 14px;
        overflow: hidden;
        border: 1px solid var(--border);
        background: var(--bg-warm);
        box-shadow: 0 24px 48px rgba(0, 0, 0, 0.4);
      }
      .chapter-image img { display: block; width: 100%; height: auto; aspect-ratio: 16 / 9; object-fit: cover; }

      .prose h2 {
        font-family: "Playfair Display", Georgia, serif;
        font-size: 26px;
        font-weight: 700;
        color: var(--gold-light);
        margin: 52px 0 16px;
        line-height: 1.25;
      }
      .prose h2[id],
      .faq-section[id] {
        scroll-margin-top: 88px;
      }
      .prose h2 em { font-style: italic; color: #fff; }

      .prose h3 {
        font-family: "Playfair Display", Georgia, serif;
        font-size: 19px;
        font-weight: 700;
        color: var(--text);
        margin: 32px 0 12px;
      }

      .prose p {
        font-size: 16.5px;
        line-height: 1.78;
        color: var(--text-dim);
        margin-bottom: 20px;
      }
      .prose p:last-child { margin-bottom: 0; }
      .prose strong { font-weight: 600; color: var(--text); }
      .prose em { font-style: italic; }
      .lead {
        font-size: 19px;
        line-height: 1.7;
        color: var(--text);
        font-weight: 300;
        margin-bottom: 28px;
      }

      /* ── TOC ── */
      .toc {
        background: var(--bg-card);
        border: 1px solid var(--border);
        border-left: 3px solid var(--gold);
        border-radius: 0 12px 12px 0;
        padding: 20px 24px;
        margin: 36px 0 40px;
      }
      .toc-label {
        font-size: 9.5px;
        letter-spacing: 0.18em;
        text-transform: uppercase;
        font-weight: 700;
        color: var(--gold);
        margin-bottom: 12px;
      }
      .toc-list { list-style: none; display: flex; flex-direction: column; gap: 7px; counter-reset: toc-counter; }
      .toc-list li { counter-increment: toc-counter; display: flex; align-items: baseline; gap: 10px; }
      .toc-list li::before {
        content: counter(toc-counter);
        font-family: "Inter", sans-serif;
        font-size: 10px;
        font-variant-numeric: tabular-nums;
        color: var(--text-dimmer);
        min-width: 14px;
      }
      .toc-list a { font-size: 13.5px; color: var(--text-dim); line-height: 1.4; transition: color 0.15s; }
      .toc-list a:hover { color: var(--gold-light); }

      /* ── SHLOKA CARD ── */

      /* ── PULL QUOTE ── */
      .pull-quote {
        margin: 40px 0;
        padding: 28px 32px;
        border-left: 3px solid var(--gold);
        background: rgba(200, 136, 30, 0.05);
        border-radius: 0 12px 12px 0;
      }
      .pull-quote blockquote {
        font-family: "Playfair Display", serif;
        font-size: 21px;
        font-style: italic;
        color: var(--gold-light);
        line-height: 1.5;
        margin-bottom: 10px;
      }
      .pull-quote cite { font-size: 12px; letter-spacing: 0.1em; text-transform: uppercase; color: var(--gold); font-style: normal; font-weight: 600; }

      /* ── SECTION DIVIDER ── */
      .section-divider { display: flex; align-items: center; gap: 16px; margin: 56px 0 40px; }
      .section-divider-line { flex: 1; height: 1px; background: var(--border); }
      .section-divider-label { font-size: 10px; letter-spacing: 0.18em; text-transform: uppercase; color: var(--text-dimmer); white-space: nowrap; font-weight: 600; }

      /* ── HIGHLIGHT BOX ── */
      .highlight-box {
        background: rgba(200, 136, 30, 0.05);
        border: 1px solid var(--border);
        border-left: 3px solid var(--gold);
        border-radius: 0 10px 10px 0;
        padding: 20px 24px;
        margin: 28px 0;
      }
      .highlight-box p { font-size: 15px; line-height: 1.7; color: var(--text-dim); }
      .highlight-box strong { color: var(--gold-light); }

      /* ── KEY INSIGHTS ── */
      .insights-box {
        background: var(--bg-card);
        border: 1px solid var(--border);
        border-top: 2px solid var(--gold);
        border-radius: 14px;
        padding: 28px 32px;
        margin: 48px 0;
      }
      .insights-label { font-size: 9.5px; letter-spacing: 0.18em; text-transform: uppercase; font-weight: 700; color: var(--gold); margin-bottom: 16px; }
                  .insights-list { list-style: none; display: flex; flex-direction: column; gap: 0; counter-reset: insight-counter; }
      .insights-list li {
        counter-increment: insight-counter;
        position: relative;
        padding: 22px 0 22px 52px;
        border-bottom: 1px solid var(--border);
        font-size: 14.5px;
        color: var(--text-dim);
        line-height: 1.7;
      }
      .insights-list li:last-child { border-bottom: none; padding-bottom: 0; }
      .insights-list li::before {
        content: counter(insight-counter);
        position: absolute;
        left: 0;
        top: 22px;
        width: 32px;
        height: 32px;
        font-size: 13px;
        font-weight: 700;
        background: rgba(200, 136, 30, 0.12);
        color: var(--gold);
        border: 1px solid rgba(200, 136, 30, 0.35);
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
      }
      .insights-list strong { color: var(--text); font-weight: 600; display: block; margin-bottom: 5px; font-size: 15px; }

      /* ── VERSE TABLE ── */
      .verse-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 13.5px;
        margin: 28px 0 40px;
        border: 1px solid var(--border);
        border-radius: 10px;
        overflow: hidden;
      }
      .verse-table thead tr { background: rgba(200, 136, 30, 0.08); }
      .verse-table thead th {
        text-align: left;
        padding: 12px 16px;
        font-size: 9.5px;
        letter-spacing: 0.15em;
        text-transform: uppercase;
        color: var(--gold);
        font-weight: 700;
      }
      .verse-table tbody td {
        padding: 10px 16px;
        border-bottom: 1px solid var(--border);
        vertical-align: top;
        line-height: 1.55;
        color: var(--text-dim);
      }
      .verse-table tbody tr:last-child td { border-bottom: none; }
      .verse-table tbody tr:hover { background: var(--bg-card); }
      .verse-table td:first-child { font-size: 12px; color: var(--gold); font-weight: 600; white-space: nowrap; }

      /* ── FAQ ── */
      .faq-section {
        background: var(--bg-card);
        border: 1px solid var(--border);
        border-top: 2px solid var(--gold);
        border-radius: 14px;
        overflow: hidden;
        margin: 48px 0;
      }
      .faq-header { padding: 28px 32px 20px; border-bottom: 1px solid var(--border); }
      .faq-header-label { font-size: 10px; letter-spacing: 0.2em; text-transform: uppercase; color: var(--gold); font-weight: 700; margin-bottom: 6px; }
      .faq-header h2 {
        font-family: "Playfair Display", serif;
        font-size: 22px;
        font-weight: 700;
        color: var(--gold-light);
        line-height: 1.3;
        margin: 0;
      }
      .faq-item { padding: 22px 32px; border-bottom: 1px solid var(--border); }
      .faq-item:last-child { border-bottom: none; }
      .faq-q { font-size: 15px; font-weight: 600; color: var(--text); margin-bottom: 10px; line-height: 1.4; }
      .faq-a { font-size: 14.5px; line-height: 1.72; color: var(--text-dim); }

      /* ── WISDOM ENTITY ── */
      .wisdom-entity {
        background: var(--bg-card);
        border: 1px solid var(--border);
        border-top: 2px solid var(--gold);
        border-radius: 14px;
        padding: 28px 32px;
        margin: 48px 0;
      }
      .wisdom-entity-label { font-size: 9.5px; letter-spacing: 0.18em; text-transform: uppercase; font-weight: 700; color: var(--gold); margin-bottom: 10px; }
      .wisdom-entity h3 { font-family: "Playfair Display", serif; font-size: 18px; font-weight: 700; color: var(--gold-light); margin-bottom: 10px; }
      .wisdom-entity p { font-size: 14px; line-height: 1.7; color: var(--text-dim); margin-bottom: 10px; }
      .wisdom-entity p:last-child { margin-bottom: 0; }
      .wisdom-entity strong { color: var(--text); font-weight: 600; }
      .wisdom-entity a { color: var(--gold); text-decoration: underline; text-underline-offset: 3px; }

            /* ── APP CTA ── */
      .app-cta {
        background: linear-gradient(160deg, #2d0a0a 0%, #1a0606 100%);
        border: 1px solid rgba(200, 136, 30, 0.25);
        border-top: 3px solid var(--gold);
        border-radius: 20px;
        padding: 44px 48px 40px;
        margin: 48px 0 60px;
        text-align: center;
        position: relative;
        overflow: hidden;
      }
      .app-cta::before {
        content: "ज्ञान";
        position: absolute;
        top: -14px;
        right: -8px;
        font-family: "Noto Sans Devanagari", sans-serif;
        font-size: 130px;
        color: rgba(200, 136, 30, 0.05);
        line-height: 1;
        pointer-events: none;
        user-select: none;
      }
      .app-cta-eyebrow {
        display: inline-flex;
        align-items: center;
        background: rgba(200, 136, 30, 0.12);
        border: 1px solid rgba(200, 136, 30, 0.35);
        color: var(--gold-light);
        font-size: 11px;
        font-weight: 600;
        letter-spacing: 0.14em;
        text-transform: uppercase;
        padding: 5px 14px;
        border-radius: 20px;
        margin-bottom: 20px;
      }
      .app-cta-headline {
        font-family: "Playfair Display", serif;
        font-size: clamp(22px, 3vw, 30px);
        font-weight: 700;
        color: var(--text);
        line-height: 1.25;
        margin-bottom: 14px;
      }
      .app-cta-desc {
        font-size: 15px;
        color: var(--text-dim);
        line-height: 1.7;
        max-width: 480px;
        margin: 0 auto 22px;
      }
      .app-cta-features {
        display: flex;
        gap: 6px 18px;
        justify-content: center;
        flex-wrap: wrap;
        margin-bottom: 28px;
      }
      .app-cta-features span {
        font-size: 13px;
        color: var(--gold-light);
        opacity: 0.8;
      }
      .app-cta-btn {
        display: inline-flex;
        align-items: center;
        gap: 10px;
        background: var(--gold);
        color: #120505;
        text-decoration: none;
        padding: 15px 34px;
        border-radius: 12px;
        font-size: 16px;
        font-weight: 700;
        letter-spacing: -0.01em;
        transition: all 0.2s;
        box-shadow: 0 4px 22px rgba(200, 136, 30, 0.3);
      }
      .app-cta-btn:hover {
        background: var(--gold-light);
        transform: translateY(-2px);
        box-shadow: 0 8px 32px rgba(200, 136, 30, 0.5);
      }
      .app-cta-sub {
        font-size: 12px;
        color: rgba(245, 232, 204, 0.35);
        margin-top: 14px;
        letter-spacing: 0.04em;
      }

      /* ── CHAPTER NAV ── */
      .chapter-nav {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 16px;
        padding: 20px 0;
        border-top: 1px solid var(--border);
        border-bottom: 1px solid var(--border);
        margin: 0 0 40px;
      }
      .ch-nav-label { font-size: 11px; letter-spacing: 0.1em; text-transform: uppercase; color: var(--text-dimmer); font-weight: 600; margin-bottom: 4px; }
      .ch-nav-title { font-size: 14px; font-weight: 600; color: var(--text); }

      /* ── RELATED ── */
      .related-section { margin-bottom: 60px; }
      .related-section h3 { font-family: "Playfair Display", serif; font-size: 20px; font-weight: 700; color: var(--gold-light); margin-bottom: 20px; }
      .related-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 14px; }
      .related-card {
        background: var(--bg-card);
        border: 1px solid var(--border);
        border-radius: 10px;
        padding: 18px 20px;
        text-decoration: none;
        transition: border-color 0.15s, background 0.15s, transform 0.15s;
      }
      .related-card:hover { border-color: var(--gold); background: var(--bg-card-hover); transform: translateY(-2px); }
      .related-card-label { font-size: 10px; letter-spacing: 0.15em; text-transform: uppercase; color: var(--text-dimmer); font-weight: 600; margin-bottom: 6px; }
      .related-card-title { font-size: 14px; font-weight: 600; color: var(--text); line-height: 1.4; }

      /* ── FOOTER ── */
      footer {
        background: var(--bg-alt);
        border-top: 1px solid var(--border);
        padding: 32px 28px;
        text-align: center;
        font-size: 12px;
        letter-spacing: 0.06em;
        color: var(--text-dimmer);
      }
      footer a { color: var(--text-dimmer); transition: color 0.15s; }
      footer a:hover { color: var(--gold-light); }
      footer span { color: var(--gold); }

      /* ── RESPONSIVE ── */
      @media (max-width: 700px) {
        .article-hero { padding: 44px 20px 40px; }
        .article-wrap { padding: 40px 20px 60px; }
        .app-cta { padding: 32px 24px; }
        .pull-quote { padding: 22px 24px; }
        .faq-header, .faq-item { padding-left: 20px; padding-right: 20px; }
        .insights-box, .wisdom-entity { padding: 20px; }
      }
    
`

const schemas = [
  {
    "@context": "https://schema.org",
    "@type": ["Article", "LearningResource"],
    "headline": "Bhagavad Gita Chapter 1 — Arjuna Vishada Yoga: When the Warrior Sat Down",
    "description": "Bhagavad Gita Chapter 1 — Arjuna Vishada Yoga. All 47 verses with Sanskrit, transliteration, meaning, and the moment the greatest archer in history put down his bow.",
    "alternativeHeadline": "Bhagavad Gita Chapter 1 (Arjuna Vishada Yoga) — Summary & Verses",
    "author": {
      "@type": "Person",
      "name": "Ankur Shukla",
      "url": "https://wisdomquotes.in/about",
      "sameAs": ["https://www.linkedin.com/in/thisisashukla/", "https://x.com/thisisashukla"]
    },
    "publisher": {
      "@type": "Organization",
      "name": "Wisdom",
      "url": "https://wisdomquotes.in",
      "logo": { "@type": "ImageObject", "url": "https://wisdomquotes.in/assets/new-light-logo.webp" }
    },
    "image": { "@type": "ImageObject", "url": "https://wisdomquotes.in/assets/chapter1.webp", "width": 1200, "height": 675 },
    "datePublished": "2026-04-08",
    "dateModified": "2026-05-24",
    "mainEntityOfPage": { "@type": "WebPage", "@id": "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-1" },
    "about": [
      { "@type": "Book", "name": "Bhagavad Gita", "author": { "@type": "Person", "name": "Ved Vyasa" }, "url": "https://wisdomquotes.in/gita" },
      { "@type": "Person", "name": "Krishna", "url": "https://en.wikipedia.org/wiki/Krishna" },
      { "@type": "Person", "name": "Arjuna", "url": "https://en.wikipedia.org/wiki/Arjuna" }
    ],
    "keywords": "bhagwat geeta chapter 1, bhagwat geeta adhyay 1, arjuna vishada yoga, bhagavad gita chapter 1 shlok, bhagwat geeta chapter 1 in hindi, arjuna grief bhagavad gita, kurukshetra battlefield, dhritarashtra uvacha, arjuna refuses to fight, gita chapter 1 summary, Bhagavad Gita 1.1 dharmakshetre kurukshetre, why Arjuna put down his bow",
    "articleSection": "Bhagavad Gita",
    "inLanguage": "en",
    "isAccessibleForFree": true,
    "learningResourceType": "Article",
    "educationalLevel": "General",
    "speakable": {
      "@type": "SpeakableSpecification",
      "cssSelector": [".lead", ".shloka-meaning", ".shloka-essence"]
    }
  },
  {
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    {
      "@type": "ListItem",
      "position": 1,
      "name": "Wisdom",
      "item": "https://wisdomquotes.in/"
    },
    {
      "@type": "ListItem",
      "position": 2,
      "name": "Blog",
      "item": "https://wisdomquotes.in/blogs/"
    },
    {
      "@type": "ListItem",
      "position": 3,
      "name": "Bhagavad Gita Chapter 1 — Arjuna Vishada Yoga",
      "item": "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-1"
    }
  ]
},
  {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "What is Bhagavad Gita Chapter 1 about?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Bhagavad Gita Chapter 1, called Arjuna Vishada Yoga, describes the scene on the battlefield of Kurukshetra just before the great war begins. Arjuna, the greatest archer of his age, sees his relatives and teachers arrayed on both sides, is overcome with grief and moral doubt, and ultimately sets down his bow and refuses to fight. The chapter establishes the profound ethical crisis that makes Krishna's teachings in the chapters that follow both necessary and meaningful."
      }
    },
    {
      "@type": "Question",
      "name": "What is Arjuna Vishada Yoga?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Arjuna Vishada Yoga means 'the yoga of Arjuna's grief' or 'the yoga of Arjuna's despondency.' In Sanskrit, vishada means deep sorrow, distress, or despondency. The word 'yoga' here doesn't mean exercise — it means a path or a discipline. The implication is that Arjuna's grief itself becomes a doorway: his collapse is what opens the space for Krishna's teaching."
      }
    },
    {
      "@type": "Question",
      "name": "How many verses are in Chapter 1 of the Bhagavad Gita?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Bhagavad Gita Chapter 1 has 47 verses (shlokas). It is the shortest chapter in terms of philosophy — none of Krishna's teachings appear yet — but among the most important in setting up the psychological and ethical context for everything that follows."
      }
    },
    {
      "@type": "Question",
      "name": "Why does Arjuna refuse to fight in Chapter 1?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Arjuna refuses to fight because he sees his own relatives — grandfathers, teachers, uncles, brothers, friends — arrayed on both sides of the battlefield. He argues that victory is meaningless if it requires killing the people he loves, that destroying families unravels the ethical fabric of society, and that dying unarmed would be preferable to this. His arguments are ethically sophisticated, not cowardly — but they are rooted in attachment to his roles as a son, student, and friend rather than to his deeper duty as a warrior and a atman."
      }
    },
    {
      "@type": "Question",
      "name": "What are the physical symptoms Arjuna describes in Chapter 1?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "In verses 29–30 (1.29–1.30), Arjuna describes his limbs going weak, his mouth drying up, his body trembling, his hair standing on end, his skin burning, his famous bow Gandiva slipping from his hands, and his mind reeling in confusion. These are precise descriptions of an acute stress response — what we now recognize as the physiological signature of grief, anxiety, and moral distress."
      }
    },
    {
      "@type": "Question",
      "name": "Who speaks first in the Bhagavad Gita?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "The very first words of the Bhagavad Gita are spoken by King Dhritarashtra, the blind father of the Kauravas. He asks his advisor Sanjaya: 'O Sanjaya, what did my sons and the sons of Pandu do after assembling on the holy field of Kurukshetra?' The Gita's opening is not a teaching — it is a question loaded with a blind king's attachment to his own children."
      }
    },
    {
      "@type": "Question",
      "name": "What does 'dharma-kshetra kuru-kshetra' mean?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "The opening line of the Bhagavad Gita describes Kurukshetra as 'dharma-kshetra' — the field of dharma, or the field of righteousness. The battlefield is not just a physical location; it is presented as a place where the question of what is right must be confronted directly. This framing immediately establishes that what follows is not just a war story, but a philosophical reckoning with duty, conscience, and action."
      }
    },
    {
      "@type": "Question",
      "name": "Is Chapter 1 the most important in the Bhagavad Gita?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Chapter 2 is typically considered the philosophical heart of the Gita, and later chapters go deeper into yoga, devotion, and metaphysics. But Chapter 1 may be the most humanly important — because it establishes the crisis that makes all wisdom necessary. A teaching without a felt question is just information. Arjuna's collapse in Chapter 1 is what makes Krishna's answers in the following chapters land with any weight."
      }
    },
    {
      "@type": "Question",
      "name": "What is the main teaching of Bhagavad Gita Chapter 1?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Chapter 1 does not contain any explicit teaching from Krishna. Its teaching is structural: it shows what happens when a person's identity is built entirely on their roles and relationships. When those roles come into conflict with each other, the person collapses. Chapter 1 is the Gita's argument that wisdom only becomes real when you've been brought to your knees by its absence."
      }
    },
    {
      "@type": "Question",
      "name": "What does the Bhagavad Gita say about grief and emotional crisis?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "The Bhagavad Gita takes grief seriously — it opens with it. Arjuna's despondency in Chapter 1 is treated not as weakness to be dismissed but as the necessary starting point for transformation. The Sanskrit word vishada (grief/despondency) appears in the title of Chapter 1 itself. The Gita's approach is that genuine understanding can only begin after you have honestly confronted your own confusion and pain."
      }
    }
  ]
}
]

export default function ChapterOnePage() {
  return (
    <>
      <style dangerouslySetInnerHTML={{ __html: pageCSS }} />
      {schemas.map((s, i) => (
        <script key={i} type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(s) }} />
      ))}


    {/* ── BREADCRUMB ── */}
    <div className="breadcrumb">
      <div className="breadcrumb-inner">
        <a href="/">Wisdom</a>
        <span className="bc-sep">/</span>
        <a href="/blogs">Blog</a>
        <span className="bc-sep">/</span>
        Bhagavad Gita Chapter 1
      </div>
    </div>

    {/* ── HERO ── */}
    <div className="article-hero">
      <div className="article-hero-inner">
        <div className="chapter-badge">
          <div className="chapter-badge-dot"></div>
          Bhagavad Gita · Adhyay 1 · 47 Verses
          <div className="chapter-badge-dot"></div>
        </div>
        <h1 className="article-title">
          Bhagavad Gita Chapter 1 (Adhyay 1):<br />
          <em>Arjuna Vishada Yoga</em>
        </h1>
        <p className="article-subtitle">
          The most psychologically honest chapter in the Gita begins not with
          wisdom, but with collapse. Forty-seven verses of a great archer who
          can't lift his bow.
        </p>
        <div className="article-meta">
          <span className="meta-item">By <a href="/about" rel="author" data-mp-location="byline_author" style={{ color: 'var(--gold-light)', borderBottom: '1px solid rgba(200,136,30,0.35)' }}>Ankur Shukla</a></span>
          <span className="meta-sep">·</span>
          <span className="meta-item">47 verses · Arjuna Vishada Yoga</span>
          <span className="meta-sep">·</span>
          <span className="meta-item">~16 min read</span>
          <span className="meta-sep">·</span>
          <span className="meta-item">Chapter 1 of 18</span>
          <span className="meta-sep">·</span>
          <span className="meta-item" style={{ fontStyle: 'italic' }}>Wisdom translation, edited by Ankur Shukla. Commentary AI-drafted, human-reviewed. Reviewed June 2026. <a href="/methodology" style={{ color: 'var(--gold-light)', borderBottom: '1px solid rgba(200,136,30,0.3)' }}>Methodology →</a></span>
        </div>
      </div>
    </div>

    {/* ── ARTICLE ── */}
    <div className="article-wrap">
      <article className="prose">
                <figure className="chapter-image">
          <img
            src="/assets/chapter1.webp"
            alt="Arjuna's despair on the battlefield, Bhagavad Gita Chapter 1"
            width="1200"
            height="675"
            loading="eager"
          />
        </figure>

        <p className="lead">
          Most teachers rush past Chapter 1. It gets treated as backstory, the
          setup before the philosophy begins in Chapter 2. This is a mistake.
          Chapter 1 is the most humanly honest chapter in the Gita. Possibly in
          all of Sanskrit literature. Because it begins not with answers, but
          with collapse.
        </p>

        <p>
          Not with noble courage to act, but with the terrifying uncertainty
          about whether acting is right at all.
        </p>

        <p>
          The setting: the battlefield of Kurukshetra. Two armies face each
          other, representing the largest military gathering the subcontinent
          has known. At the center of it stands Arjuna, the greatest archer of
          his age, trained since boyhood for exactly this moment, armed with the
          divine bow Gandiva and the blessings of the gods. And he can't move.
        </p>

        <p>
          47 verses later, he sits down in his chariot and puts his bow down.
        </p>

        <p>The chapter that causes this is worth understanding in full.</p>

        {/* TABLE OF CONTENTS */}
        <nav className="toc" aria-label="Table of contents">
          <div className="toc-label">In this article</div>
          <ol className="toc-list">
            <li>
              <a href="#blind-king"
                >The blind king's opening question, Bhagavad Gita 1.1</a
              >
            </li>
            <li>
              <a href="#inventory">The inventory of warriors (1.2–1.19)</a>
            </li>
            <li><a href="#precipice">The pause at the precipice, 1.20</a></li>
            <li>
              <a href="#faces">When Arjuna sees their faces, 1.26–1.27</a>
            </li>
            <li>
              <a href="#body"
                >A body that doesn't lie, physical symptoms 1.29–1.30</a
              >
            </li>
            <li>
              <a href="#argument"
                >The ethical argument against victory, 1.32–1.44</a
              >
            </li>
            <li>
              <a href="#final"
                >The final choice, Arjuna sets down his bow, 1.46–1.47</a
              >
            </li>
            <li><a href="#why">Why Vyasa spent 47 verses on the crisis</a></li>
            <li><a href="#all-verses">All 47 shlokas at a glance</a></li>
            <li><a href="#faq">Frequently asked questions</a></li>
          </ol>
        </nav>

        {/* DIVIDER */}
        <div className="section-divider">
          <div className="section-divider-line"></div>
          <div className="section-divider-label">
            Verse 1.1 · The Opening Question
          </div>
          <div className="section-divider-line"></div>
        </div>

        <h2 id="blind-king">The Blind King Asks First</h2>

        <p>
          The very first words of the Bhagavad Gita don't belong to Krishna.
          They don't belong to Arjuna. They belong to Dhritarashtra, a blind
          king, sitting far from the battlefield, asking his advisor Sanjaya for
          a report.
        </p>

        <p>Listen carefully to how he asks it.</p>

        {/* SHLOKA 1.1 */}
                <ShlokaCard
          verseRef="Bhagavad Gita 1.1"
          speaker="Dhritarashtra"
          sanskrit="धृतराष्ट्र उवाच धर्मक्षेत्रे कुरुक्षेत्रे समवेता युयुत्सवः । मामकाः पाण्डवाश्चैव किमकुर्वत सञ्जय ॥"
          iast="dhṛtarāṣṭra uvāca dharmakṣetre kurukṣetre samavetā yuyutsavaḥ | māmakāḥ pāṇḍavāścaiva kimakurvata sañjaya ||"
          meaning="Dhritarashtra said: O Sanjaya, after assembling on the holy field of Kurukshetra, eager to fight, what did mine and Pandu's sons do?"
          insightLabel="What it reveals"
          insight="The Gita's first sentence already contains the war's root cause. &quot;Mine&quot; (māmakāḥ). Not &quot;the armies.&quot; Not &quot;the warriors.&quot; Mine and theirs. The blind king has already sorted the world into us and them before anything has happened."
          essence="Our perspective is shaped by our attachments and fears."
        />

        <p>
          The word <em>māmakāḥ</em> is important. Dhritarashtra doesn't call
          them "my sons" or even "the Kauravas." He calls them "mine", a
          possessive that has no real translation in English that captures its
          full weight. This is a man who has always confused ownership with
          love. His blindness, the Gita suggests, is not just physical.
        </p>

        <p>
          The Gita also places this scene in <em>dharma-kshetra</em>, the field
          of righteousness. Kurukshetra was already considered a sacred site.
          The battlefield is not just a geographical location; it's being framed
          as a place where the fundamental question of what is right must be
          confronted. Every word in this opening line is doing work.
        </p>

        {/* DIVIDER */}
        <div className="section-divider">
          <div className="section-divider-line"></div>
          <div className="section-divider-label">
            Verses 1.2–1.19 · The Armies Array
          </div>
          <div className="section-divider-line"></div>
        </div>

        <h2 id="inventory">The Inventory of Warriors</h2>

        <p>
          Verses 2 through 19 are often skimmed: Duryodhana surveys the Pandava
          army and reports to his teacher Dronacharya. Warriors are named on
          both sides. Conches are blown. The battlefield reverberates with the
          sound of war drums, trumpets, and the collective cry of two armies
          that have been building toward this moment for thirteen years of exile
          and betrayal.
        </p>

        <p>
          These verses aren't filler. They accomplish something crucial: they
          establish the weight of what's at stake. When Arjuna's crisis hits, we
          understand its scale because we've been shown what's arrayed on both
          sides, not abstractions, but named people. Bhishma, who trained half
          these warriors. Dronacharya, who taught both armies. Karna, who Arjuna
          knows is secretly his own brother. Every name is a relationship. Every
          warrior is someone's son, someone's teacher, someone's friend.
        </p>

        <div className="highlight-box">
          <p>
            <strong>A note on Duryodhana's psychology:</strong> In verses 3–11,
            Duryodhana's report to Dronacharya reveals a man performing
            confidence he doesn't feel. He lists the Pandava warriors almost
            obsessively, then declares his own side "unlimited" in strength, but the words betray anxiety. He's convincing himself, not his
            teacher. The Gita is psychologically precise from its opening
            verses.
          </p>
        </div>

        {/* DIVIDER */}
        <div className="section-divider">
          <div className="section-divider-line"></div>
          <div className="section-divider-label">
            Verse 1.20 · The Last Moment of Certainty
          </div>
          <div className="section-divider-line"></div>
        </div>

        <h2 id="precipice">The Pause at the Precipice</h2>

        <p>
          Then comes verse 20. The armies are ready. The conches have been
          blown. The arrows are nocked. And Arjuna, whose chariot bears the
          flag of Hanuman, a symbol of devotion and strength, raises his bow.
        </p>

                <ShlokaCard
          verseRef="Bhagavad Gita 1.20"
          sanskrit="अथ व्यवस्थितान् दृष्ट्वा धार्तराष्ट्रान्कपिध्वजः । प्रवृत्ते शस्त्रसंपाते धनुरुद्यम्य पाण्डवः ॥"
          iast="atha vyavasthitān dṛṣṭvā dhārtarāṣṭrānkapidhvajaḥ | pravṛtte śastrasaṃpāte dhanurudyamya pāṇḍavaḥ ||"
          meaning="Seeing the sons of Dhritarashtra arranged and ready for battle, as the weapons were about to clash, Arjuna, the son of Pandu, whose chariot bore the monkey banner, lifted his bow."
          insightLabel="The pivot"
          insight="This is the last moment before everything changes. The bow is lifted, but what follows in verses 21–23 is Arjuna asking Krishna to stop the chariot so he can look. This is not weakness. It is, in fact, his most warrior-like act: pausing before the irrevocable."
          essence="Pause and ready yourself before facing life's great challenges."
        />

        <p>
          In verses 21–23, Arjuna asks Krishna to position their chariot between
          the two armies so he can see who he'll be fighting against. Krishna
          complies. And what Arjuna sees destroys him.
        </p>

        {/* DIVIDER */}
        <div className="section-divider">
          <div className="section-divider-line"></div>
          <div className="section-divider-label">
            Verses 1.26–1.27 · Recognition
          </div>
          <div className="section-divider-line"></div>
        </div>

        <h2 id="faces">When You See <em>Their Faces</em></h2>

        <p>Arjuna doesn't see an army. He sees people.</p>

                <ShlokaCard
          verseRef="Bhagavad Gita 1.26–1.27"
          sanskrit="तत्रापश्यत्स्थितान्पार्थः पितृ़नथ पितामहान् । आचार्यान्मातुलान्भ्रातृ़न्पुत्रान्पौत्रान्सखींस्तथा ॥ श्वशुरान्सुहृदश्चैव सेनयोरुभयोरपि । तान्समीक्ष्य स कौन्तेयः सर्वान्बन्धूनवस्थितान् ॥"
          iast="tatrāpaśyatsthitānpārthaḥ pitṛ̈natha pitāmahān | ācāryānmātulānbhrātṛ̈nputrānpautrānsakhīṃstathā || śvaśurānsuhṛdaścaiva senayorubhayorapi | tānsamīkṣya sa kaunteyaḥ sarvānbandhūnavasthitān ||"
          meaning="There Arjuna saw, standing in both armies: fathers, grandfathers, teachers, maternal uncles, brothers, sons, grandsons, friends, fathers-in-law, and well-wishers. Seeing all these relatives arrayed on both sides, the son of Kunti was overwhelmed with great compassion."
          insightLabel="The human moment"
          insight="The list is precise and personal. Not &quot;the enemy&quot;, fathers, grandfathers, teachers. The Gita is describing what it looks like when abstract conflict becomes concrete and personal. This is not cowardice. This is recognition."
          essence="Recognize the humanity in every conflict; behind every role is a relationship."
        />

        <p>
          What collapses Arjuna is not fear of dying. He has faced death before.
          It's something more disorienting: he can no longer tell which side he
          is on. The people he loves are on both sides. His grandfathers, his
          teachers, his brothers-in-law, distributed across two armies that are
          about to kill each other.
        </p>

        <p>
          His identity has been built on a network of relationships. When those
          relationships are about to be severed, by his own hand, the self
          built on them begins to dissolve.
        </p>

        <div className="pull-quote">
          <blockquote>
            "Recognize the humanity in every conflict; behind every role is a
            relationship."
          </blockquote>
          <cite>Bhagavad Gita 1.26–27</cite>
        </div>

        {/* DIVIDER */}
        <div className="section-divider">
          <div className="section-divider-line"></div>
          <div className="section-divider-label">
            Verses 1.28–1.30 · Physiological Grief
          </div>
          <div className="section-divider-line"></div>
        </div>

        <h2 id="body">A Body That Doesn't Lie</h2>

        <p>Arjuna doesn't philosophize first. His body responds first.</p>

                <ShlokaCard
          verseRef="Bhagavad Gita 1.29"
          speaker="Arjuna"
          sanskrit="सीदन्ति मम गात्राणि मुखं च परिशुष्यति । वेपथुश्च शरीरे मे रोमहर्षश्च जायते ॥"
          iast="sīdanti mama gātrāṇi mukhaṃ ca pariśuṣyati | vepathuśca śarīre me romaharṣaśca jāyate ||"
          meaning="My limbs give way and fail. My mouth is drying up. My body trembles. My hair stands on end."
          insightLabel="Clinical precision"
          insight="What the Gita describes here is physiologically accurate: vasoconstriction causes skin-crawling sensations, adrenaline causes trembling, saliva production drops. This is an acute stress response, documented with precision 5,000 years before we named it."
          essence="Even the strongest can feel afraid, acknowledge your emotions with honesty."
        />

                <ShlokaCard
          verseRef="Bhagavad Gita 1.30"
          speaker="Arjuna"
          sanskrit="गाण्डीवं स्रंसते हस्तात्त्वक्चैव परिदह्यते । न च शक्नोम्यवस्थातुं भ्रमतीव च मे मनः ॥"
          iast="gāṇḍīvaṃ sraṃsate hastāttvakcaiva paridahyate | na ca śaknomyavasthātuṃ bhramatīva ca me manaḥ ||"
          meaning="The Gandiva slips from my hand. My skin burns all over. I cannot stand. My mind reels and spins."
          insightLabel="Significance"
          insight="Gandiva is not just a bow. It's a divine weapon given by Agni, a symbol of Arjuna's identity as the supreme warrior. When it slips, something more than a weapon is falling. It's the self he has always known."
          essence="In moments of deep confusion and overwhelm, expressing your vulnerability is a sign of true strength."
        />

        <p>
          Two thousand years before the term existed, the Gita is describing a
          panic attack with exact clinical accuracy: vasoconstriction causing
          burning skin, loss of grip strength, inability to stand, mental
          disorientation. The ancient text didn't need the vocabulary, it had
          the observation.
        </p>

        <p>
          And crucially, Arjuna is not ashamed of this. He describes it to
          Krishna plainly. He doesn't suppress it, doesn't try to push through.
          The Gita treats this honesty as important, the necessary first step
          before anything else can be addressed.
        </p>

        {/* DIVIDER */}
        <div className="section-divider">
          <div className="section-divider-line"></div>
          <div className="section-divider-label">
            Verses 1.31–1.44 · The Ethical Argument
          </div>
          <div className="section-divider-line"></div>
        </div>

        <h2 id="argument">The Argument Against Victory</h2>

        <p>
          Here is where Chapter 1 gets underappreciated. Arjuna's arguments from
          verse 31 onward are not the rationalizations of a coward. They are a
          coherent ethical case, and a surprisingly sophisticated one.
        </p>

                <ShlokaCard
          verseRef="Bhagavad Gita 1.32"
          speaker="Arjuna"
          sanskrit="न काङ्क्षे विजयं कृष्ण न च राज्यं सुखानि च । किं नो राज्येन गोविन्द किं भोगैर्जीवितेन वा ॥"
          iast="na kāṅkṣe vijayaṃ kṛṣṇa na ca rājyaṃ sukhāni ca | kiṃ no rājyena govinda kiṃ bhogairjīvitena vā ||"
          meaning="I do not want victory, Krishna. I do not want a kingdom or pleasures. Of what use is a kingdom to us, Govinda? Of what use are enjoyments or even life itself?"
          insightLabel="The inversion"
          insight="This is Arjuna dismantling the entire framework of why they came to fight. Victory, kingdom, enjoyment, the three things warriors fight for. He is renouncing all three in one verse. This is not fear. It is a rejection of the premise."
          essence="True fulfillment comes from living with purpose, not from external success."
        />

                <ShlokaCard
          verseRef="Bhagavad Gita 1.33"
          speaker="Arjuna"
          sanskrit="येषामर्थे काङ्क्षितं नो राज्यं भोगाः सुखानि च । त इमेऽवस्थिता युद्धे प्राणांस्त्यक्त्वा धनानि च ॥"
          iast="yeṣāmarthe kāṅkṣitaṃ no rājyaṃ bhogāḥ sukhāni ca | ta ime'vasthitā yuddhe prāṇāṃstyaktvā dhanāni ca ||"
          meaning="Those for whose sake we desire kingdoms, pleasures, and happiness, they themselves stand here on this battlefield, having given up their desire for life and wealth."
          insightLabel="The logic"
          insight="A crisp consequentialist argument: the beneficiaries of victory are the very people who will die in the pursuit of it. This isn't irrational. This is the observation that the means have devoured the ends, a collapse in the logic of the entire enterprise."
          essence="Meaning lies not in possessions, but in understanding and valuing the people and sacrifices behind them."
        />

                <ShlokaCard
          verseRef="Bhagavad Gita 1.38–1.39"
          speaker="Arjuna"
          sanskrit="यद्यप्येते न पश्यन्ति लोभोपहतचेतसः । कुलक्षयकृतं दोषं मित्रद्रोहे च पातकम् ॥ कथं न ज्ञेयमस्माभिः पापादस्मान्निवर्तितुम् । कुलक्षयकृतं दोषं प्रपश्यद्भिर्जनार्दन ॥"
          iast="yadyapyete na paśyanti lobhopahatacetasaḥ | kulakṣayakṛtaṃ doṣaṃ mitradrohe ca pātakam || kathaṃ na jñeyamasmābhiḥ pāpādasmānnivartitum | kulakṣayakṛtaṃ doṣaṃ prapaśyadbhirjanārdana ||"
          meaning="Even if those whose minds are blinded by greed cannot see the papa in destroying families and betraying friends, how can we, who clearly see the consequences, fail to turn away from this papa, O Janardana?"
          insightLabel="The ethics"
          insight="Arjuna is making a deontological case: if you can see the harm and others cannot, you bear a greater responsibility to act on that knowledge. This is not rationalization. This is conscience. The problem is not that the argument is wrong, it's that Arjuna's 'I' is still attached to the wrong thing."
          essence="Awareness of consequences brings the responsibility to act wisely."
        />

        <p>
          This is not a small point. Arjuna isn't wrong that destroying families
          has generational consequences. He isn't wrong that those who see harm
          more clearly bear greater responsibility. He isn't wrong that victory
          built on killing people you love feels hollow.
        </p>

        <p>
          His arguments fail not because they're incorrect, but because they're
          incomplete. They're rooted in what Krishna will later call
          <em>ahamkara</em>: the ego-self constructed around roles,
          relationships, and outcomes. The "I" that doesn't want to fight is not
          the deepest "I." That's what the next 17 chapters are about.
        </p>

        <p>
          But before you can understand what the self truly is, you have to see
          clearly where the confusion lies. And Chapter 1 is that seeing.
        </p>

        {/* DIVIDER */}
        <div className="section-divider">
          <div className="section-divider-line"></div>
          <div className="section-divider-label">
            Verses 1.45–1.47 · The Final Position
          </div>
          <div className="section-divider-line"></div>
        </div>

        <h2 id="final">
          The Final Choice, <em>Silence and a Bow Set Down</em>
        </h2>

                <ShlokaCard
          verseRef="Bhagavad Gita 1.46"
          speaker="Arjuna"
          sanskrit="यदि मामप्रतीकारमशस्त्रं शस्त्रपाणयः । धार्तराष्ट्रा रणे हन्युस्तन्मे क्षेमतरं भवेत् ॥"
          iast="yadi māmapratīkāramaśastraṃ śastrapāṇayaḥ | dhārtarāṣṭrā raṇe hanyustanme kṣemataraṃ bhavet ||"
          meaning="If the armed sons of Dhritarashtra were to kill me in battle, unresisting, unarmed, even that would be better for me."
          insightLabel="Not cowardice"
          insight="Arjuna is not afraid of death. He's making a principled stand: he would rather be killed than violate his own conscience. This is, in its own way, a warrior's ethic, choosing death over an action that feels wrong. The problem isn't the courage. It's the source of the conviction."
          essence="Strength is found not just in fighting, but in choosing peace over retaliation."
        />

                <ShlokaCard
          verseRef="Bhagavad Gita 1.47"
          sanskrit="सञ्जय उवाच एवमुक्त्वाऽर्जुनः संख्ये रथोपस्थ उपाविशत् । विसृज्य सशरं चापं शोकसंविग्नमानसः ॥"
          iast="sañjaya uvāca evamuktvā'rjunaḥ saṃkhye rathopastha upāviśat | visṛjya saśaraṃ cāpaṃ śokasaṃvignamānasaḥ ||"
          meaning="Sanjaya said: Having spoken thus on the battlefield, Arjuna sat down upon the seat of his chariot, casting aside both bow and arrows, his mind overwhelmed with grief."
          insightLabel="The end of Chapter 1"
          insight="Sanjaya narrates this to the blind king with journalistic calm. The greatest teacher in Sanskrit literature sits next to the greatest student. The student has his face in his hands. This is where Chapter 1 ends, not with resolution, but with the question fully formed and held."
          essence="Even our heroes face moments of deep inner struggle; pausing and accepting our feelings is a vital part of the journey."
        />

        <p>
          Sanjaya's narration ends here. Chapter 1's last image is Arjuna,
          seated, bow and arrows set aside, mind overwhelmed with grief, <em>śokasaṃvignamānasaḥ</em>. The compound word is worth sitting with:
          <em>shoka</em> (grief) + <em>samvigna</em> (agitated, disturbed) +
          <em>manasah</em> (of the mind). A mind disturbed by grief. Not
          defeated. Not wrong. Simply, brought to a stop.
        </p>

        {/* DIVIDER */}
        <div className="section-divider">
          <div className="section-divider-line"></div>
          <div className="section-divider-label">
            What This Chapter Is Really Doing
          </div>
          <div className="section-divider-line"></div>
        </div>

        <h2 id="why">Why Vyasa Spent 47 Verses on the Crisis</h2>

        <p>
          The Gita could have begun at Chapter 2. Krishna could have started
          teaching the moment Arjuna felt uncertain. Vyasa chose differently. He
          spent an entire chapter, 47 verses, documenting the collapse in full
          before a single word of teaching appears.
        </p>

        <p>
          This is not literary inefficiency. It's the most important structural
          choice in the text.
        </p>

        <p>
          Because wisdom that arrives before the question has weight doesn't
          land. It bounces off. Arjuna needed to be fully in his confusion, body, mind, ethics, grief, all of it, before he could receive what
          Krishna was about to say.
        </p>

        <p>
          The same is true of every genuine inquiry. You can read about the
          nature of the self, detachment, duty, and the atman. You can
          understand it intellectually. But it becomes real only when you've
          been brought to the edge of something, when your identity has been
          challenged, when the person you thought you were can no longer give
          you direction.
        </p>

        <p>
          Arjuna's mistake in Chapter 1 is not that he feels grief. It's that he
          has confused his roles with his essence. He is a son, a student, a
          friend, a warrior, and when those roles collide, there is no deeper
          "I" to navigate from. The grief of Chapter 1 is the grief of a self
          built entirely on circumstances, confronting circumstances it cannot
          handle.
        </p>

        <p>
          What Krishna teaches from Chapter 2 onward is how to find the self
          that is not built on circumstances at all.
        </p>

        <p>
          But that teaching requires this, the complete, honest, unsparing
          account of what collapse looks like. That's what Chapter 1 gives us.
        </p>

        <div className="pull-quote">
          <blockquote>
            "Wisdom only becomes real when you've been brought to your knees by
            its absence. Arjuna's collapse in Chapter 1 is what makes Krishna's
            answers in the chapters that follow carry any weight at all."
          </blockquote>
          <cite>On Bhagavad Gita, Chapter 1</cite>
        </div>

        {/* ── KEY INSIGHTS ── */}
        <div className="insights-box">
          <div className="insights-label">
            What Bhagavad Gita Chapter 1 teaches, 5 core insights
          </div>
          <ol className="insights-list">
            <li>
              <strong>Attachment distorts perception.</strong> The Gita's very
              first line, a blind king asking "what did mine do?", shows that
              attachment shapes the questions we ask before we even begin to
              act.
            </li>
            <li>
              <strong
                >Grief is not the opposite of wisdom, it is its
                precondition.</strong
              >
              Arjuna's vishada (despondency) is the titled subject of the
              chapter. The Gita treats his breakdown as the necessary starting
              point, not a failure to overcome.
            </li>
            <li>
              <strong
                >The body registers moral crisis before the mind does.</strong
              >
              In 1.29–1.30, Arjuna describes trembling, dry mouth, burning skin,
              and a bow slipping from his hand, a physiological stress response
              documented with clinical precision thousands of years before
              modern neuroscience.
            </li>
            <li>
              <strong
                >A coherent ethical argument can still be rooted in the wrong
                identity.</strong
              >
              Arjuna's case against fighting is not irrational, but it is built
              on attachment to roles (son, student, friend) rather than on a
              deeper understanding of the self. That is what Krishna addresses
              in Chapter 2.
            </li>
            <li>
              <strong>The question matters as much as the answer.</strong> Vyasa
              spent an entire chapter, 47 verses, establishing the crisis
              before Krishna speaks a single word of teaching. The weight of the
              answer depends entirely on the depth of the question.
            </li>
          </ol>
        </div>

        {/* ── ALL 47 VERSES SUMMARY ── */}
        <div className="section-divider">
          <div className="section-divider-line"></div>
          <div className="section-divider-label">
            All 47 Verses, Quick Reference
          </div>
          <div className="section-divider-line"></div>
        </div>

        <h2 id="all-verses">
          Bhagwat Geeta Adhyay 1, All 47 Shlokas at a Glance
        </h2>

        <p>
          All 47 verses of Arjuna Vishada Yoga (Bhagavad Gita Chapter 1),
          organised by speaker and theme:
        </p>

        <table className="verse-table">
          <thead>
            <tr>
              <th>Verses</th>
              <th>Speaker</th>
              <th>What Happens</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>1.1</td>
              <td>Dhritarashtra</td>
              <td>
                The blind king's opening question, "mine and Pandu's sons"
              </td>
            </tr>
            <tr>
              <td>1.2–11</td>
              <td>Duryodhana / Sanjaya</td>
              <td>
                Duryodhana surveys Pandava army, reports to Drona, assesses both
                forces
              </td>
            </tr>
            <tr>
              <td>1.12–19</td>
              <td>Sanjaya</td>
              <td>
                Bhishma blows his conch; both armies respond with war cries and
                instruments
              </td>
            </tr>
            <tr>
              <td>1.20–23</td>
              <td>Sanjaya / Arjuna</td>
              <td>
                Arjuna lifts his bow, then asks Krishna to place the chariot
                between the armies
              </td>
            </tr>
            <tr>
              <td>1.24–25</td>
              <td>Sanjaya</td>
              <td>
                Krishna positions the chariot; Arjuna sees the armies arrayed
              </td>
            </tr>
            <tr>
              <td>1.26–27</td>
              <td>Sanjaya</td>
              <td>
                Arjuna recognises relatives on both sides, overcome with
                compassion
              </td>
            </tr>
            <tr>
              <td>1.28–46</td>
              <td>Arjuna</td>
              <td>
                Arjuna's grief, physical symptoms, ethical arguments, final
                refusal
              </td>
            </tr>
            <tr>
              <td>1.47</td>
              <td>Sanjaya</td>
              <td>Arjuna sets down his bow. Chapter 1 ends.</td>
            </tr>
          </tbody>
        </table>
      </article>

      {/* ── FAQ ── */}
      {/* ── WISDOM ENTITY DESCRIPTION (for AI extraction) ── */}
      <div className="wisdom-entity">
        <div className="wisdom-entity-label">About the Wisdom App</div>
        <h3>What is the Wisdom app?</h3>
        <p>
          <strong>Wisdom</strong> is an iPhone app that tunes the Bhagavad Gita
          to your life. You say how you feel and what is going on, and it picks
          the verse that speaks to it, with the original Sanskrit, a plain
          English meaning and what it says for you. Then it builds a 7-day plan
          around your situation, read aloud, drawing on the Gita, the Ramayana
          and the Mahabharata. Today&apos;s shloka also sits on your Home Screen
          and Lock Screen.
        </p>
        <p>
          Wisdom is for people who want the Gita&apos;s answer to the week they
          are actually having, not a poster quote. Week 1 is free on the
          <a
            href={appStoreUrl('web_blog_footer')}
            target="_blank"
            rel="noopener"
            data-mp-location="about_app"
            >Apple App Store</a>.
        </p>
      </div>


      <FeedbackWidget pageType="blog" />
      <div className="faq-section" id="faq">
        <div className="faq-header">
          <div className="faq-header-label">Frequently Asked Questions</div>
          <h2>Bhagavad Gita Chapter 1, Common Questions</h2>
        </div>

        <div className="faq-item">
          <div className="faq-q">What is Bhagavad Gita Chapter 1 about?</div>
          <div className="faq-a">
            Bhagavad Gita Chapter 1, called Arjuna Vishada Yoga, describes the
            scene on the battlefield of Kurukshetra just before the great war
            begins. Arjuna, the greatest archer of his age, sees his relatives
            and teachers arrayed on both sides, is overcome with grief and moral
            doubt, and ultimately sets down his bow and refuses to fight. The
            chapter establishes the profound ethical crisis that makes Krishna's
            teachings in the chapters that follow both necessary and meaningful.
          </div>
        </div>

        <div className="faq-item">
          <div className="faq-q">What does "Arjuna Vishada Yoga" mean?</div>
          <div className="faq-a">
            Arjuna Vishada Yoga means the yoga of Arjuna's grief, or the yoga of
            Arjuna's despondency. In Sanskrit, vishada means deep sorrow or
            distress, and yoga here means a path or discipline, not exercise.
            The title implies that Arjuna's grief itself is a doorway: his
            collapse is what opens the space for Krishna's teaching. Without the
            depth of the question, the answers would have no ground to land on.
          </div>
        </div>

        <div className="faq-item">
          <div className="faq-q">
            How many verses are in Chapter 1 of the Bhagavad Gita?
          </div>
          <div className="faq-a">
            Bhagavad Gita Chapter 1 has 47 verses (shlokas). It is the shortest
            chapter philosophically, none of Krishna's direct teachings appear
            yet, but among the most important for establishing the
            psychological and ethical context for everything that follows in the
            remaining 17 chapters.
          </div>
        </div>

        <div className="faq-item">
          <div className="faq-q">Why does Arjuna refuse to fight in Chapter 1?</div>
          <div className="faq-a">
            Arjuna refuses to fight because he sees his own relatives, grandfathers, teachers, uncles, brothers, friends, arrayed on both
            sides of the battlefield. He argues that victory is meaningless if
            it requires killing the people he loves, that destroying families
            unravels the ethical fabric of society, and that dying unarmed would
            be preferable to this. His arguments are ethically sophisticated
            rather than cowardly, but they are rooted in attachment to his
            roles as a son, student, and friend rather than to his deeper
            identity beyond those roles.
          </div>
        </div>

        <div className="faq-item">
          <div className="faq-q">
            What physical symptoms does Arjuna describe in Chapter 1?
          </div>
          <div className="faq-a">
            In verses 1.29–1.30, Arjuna describes his limbs going weak, his
            mouth drying up, his body trembling, his hair standing on end, his
            skin burning all over, his famous bow Gandiva slipping from his
            hands, and his mind reeling in confusion. These are precise
            descriptions of an acute stress response, the physiological
            signature of grief, anxiety, and moral distress, documented with
            clinical accuracy thousands of years before modern psychology named
            them.
          </div>
        </div>

        <div className="faq-item">
          <div className="faq-q">Who speaks first in the Bhagavad Gita?</div>
          <div className="faq-a">
            The very first words of the Bhagavad Gita are spoken by King
            Dhritarashtra, the blind father of the Kauravas. He asks his advisor
            Sanjaya what happened after both armies assembled on the battlefield
            of Kurukshetra. The Gita's opening is not a teaching, it is a
            question already loaded with a father's blind attachment to his own
            children, introducing the text's central theme of attachment before
            philosophy even begins.
          </div>
        </div>

        <div className="faq-item">
          <div className="faq-q">What does "dharma-kshetra kuru-kshetra" mean?</div>
          <div className="faq-a">
            The opening line of the Bhagavad Gita describes Kurukshetra as
            dharma-kshetra, the field of dharma, or the field of righteousness.
            The battlefield is not just a physical location; it is presented as
            a place where the fundamental question of right action must be
            confronted directly. This framing immediately establishes that what
            follows is not merely a war story, but a philosophical reckoning
            with duty, conscience, and what it means to act rightly.
          </div>
        </div>

        <div className="faq-item">
          <div className="faq-q">
            Is Bhagavad Gita Chapter 1 the most important chapter?
          </div>
          <div className="faq-a">
            Chapter 2 is typically considered the philosophical heart of the
            Gita, and later chapters go deeper into yoga, devotion, and
            metaphysics. But Chapter 1 may be the most humanly important, because it establishes the crisis that makes all wisdom necessary. A
            teaching without a felt question is just information. Arjuna's
            collapse in Chapter 1 is what gives Krishna's answers in the
            chapters that follow their actual weight.
          </div>
        </div>

        <div className="faq-item">
          <div className="faq-q">What does the Bhagavad Gita say about grief?</div>
          <div className="faq-a">
            The Bhagavad Gita takes grief seriously, it opens with it. Arjuna's
            despondency in Chapter 1 is treated not as weakness to be dismissed,
            but as the necessary starting point for transformation. The Sanskrit
            word vishada (grief or despondency) appears in the title of Chapter
            1 itself. The Gita's approach is that genuine understanding can only
            begin after you have honestly confronted your own confusion and
            pain, without suppression or avoidance.
          </div>
        </div>

        <div className="faq-item">
          <div className="faq-q">
            What is the most famous shloka in Bhagavad Gita Chapter 1?
          </div>
          <div className="faq-a">
            While Chapter 2 contains the Gita's most frequently cited verses
            (such as 2.47, the karma yoga verse), Chapter 1's most quoted
            shlokas include 1.1 (the opening question), 1.29–1.30 (Arjuna's
            physical symptoms), and 1.32, "I do not desire victory, nor
            kingdom, nor pleasures." Verse 1.47, the chapter's closing image of
            Arjuna setting down his bow, is also widely cited as one of the most
            emotionally resonant moments in Sanskrit literature.
          </div>
        </div>
      </div>

        <VerseFunnelCTA variant="chapter" locale="en" pageName={"Bhagwat Geeta Chapter 1"} />


      {/* ── CHAPTER NAV ── */}
      <div className="chapter-nav">
        <div>
          <div className="ch-nav-label">← Previous</div>
          <div
            className="ch-nav-title"
            style={{color: 'var(--muted-2)', fontSize: '13px'}}
          >
            Chapter 1 is the first
          </div>
        </div>
        <div style={{textAlign: 'right'}}>
          <div className="ch-nav-label">Next →</div>
          <span
            className="ch-nav-title"
            style={{fontSize: '14px', color: 'var(--muted-2)'}}
            >Chapter 2, Sankhya Yoga
            <span style={{fontSize: '11px', fontWeight: '400'}}
              >(coming soon)</span
            ></span
          >
        </div>
      </div>

      {/* ── RELATED ── */}
      <div className="related-section">
        <h3>More from the Bhagavad Gita</h3>
        <div className="related-grid">
          <a href="/blogs" className="related-card">
            <div className="related-card-label">Shloka Collection</div>
            <div className="related-card-title">
              Bhagwat Geeta Shlokas in Sanskrit, 20 Key Verses
              <span
                style={{color: 'var(--muted-2)', fontSize: '11px', fontWeight: '400', display: 'block', marginTop: '4px'}}
                >Coming soon</span
              >
            </div>
          </a>
          <a href="/blogs" className="related-card">
            <div className="related-card-label">Teaching</div>
            <div className="related-card-title">
              Karma Quotes from the Bhagavad Gita, What Krishna Actually Said
              <span
                style={{color: 'var(--muted-2)', fontSize: '11px', fontWeight: '400', display: 'block', marginTop: '4px'}}
                >Coming soon</span
              >
            </div>
          </a>
          <a href="/blogs" className="related-card">
            <div className="related-card-label">Guide</div>
            <div className="related-card-title">
              Bhagwat Geeta Saar, The Complete Essence in Plain Language
              <span
                style={{color: 'var(--muted-2)', fontSize: '11px', fontWeight: '400', display: 'block', marginTop: '4px'}}
                >Coming soon</span
              >
            </div>
          </a>
          <a href="/blogs" className="related-card">
            <div className="related-card-label">Blog</div>
            <div className="related-card-title">
              All Articles, Bhagavad Gita & Hindu Philosophy
            </div>
          </a>
        </div>
      </div>
    </div>
    {/* /article-wrap */}

    {/* ── FOOTER ── */}
    <footer>
      <p>
        Wisdom App ·
        <span>Daily shlokas from the Bhagavad Gita & Hindu scriptures</span>
        · Free on iPhone
      </p>
      <p style={{marginTop: '8px'}}>
        <a href="/">wisdomquotes.in</a>  · 
        <a
          href={appStoreUrl('web_blog_footer')}
          target="_blank"
          rel="noopener"
          data-mp-location="footer_app_store"
          >App Store</a>
         ·  <a href="/privacy">Privacy</a>  ·  <a href="/terms">Terms</a>  ·  <a href="mailto:work.ankurshukla@gmail.com">Support</a>
      </p>
    </footer>

    

      <BlogTracker pageName="Bhagwat Geeta Chapter 1" />
    </>
  )
}