import type { Metadata } from 'next'
import BlogTracker from '@/components/BlogTracker'
import FeedbackWidget from '@/components/FeedbackWidget'
import ShlokaCard from '@/components/gita/ShlokaCard'
import VerseFunnelCTA from '@/components/funnel/VerseFunnelCTA'
import { appStoreUrl } from '@/lib/app'

export const metadata: Metadata = {
  title: "Bhagavad Gita Chapter 8 Summary – Key Verses & Meaning (Akshara Brahma Yoga)",
  description: "Whatever you think of at the moment of death — that you become. Bhagavad Gita Chapter 8 on death, rebirth, and the imperishable Brahman. All 28 verses in Sanskrit, Hindi and English.",
  keywords: "bhagwat geeta chapter 8, bhagavad gita akshara brahma yoga, bhagwat geeta adhyay 8, death in bhagavad gita, brahma kalpa days nights, supreme abode gita, antakale ca mam eva smaran, mind at the moment of death gita, Akshara Brahma Yoga meaning, Bhagavad Gita 8.5 anta kale ca mam eva smaran, Bhagavad Gita 8.6 meaning, what is the supreme abode in Bhagavad Gita, Brahma's day and night Bhagavad Gita, om iti ekaksharam brahma",
  openGraph: {
    title: "Bhagavad Gita Chapter 8 Summary – Key Verses & Meaning (Akshara Brahma Yoga)",
    description: "Bhagavad Gita Chapter 8, what the mind has practiced, the moment of death, and the imperishable destination.",
    type: 'article',
    url: "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-8",
    siteName: 'Wisdom',
    locale: 'en_IN',
    images: [{ url: "https://wisdomquotes.in/assets/chapter8.webp", width: 1200, height: 675, alt: "Light dispersing into the eternal, Chapter 8 of the Bhagavad Gita teaches Akshara Brahma Yoga: the imperishable, the moment of death, and what the mind has practiced." }],
  },
  twitter: {
    card: 'summary_large_image',
    title: "Bhagavad Gita Chapter 8 Summary – Key Verses & Meaning (Akshara Brahma Yoga)",
    description: "Bhagavad Gita Chapter 8, what the mind has practiced, the moment of death, and the imperishable destination.",
    images: ["https://wisdomquotes.in/assets/chapter8.webp"],
  },
  alternates: { canonical: "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-8", languages: { 'x-default': 'https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-8' } },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, 'max-image-preview': 'large', 'max-snippet': -1 },
  },
  other: { "rel=prev": "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-7", "rel=next": "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-9" },
}

const pageCSS = `

      :root {
        --maroon: #3d0c0c;
        --maroon-mid: #5c1a1a;
        --gold: #c8881e;
        --gold-light: #f5c96a;
        --gold-pale: #fdf3dc;
        --gold-border: #e8c97a;
        --gold-dim: rgba(200, 136, 30, 0.15);
        --text: #f5e8cc;
        --text-dim: rgba(245, 232, 204, 0.65);
        --text-dimmer: rgba(245, 232, 204, 0.35);
        --muted-2: rgba(245, 232, 204, 0.35);
        --border: rgba(200, 136, 30, 0.2);
        --bg: #120505;
        --bg-warm: #190707;
        --bg-alt: #0f0404;
        --bg-card: rgba(255, 255, 255, 0.04);
        --bg-card-hover: rgba(255, 255, 255, 0.07);
        --max: 780px;
      }

      *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
      html { scroll-behavior: smooth; scroll-padding-top: 88px; }

      body {
        font-family: "Inter", system-ui, -apple-system, sans-serif;
        background: var(--bg);
        color: var(--text);
        line-height: 1.7;
        -webkit-font-smoothing: antialiased;
      }

      a { color: inherit; text-decoration: none; }
      img { display: block; max-width: 100%; }

      .breadcrumb { background: var(--bg-alt); border-bottom: 1px solid var(--border); }
      .breadcrumb-inner { max-width: 1100px; margin: 0 auto; padding: 10px 28px;
        font-size: 12px; color: var(--text-dimmer); display: flex; gap: 8px; align-items: center; }
      .breadcrumb-inner a { color: var(--text-dimmer); transition: color 0.15s; }
      .breadcrumb-inner a:hover { color: var(--gold-light); }
      .bc-sep { opacity: 0.4; }

      .article-hero {
        background: var(--bg-warm); padding: 64px 28px 56px;
        border-bottom: 1px solid var(--border); position: relative; overflow: hidden;
      }
      .article-hero::before {
        content: "अध्याय ८";
        position: absolute; right: -10px; bottom: -20px;
        font-family: "Noto Sans Devanagari", serif; font-size: 180px;
        color: rgba(200, 136, 30, 0.04); line-height: 1; pointer-events: none; user-select: none;
      }
      .article-hero-inner { max-width: 1100px; margin: 0 auto; position: relative; z-index: 2; }

      .chapter-badge { display: inline-flex; align-items: center; gap: 8px;
        background: rgba(200, 136, 30, 0.1); border: 1px solid rgba(200, 136, 30, 0.28);
        color: var(--gold-light); font-size: 11px; font-weight: 700; letter-spacing: 0.12em;
        text-transform: uppercase; padding: 5px 14px; border-radius: 100px; margin-bottom: 20px; }
      .chapter-badge-dot { width: 5px; height: 5px; border-radius: 50%; background: var(--gold);
        box-shadow: 0 0 6px var(--gold); flex-shrink: 0; }
      .article-title { font-family: "Playfair Display", Georgia, serif;
        font-size: clamp(28px, 4vw, 48px); font-weight: 700; color: var(--gold-light);
        line-height: 1.15; letter-spacing: -0.5px; margin-bottom: 12px; }
      .article-title em { font-style: italic; color: #fff; }
      .article-subtitle { font-size: 17px; color: var(--text-dim); font-weight: 300;
        margin-bottom: 32px; line-height: 1.65; max-width: 580px; }
      .article-meta { display: flex; align-items: center; gap: 16px; flex-wrap: wrap; }
      .meta-item { font-size: 12px; color: var(--text-dimmer); letter-spacing: 0.04em; }
      .meta-sep { color: var(--border); }

      .article-wrap { max-width: var(--max); margin: 0 auto; padding: 60px 28px 80px; }

      .chapter-image {
        margin: 0 0 36px;
        border-radius: 14px;
        overflow: hidden;
        border: 1px solid var(--border);
        background: var(--bg-warm);
        box-shadow: 0 24px 48px rgba(0, 0, 0, 0.4);
      }
      .chapter-image img { display: block; width: 100%; height: auto; aspect-ratio: 16 / 9; object-fit: cover; }

      .prose h2 { font-family: "Playfair Display", Georgia, serif; font-size: 26px; font-weight: 700;
        color: var(--gold-light); margin: 52px 0 16px; line-height: 1.25; }
      .prose h2[id], .faq-section[id], .related-reading[id] { scroll-margin-top: 88px; }
      .prose h2 em { font-style: italic; color: #fff; }

      .prose h3 { font-family: "Playfair Display", Georgia, serif; font-size: 19px; font-weight: 700;
        color: var(--text); margin: 32px 0 12px; }

      .prose p { font-size: 16.5px; line-height: 1.78; color: var(--text-dim); margin-bottom: 20px; }
      .prose p:last-child { margin-bottom: 0; }
      .prose strong { font-weight: 600; color: var(--text); }
      .prose em { font-style: italic; }
      .lead { font-size: 19px; line-height: 1.7; color: var(--text); font-weight: 300; margin-bottom: 28px; }

      .toc { background: var(--bg-card); border: 1px solid var(--border);
        border-left: 3px solid var(--gold); border-radius: 0 12px 12px 0;
        padding: 20px 24px; margin: 36px 0 40px; }
      .toc-label { font-size: 9.5px; letter-spacing: 0.18em; text-transform: uppercase;
        font-weight: 700; color: var(--gold); margin-bottom: 12px; }
      .toc-list { list-style: none; display: flex; flex-direction: column; gap: 7px; counter-reset: toc-counter; }
      .toc-list li { counter-increment: toc-counter; display: flex; align-items: baseline; gap: 10px; }
      .toc-list li::before { content: counter(toc-counter); font-family: "Inter", sans-serif;
        font-size: 10px; font-variant-numeric: tabular-nums; color: var(--text-dimmer); min-width: 14px; }
      .toc-list a { font-size: 13.5px; color: var(--text-dim); line-height: 1.4; transition: color 0.15s; }
      .toc-list a:hover { color: var(--gold-light); }

      .pull-quote { margin: 40px 0; padding: 28px 32px; border-left: 3px solid var(--gold);
        background: rgba(200, 136, 30, 0.05); border-radius: 0 12px 12px 0; }
      .pull-quote blockquote { font-family: "Playfair Display", serif; font-size: 21px;
        font-style: italic; color: var(--gold-light); line-height: 1.5; margin-bottom: 10px; }
      .pull-quote cite { font-size: 12px; letter-spacing: 0.1em; text-transform: uppercase;
        color: var(--gold); font-style: normal; font-weight: 600; }

      .section-divider { display: flex; align-items: center; gap: 16px; margin: 56px 0 40px; }
      .section-divider-line { flex: 1; height: 1px; background: var(--border); }
      .section-divider-label { font-size: 10px; letter-spacing: 0.18em; text-transform: uppercase;
        color: var(--text-dimmer); white-space: nowrap; font-weight: 600; }

      .highlight-box { background: rgba(200, 136, 30, 0.05); border: 1px solid var(--border);
        border-left: 3px solid var(--gold); border-radius: 0 10px 10px 0;
        padding: 20px 24px; margin: 28px 0; }
      .highlight-box p { font-size: 15px; line-height: 1.7; color: var(--text-dim); }
      .highlight-box strong { color: var(--gold-light); }

      .verse-table { width: 100%; border-collapse: collapse; font-size: 13.5px;
        margin: 28px 0 40px; border: 1px solid var(--border); border-radius: 10px; overflow: hidden; }
      .verse-table thead tr { background: rgba(200, 136, 30, 0.08); }
      .verse-table thead th { text-align: left; padding: 12px 16px; font-size: 9.5px;
        letter-spacing: 0.15em; text-transform: uppercase; color: var(--gold); font-weight: 700; }
      .verse-table tbody td { padding: 10px 16px; border-bottom: 1px solid var(--border);
        vertical-align: top; line-height: 1.55; color: var(--text-dim); }
      .verse-table tbody tr:last-child td { border-bottom: none; }
      .verse-table tbody tr:hover { background: var(--bg-card); }
      .verse-table td:first-child { font-size: 12px; color: var(--gold); font-weight: 600; white-space: nowrap; }

      .faq-section { background: var(--bg-card); border: 1px solid var(--border);
        border-top: 2px solid var(--gold); border-radius: 14px; overflow: hidden; margin: 48px 0; }
      .faq-header { padding: 28px 32px 20px; border-bottom: 1px solid var(--border); }
      .faq-header-label { font-size: 10px; letter-spacing: 0.2em; text-transform: uppercase;
        color: var(--gold); font-weight: 700; margin-bottom: 6px; }
      .faq-header h2 { font-family: "Playfair Display", serif; font-size: 22px; font-weight: 700;
        color: var(--gold-light); line-height: 1.3; margin: 0; }
      .faq-item { padding: 22px 32px; border-bottom: 1px solid var(--border); }
      .faq-item:last-child { border-bottom: none; }
      .faq-q { font-size: 15px; font-weight: 600; color: var(--text); margin-bottom: 10px; line-height: 1.4; }
      .faq-a { font-size: 14.5px; line-height: 1.72; color: var(--text-dim); }

      .related-reading { background: var(--bg-card); border: 1px solid var(--border);
        border-top: 2px solid var(--gold); border-radius: 14px; padding: 28px 32px;
        margin: 48px 0; }
      .related-reading-label { font-size: 10px; letter-spacing: 0.2em; text-transform: uppercase;
        color: var(--gold); font-weight: 700; margin-bottom: 6px; }
      .related-reading h2 { font-family: "Playfair Display", serif; font-size: 22px; font-weight: 700;
        color: var(--gold-light); line-height: 1.3; margin: 0 0 18px; }
      .related-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
      .related-card { display: block; background: var(--bg); border: 1px solid var(--border);
        border-radius: 10px; padding: 14px 18px; transition: border-color 0.15s, background 0.15s, transform 0.15s; }
      .related-card:hover { border-color: var(--gold); background: var(--bg-card-hover); transform: translateY(-2px); }
      .related-card-label { font-size: 10px; letter-spacing: 0.15em; text-transform: uppercase;
        color: var(--text-dimmer); font-weight: 600; margin-bottom: 4px; }
      .related-card-title { font-size: 14px; font-weight: 600; color: var(--text); line-height: 1.4; }

      .app-cta { background: linear-gradient(160deg, #2d0a0a 0%, #1a0606 100%);
        border: 1px solid rgba(200, 136, 30, 0.25); border-top: 3px solid var(--gold);
        border-radius: 20px; padding: 44px 48px 40px; margin: 48px 0 60px;
        text-align: center; position: relative; overflow: hidden; }
      .app-cta::before { content: "अक्षर"; position: absolute; top: -14px; right: -8px;
        font-family: "Noto Sans Devanagari", sans-serif; font-size: 130px;
        color: rgba(200, 136, 30, 0.05); line-height: 1; pointer-events: none; user-select: none; }
      .app-cta-eyebrow { display: inline-flex; align-items: center; background: rgba(200, 136, 30, 0.12);
        border: 1px solid rgba(200, 136, 30, 0.35); color: var(--gold-light); font-size: 11px;
        font-weight: 600; letter-spacing: 0.14em; text-transform: uppercase; padding: 5px 14px;
        border-radius: 20px; margin-bottom: 20px; }
      .app-cta-headline { font-family: "Playfair Display", serif;
        font-size: clamp(22px, 3vw, 30px); font-weight: 700; color: var(--text);
        line-height: 1.25; margin-bottom: 14px; }
      .app-cta-desc { font-size: 15px; color: var(--text-dim); line-height: 1.7;
        max-width: 480px; margin: 0 auto 22px; }
      .app-cta-features { display: flex; gap: 6px 18px; justify-content: center;
        flex-wrap: wrap; margin-bottom: 28px; }
      .app-cta-features span { font-size: 13px; color: var(--gold-light); opacity: 0.8; }
      .app-cta-btn { display: inline-flex; align-items: center; gap: 10px;
        background: var(--gold); color: #120505; text-decoration: none;
        padding: 15px 34px; border-radius: 12px; font-size: 16px; font-weight: 700;
        letter-spacing: -0.01em; transition: all 0.2s;
        box-shadow: 0 4px 22px rgba(200, 136, 30, 0.3); }
      .app-cta-btn:hover { background: var(--gold-light); transform: translateY(-2px);
        box-shadow: 0 8px 32px rgba(200, 136, 30, 0.5); }
      .app-cta-sub { font-size: 12px; color: rgba(245, 232, 204, 0.35); margin-top: 14px; letter-spacing: 0.04em; }

      .chapter-nav { display: flex; justify-content: space-between; align-items: center;
        gap: 16px; padding: 20px 0; border-top: 1px solid var(--border);
        border-bottom: 1px solid var(--border); margin: 0 0 40px; }
      .ch-nav-label { font-size: 11px; letter-spacing: 0.1em; text-transform: uppercase;
        color: var(--text-dimmer); font-weight: 600; margin-bottom: 4px; }
      .ch-nav-title { font-size: 14px; font-weight: 600; color: var(--text); }

      footer { background: var(--bg-alt); border-top: 1px solid var(--border);
        padding: 32px 28px; text-align: center; font-size: 12px;
        letter-spacing: 0.06em; color: var(--text-dimmer); }
      footer a { color: var(--text-dimmer); transition: color 0.15s; }
      footer a:hover { color: var(--gold-light); }
      footer span { color: var(--gold); }

      @media (max-width: 700px) {
        .article-hero { padding: 44px 20px 40px; }
        .article-wrap { padding: 40px 20px 60px; }
        .app-cta { padding: 32px 24px; }
        .pull-quote { padding: 22px 24px; }
        .faq-header, .faq-item { padding-left: 20px; padding-right: 20px; }
        .related-grid { grid-template-columns: 1fr; }
      }

`

const schemas = [
  {
    "@context": "https://schema.org",
    "@type": [
      "Article",
      "LearningResource"
    ],
    "headline": "Bhagavad Gita Chapter 8 — Akshara Brahma Yoga: What the Mind Has Practiced",
    "description": "Bhagavad Gita Chapter 8 — Akshara Brahma Yoga. All 28 verses on the imperishable Brahman, the state at death, Brahma's day, and the path beyond return.",
    "alternativeHeadline": "Bhagavad Gita Chapter 8 (Akshara Brahma Yoga) — All Verses",
    "author": {
    "@type": "Person",
    "name": "Ankur Shukla",
    "url": "https://wisdomquotes.in/about",
    "sameAs": [
      "https://www.linkedin.com/in/thisisashukla/",
      "https://x.com/thisisashukla"
    ]
  },
    "publisher": {
      "@type": "Organization",
      "name": "Wisdom",
      "url": "https://wisdomquotes.in",
      "logo": {
        "@type": "ImageObject",
        "url": "https://wisdomquotes.in/assets/new-light-logo.webp"
      }
    },
    "image": {
      "@type": "ImageObject",
      "url": "https://wisdomquotes.in/assets/chapter8.webp",
      "width": 1200,
      "height": 675
    },
    "datePublished": "2026-05-18",
    "dateModified": "2026-05-18",
    "mainEntityOfPage": {
      "@type": "WebPage",
      "@id": "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-8"
    },
    "about": [
      {
        "@type": "Book",
        "name": "Bhagavad Gita",
        "author": {
          "@type": "Person",
          "name": "Ved Vyasa"
        },
        "url": "https://wisdomquotes.in/gita"
      },
      {
        "@type": "Person",
        "name": "Krishna",
        "url": "https://en.wikipedia.org/wiki/Krishna"
      },
      {
        "@type": "Person",
        "name": "Arjuna",
        "url": "https://en.wikipedia.org/wiki/Arjuna"
      }
    ],
    "keywords": "bhagwat geeta chapter 8, bhagavad gita akshara brahma yoga, bhagwat geeta adhyay 8, death in bhagavad gita, brahma kalpa days nights, supreme abode gita, antakale ca mam eva smaran, mind at the moment of death gita, Akshara Brahma Yoga meaning, Bhagavad Gita 8.5 anta kale ca mam eva smaran, Bhagavad Gita 8.6 meaning, what is the supreme abode in Bhagavad Gita, Brahma's day and night Bhagavad Gita, om iti ekaksharam brahma",
    "articleSection": "Bhagavad Gita",
    "wordCount": 2407,
    "inLanguage": "en",
    "isAccessibleForFree": true,
    "learningResourceType": "Article",
    "educationalLevel": "General",
    "speakable": {
      "@type": "SpeakableSpecification",
      "cssSelector": [
        ".lead",
        ".shloka-meaning",
        ".shloka-essence"
      ]
    }
  },
  {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [
      {
        "@type": "ListItem",
        "position": 1,
        "name": "Wisdom",
        "item": "https://wisdomquotes.in/"
      },
      {
        "@type": "ListItem",
        "position": 2,
        "name": "Blog",
        "item": "https://wisdomquotes.in/blogs"
      },
      {
        "@type": "ListItem",
        "position": 3,
        "name": "Bhagavad Gita Chapter 8 — Akshara Brahma Yoga",
        "item": "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-8"
      }
    ]
  },
  {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": "What is Bhagavad Gita Chapter 8 about?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Chapter 8 (Akshara Brahma Yoga) is the Gita's chapter on death — and therefore on every moment that is not yet death. Krishna defines seven key spiritual terms, then teaches that the state of mind at the end of life is the cumulative output of everything the mind has practiced. The chapter contains the famous teaching of 8.6 — that whatever state a person remembers at the end is the state they reach. It also introduces Brahma's day and night, the imperishable destination from which one does not return, and the two paths after death."
        }
      },
      {
        "@type": "Question",
        "name": "What does Bhagavad Gita 8.6 mean?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Verse 8.6 says, 'Whatever state of being one remembers when leaving the body, that state one attains, because the mind has long been shaped by it.' It is not a verse about being dramatic in the final moment. It is a verse about training. The mind at the end is the mind you have trained — by what it has repeatedly returned to in life. The end is the cumulative output of practice, not a separate event."
        }
      },
      {
        "@type": "Question",
        "name": "What is the meaning of antakale ca mam eva smaran?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "This is the opening phrase of verse 8.5 — 'at the end, remembering me alone.' Krishna says one who departs while remembering him reaches his state. But the very next verse clarifies that this end-remembrance is only possible for the mind that has long practiced it. You cannot install a new attention pattern at the last moment. The teaching is about lifelong rehearsal, not a deathbed manoeuvre."
        }
      },
      {
        "@type": "Question",
        "name": "What are Brahma's day and night in the Bhagavad Gita?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "In verses 8.17-19, Krishna describes Brahma's day as lasting a thousand yugas, and his night as lasting another thousand. At the start of Brahma's day, all beings emerge from the unmanifest. At nightfall, they dissolve back. The teaching is partly cosmology and partly therapeutic — it widens the frame so that ordinary urgency stops feeling cosmic. The Gita uses scale to dissolve panic."
        }
      },
      {
        "@type": "Question",
        "name": "What is the supreme abode (paramam dhama) in the Bhagavad Gita?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Verse 8.21 calls the supreme abode the unmanifest, the imperishable — and says those who reach it do not return. It is described as Krishna's own home (tad dhāma paramaṃ mama). The phrase means liberation from the cycle of return. It is not annihilation but completion — the cessation of the compulsions that bring consciousness back into embodied life."
        }
      },
      {
        "@type": "Question",
        "name": "Is Chapter 8 saying we should only think of Bhagavan at death?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Read carefully, no. Chapter 8 is teaching that the state at death is the trained state, and the trained state is the lifelong outcome of where your attention has gone. The chapter is not a special instruction for the final moment. It is a general instruction about how attention shapes being — death just makes the consequences of attention more visible."
        }
      }
    ]
  },
  {
    "@context": "https://schema.org",
    "@type": "Quotation",
    "@id": "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-8#verse-8.5",
    "text": "Whoever remembers me at the end, leaving the body — reaches my state. There is no doubt in this.",
    "spokenByCharacter": {
      "@type": "Person",
      "name": "Krishna"
    },
    "creator": {
      "@type": "Person",
      "name": "Krishna"
    },
    "isPartOf": {
      "@type": "Book",
      "name": "Bhagavad Gita, Chapter 8, Verse 5"
    },
    "inLanguage": [
      "sa",
      "en"
    ],
    "alternateName": [
      "अन्तकाले च मामेव स्मरन्मुक्त्वा कलेवरम् । / यः प्रयाति स मद्भावं याति नास्त्यत्र संशयः ॥",
      "anta-kāle ca mām eva smaran muktvā kalevaram | / yaḥ prayāti sa mad-bhāvaṃ yāti nāsty atra saṃśayaḥ ||"
    ],
    "url": "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-8#verse-8.5"
  },
  {
    "@context": "https://schema.org",
    "@type": "Quotation",
    "@id": "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-8#verse-8.6",
    "text": "Whatever state a person remembers as they leave the body, that state they reach — because the mind has long been shaped by it.",
    "spokenByCharacter": {
      "@type": "Person",
      "name": "Krishna"
    },
    "creator": {
      "@type": "Person",
      "name": "Krishna"
    },
    "isPartOf": {
      "@type": "Book",
      "name": "Bhagavad Gita, Chapter 8, Verse 6"
    },
    "inLanguage": [
      "sa",
      "en"
    ],
    "alternateName": [
      "यं यं वापि स्मरन्भावं त्यजत्यन्ते कलेवरम् । / तं तमेवैति कौन्तेय सदा तद्भावभावितः ॥",
      "yaṃ yaṃ vāpi smaran bhāvaṃ tyajaty ante kalevaram | / taṃ tam evaiti kaunteya sadā tad-bhāva-bhāvitaḥ ||"
    ],
    "url": "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-8#verse-8.6"
  },
  {
    "@context": "https://schema.org",
    "@type": "Quotation",
    "@id": "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-8#verse-8.8",
    "text": "With a mind disciplined by the yoga of practice, not wandering anywhere else, the one who departs while remembering the supreme divine person reaches that supreme being, Partha.",
    "spokenByCharacter": {
      "@type": "Person",
      "name": "Krishna"
    },
    "creator": {
      "@type": "Person",
      "name": "Krishna"
    },
    "isPartOf": {
      "@type": "Book",
      "name": "Bhagavad Gita, Chapter 8, Verse 8"
    },
    "inLanguage": [
      "sa",
      "en"
    ],
    "alternateName": [
      "अभ्यासयोगयुक्तेन चेतसा नान्यगामिना । / परमं पुरुषं दिव्यं याति पार्थानुचिन्तयन् ॥",
      "abhyāsa-yoga-yuktena cetasā nānya-gāminā | / paramaṃ puruṣaṃ divyaṃ yāti pārthānucintayan ||"
    ],
    "url": "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-8#verse-8.8"
  },
  {
    "@context": "https://schema.org",
    "@type": "Quotation",
    "@id": "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-8#verse-8.14",
    "text": "For the yogi whose mind is undivided, who remembers me constantly, always united with me — I am easy to reach, Partha.",
    "spokenByCharacter": {
      "@type": "Person",
      "name": "Krishna"
    },
    "creator": {
      "@type": "Person",
      "name": "Krishna"
    },
    "isPartOf": {
      "@type": "Book",
      "name": "Bhagavad Gita, Chapter 8, Verse 14"
    },
    "inLanguage": [
      "sa",
      "en"
    ],
    "alternateName": [
      "अनन्यचेताः सततं यो मां स्मरति नित्यशः । / तस्याहं सुलभः पार्थ नित्ययुक्तस्य योगिनः ॥",
      "ananya-cetāḥ satataṃ yo māṃ smarati nityaśaḥ | / tasyāhaṃ sulabhaḥ pārtha nitya-yuktasya yoginaḥ ||"
    ],
    "url": "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-8#verse-8.14"
  },
  {
    "@context": "https://schema.org",
    "@type": "Quotation",
    "@id": "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-8#verse-8.21",
    "text": "That which is called the unmanifest, the imperishable — they call it the supreme destination. Having reached it, beings do not return. That is my supreme abode.",
    "spokenByCharacter": {
      "@type": "Person",
      "name": "Krishna"
    },
    "creator": {
      "@type": "Person",
      "name": "Krishna"
    },
    "isPartOf": {
      "@type": "Book",
      "name": "Bhagavad Gita, Chapter 8, Verse 21"
    },
    "inLanguage": [
      "sa",
      "en"
    ],
    "alternateName": [
      "अव्यक्तोऽक्षर इत्युक्तस्तमाहुः परमां गतिम् । / यं प्राप्य न निवर्तन्ते तद्धाम परमं मम ॥",
      "avyakto'kṣara ity uktas tam āhuḥ paramāṃ gatim | / yaṃ prāpya na nivartante tad dhāma paramaṃ mama ||"
    ],
    "url": "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-8#verse-8.21"
  }
]

export default function ChapterPage8() {
  return (
    <>
      <style dangerouslySetInnerHTML={{ __html: pageCSS }} />
      {schemas.map((s, i) => (
        <script key={i} type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(s) }} />
      ))}

      {/* ── BREADCRUMB ── */}
      <div className="breadcrumb">
        <div className="breadcrumb-inner">
          <a href="/">Wisdom</a>
          <span className="bc-sep">/</span>
          <a href="/blogs">Blog</a>
          <span className="bc-sep">/</span>
          Bhagavad Gita Chapter 8
        </div>
      </div>

      {/* ── HERO ── */}
      <div className="article-hero">
        <div className="article-hero-inner">
          <div className="chapter-badge">
            <div className="chapter-badge-dot"></div>
            Bhagavad Gita · Adhyay 8 · 28 Verses
            <div className="chapter-badge-dot"></div>
          </div>
          <h1 className="article-title">
            Bhagavad Gita Chapter 8 (Adhyay 8):<br />
            <em>Akshara Brahma Yoga</em>
          </h1>
          <p className="article-subtitle">
            Chapter 8 is about the last moment, and therefore about every moment. The imperishable Brahman, the practice that carries you across death, and a quietly terrifying fact: you will leave with whatever you have rehearsed.
          </p>
          <div className="article-meta">
            <span className="meta-item">By <a href="/about" rel="author" data-mp-location="byline_author" style={{ color: 'var(--gold-light)', borderBottom: '1px solid rgba(200,136,30,0.35)' }}>Ankur Shukla</a></span>
          <span className="meta-sep">·</span>
          <span className="meta-item">28 verses · Akshara Brahma Yoga</span>
            <span className="meta-sep">·</span>
            <span className="meta-item">~11 min read</span>
            <span className="meta-sep">·</span>
            <span className="meta-item">Chapter 8 of 18</span>
          <span className="meta-sep">·</span>
          <span className="meta-item" style={{ fontStyle: 'italic' }}>Wisdom translation, edited by Ankur Shukla. Commentary AI-drafted, human-reviewed. Reviewed June 2026. <a href="/methodology" style={{ color: 'var(--gold-light)', borderBottom: '1px solid rgba(200,136,30,0.3)' }}>Methodology →</a></span>
          </div>
        </div>
      </div>

      {/* ── ARTICLE ── */}
      <div className="article-wrap">
        <article className="prose">
          <figure className="chapter-image">
            <img
              src="/assets/chapter8.webp"
              alt="Light dispersing into the eternal, Chapter 8 of the Bhagavad Gita teaches Akshara Brahma Yoga: the imperishable, the moment of death, and what the mind has practiced."
              width="1200"
              height="675"
              loading="eager"
            />
          </figure>

        <p className="lead">
          Chapter 8 is a chapter about death, and therefore, though it does not announce this directly, a chapter about every moment that is not yet death. Krishna begins by defining seven terms Arjuna has just asked about: Brahman, adhyatma, karma, adhibhuta, adhidaiva, adhiyajna, and the question of what happens at the moment of departure. The first answers are crisp, almost technical. Then the chapter pivots to its real subject, which is not the metaphysical inventory but the practical question that sits underneath every spiritual practice ever invented: what state of mind will I be in at the end?
        </p>

        <p>
          Most modern readers flinch from this question because it sounds morbid. The Gita treats it the opposite way. The question is not morbid, it is clarifying. The state of mind at the end, the Gita says, is not a separate event. It is the cumulative output of everything the mind has practiced. The most quietly serious sentence in Chapter 8 is verse 8.6: <em>whatever state of being you remember at the end, you reach that state, because the mind has been shaped by it</em>. The end follows the practice. Therefore the practice <em>is</em> the end, already begun.
        </p>

        <nav className="toc" aria-label="Table of contents">
          <div className="toc-label">In this article</div>
          <ol className="toc-list">
            <li><a href="#seven-terms">The seven terms, Krishna gets technical</a></li>
            <li><a href="#end-state">The state at the end, 8.5 and 8.6</a></li>
            <li><a href="#what-rehearsed">You leave with what you rehearsed</a></li>
            <li><a href="#easy-reach">Constant remembrance, the easy reach</a></li>
            <li><a href="#cosmic-time">Cosmic time, the day and night of Brahma</a></li>
            <li><a href="#beyond-return">The path beyond return</a></li>
            <li><a href="#two-paths">The chapter's closing, beyond merit</a></li>
            <li><a href="#all-verses">All verses at a glance</a></li>
            <li><a href="#faq">Frequently asked questions</a></li>
            <li><a href="#related-reading">Related reading</a></li>
          </ol>
        </nav>

        {/* DIVIDER */}
        <div className="section-divider">
          <div className="section-divider-line"></div>
          <div className="section-divider-label">
            Verses 8.1–8.4 · The Definitions
          </div>
          <div className="section-divider-line"></div>
        </div>

        <h2 id="seven-terms">Krishna Gets Technical, The Seven Terms</h2>

        <p>
          Arjuna opens Chapter 8 with a series of definitional questions. What is Brahman? What is the inner self? What is action? What is the field of beings? What is the divine? What is the inner sacrifice? And what happens at the moment of departure from the body? Krishna's reply is unusually crisp and structured. He defines each term in two lines, almost like a glossary, before moving to the chapter's deeper teaching.
        </p>

        <p>
          Most readers skip past these opening verses, looking for the more famous teaching that follows. But the definitions matter. They establish that the Gita's spiritual vocabulary is not vague. <em>Brahman</em> is the imperishable, the supreme. <em>Adhyatma</em> is one's own nature. <em>Karma</em> is the creative offering that brings beings into existence. The Gita is not a mystical wash. It is a precise system, with terms that mean specific things.
        </p>

                <ShlokaCard
          verseRef="Bhagavad Gita 8.3"
          speaker="Krishna"
          sanskrit="श्रीभगवानुवाच अक्षरं ब्रह्म परमं स्वभावोऽध्यात्ममुच्यते । भूतभावोद्भवकरो विसर्गः कर्मसंज्ञितः ॥"
          iast="śrī bhagavān uvāca | akṣaraṃ brahma paramaṃ svabhāvo'dhyātmam ucyate | bhūta-bhāvodbhava-karo visargaḥ karma-saṃjñitaḥ ||"
          insightLabel="Why precise definitions matter here"
          insight="The Gita is about to make claims about death that depend on these terms. Without the definitions, the later verses become mystical platitudes. With them, the claim is structural: there is an imperishable, there is your particular nature, and there is action, and these three are not the same. Clarity about what is what makes the rest of the chapter possible."
          essence="What lasts, what you are, and what you do are not the same."
        />

        {/* DIVIDER */}
        <div className="section-divider">
          <div className="section-divider-line"></div>
          <div className="section-divider-label">
            Verses 8.5–8.6 · The State at the End
          </div>
          <div className="section-divider-line"></div>
        </div>

        <h2 id="end-state">Whatever You Remember at the End, That You Become</h2>

        <p>
          After the definitions, Krishna moves to the chapter's most personal teaching. The state of mind you hold at the moment of leaving the body shapes what you carry forward. The first time you read this, it can feel ominous, like a final exam. Read more carefully, the verse is not ominous. It is mechanical. It is just describing how attention works.
        </p>

        <p>
          Verse 8.6 says: whatever state a person remembers at the end, that state they reach, because the mind has been shaped by it. The Sanskrit phrase is <em>sadā tad-bhāva-bhāvitaḥ</em>, always conditioned by that state. The Gita is making an unsentimental claim about habit. Whatever the mind has been trained to return to, that is where it will go when consciousness loses its anchors. Death just removes the anchors. The direction was already set.
        </p>

                <ShlokaCard
          verseRef="Bhagavad Gita 8.5"
          speaker="Krishna"
          sanskrit="अन्तकाले च मामेव स्मरन्मुक्त्वा कलेवरम् । यः प्रयाति स मद्भावं याति नास्त्यत्र संशयः ॥"
          iast="anta-kāle ca mām eva smaran muktvā kalevaram | yaḥ prayāti sa mad-bhāvaṃ yāti nāsty atra saṃśayaḥ ||"
          essence="The last remembered presence shapes the next state of being."
        />

                <ShlokaCard
          verseRef="Bhagavad Gita 8.6"
          speaker="Krishna"
          sanskrit="यं यं वापि स्मरन्भावं त्यजत्यन्ते कलेवरम् । तं तमेवैति कौन्तेय सदा तद्भावभावितः ॥"
          iast="yaṃ yaṃ vāpi smaran bhāvaṃ tyajaty ante kalevaram | taṃ tam evaiti kaunteya sadā tad-bhāva-bhāvitaḥ ||"
          meaning="Whatever state a person remembers as they leave the body, that state they reach, because the mind has long been shaped by it."
          insightLabel="The hinge phrase: sadā tad-bhāva-bhāvitaḥ"
          insight="Always conditioned by that state. This is the Gita's way of saying: you cannot fake the end. Whatever the mind has practiced returning to, that is what it will return to when the practice becomes involuntary. The end is determined by the training, not by intention in the moment."
          essence="The end follows the state you have trained."
        />

        <div className="pull-quote">
          <blockquote>
            "Whatever state the mind has long been shaped by, that is what it becomes at the end."
          </blockquote>
          <cite>Bhagavad Gita 8.6</cite>
        </div>

        {/* DIVIDER */}
        <div className="section-divider">
          <div className="section-divider-line"></div>
          <div className="section-divider-label">
            Verses 8.7–8.8 · The Practice Is the End
          </div>
          <div className="section-divider-line"></div>
        </div>

        <h2 id="what-rehearsed">You Will Leave With What You Rehearsed</h2>

        <p>
          Once 8.6 lands, 8.7 and 8.8 become urgent rather than abstract. Krishna says: therefore, at all times remember me, and fight. Notice the verb, fight. The Gita does not split spiritual practice from the conduct of daily life. The training of attention happens inside the work, not instead of it.
        </p>

        <p>
          Verse 8.8 then makes the cumulative claim explicit. The mind trained by practice (<em>abhyāsa-yoga</em>), fixed on nothing else, reaches the supreme. The word <em>abhyāsa</em> recurs across the Gita, repetition, the patient grooving of a habit. Your end-state, the chapter says, will be the dominant groove of your attention. So the question is not what you intend to be at the end. The question is what you are practicing right now, repeatedly, when no one is watching.
        </p>

                <ShlokaCard
          verseRef="Bhagavad Gita 8.8"
          speaker="Krishna"
          sanskrit="अभ्यासयोगयुक्तेन चेतसा नान्यगामिना । परमं पुरुषं दिव्यं याति पार्थानुचिन्तयन् ॥"
          iast="abhyāsa-yoga-yuktena cetasā nānya-gāminā | paramaṃ puruṣaṃ divyaṃ yāti pārthānucintayan ||"
          meaning="With a mind disciplined by the yoga of practice, not wandering anywhere else, the one who departs while remembering the supreme divine person reaches that supreme being, Partha."
          insightLabel="Practice is structural, not optional"
          insight="Notice the chain: abhyāsa-yoga-yuktena cetasā, by a mind made one with the yoga of practice. The mind does not just decide at the end. The mind is the cumulative deposit of every prior decision. Practice is not a virtue you add. It is the mechanism by which you become anything at all."
          essence="What the mind has practiced most will claim you at the end."
        />

        <div className="highlight-box">
          <p>
            <strong>Translated for the modern reader:</strong> Whatever you spend your attention on, scrolling, worrying, planning, watching, learning, loving, is what your mind will gravitate toward when the lights start going down. The Gita is not threatening you with this. It is informing you. Your end-state is being authored, daily, by your most repeated thought patterns.
          </p>
        </div>

        {/* DIVIDER */}
        <div className="section-divider">
          <div className="section-divider-line"></div>
          <div className="section-divider-label">
            Verse 8.14 · The Easy Reach
          </div>
          <div className="section-divider-line"></div>
        </div>

        <h2 id="easy-reach">Constant Remembrance Makes the Divine Easy to Reach</h2>

        <p>
          After the difficult teachings on death, Krishna offers a verse that lightens the chapter's tone. He says: for the one whose mind is wholly on me, who remembers me constantly, I am easy to reach. The Sanskrit word is <em>sulabhah</em>. Easy. Not difficult. Not a reward at the end of an austere struggle. Easy.
        </p>

        <p>
          This is one of the chapter's most consoling verses. The path the Gita has been describing, disciplined remembrance, training of attention, does not stay difficult. After the initial period of building the habit, the habit carries itself. The Divine is not playing hard to get. The Divine is playing easy to get, but the easiness requires a continuity of attention that most lives never assemble. The verse is an invitation, not a warning.
        </p>

                <ShlokaCard
          verseRef="Bhagavad Gita 8.14"
          speaker="Krishna"
          sanskrit="अनन्यचेताः सततं यो मां स्मरति नित्यशः । तस्याहं सुलभः पार्थ नित्ययुक्तस्य योगिनः ॥"
          iast="ananya-cetāḥ satataṃ yo māṃ smarati nityaśaḥ | tasyāhaṃ sulabhaḥ pārtha nitya-yuktasya yoginaḥ ||"
          meaning="For the yogi whose mind is undivided, who remembers me constantly, always united with me, I am easy to reach, Partha."
          insightLabel="The word that turns the chapter"
          insight="Sulabhaḥ, easy. The Gita is not built on heroic struggle. It is built on continuity. The yogi reaches the Divine easily not because they have superhuman discipline, but because they have stopped intermittently directing attention elsewhere. The reach is easy because the distance was always small."
          essence="Constant remembrance makes the divine easy to reach."
        />

        <div className="pull-quote">
          <blockquote>
            "For the one whose mind is undivided and remembers me constantly, I am easy to reach."
          </blockquote>
          <cite>Bhagavad Gita 8.14</cite>
        </div>

        {/* DIVIDER */}
        <div className="section-divider">
          <div className="section-divider-line"></div>
          <div className="section-divider-label">
            Verses 8.17–8.19 · Cosmic Time
          </div>
          <div className="section-divider-line"></div>
        </div>

        <h2 id="cosmic-time">Brahma's Day and Brahma's Night, Putting Your Week Into Perspective</h2>

        <p>
          Halfway through Chapter 8 the camera pulls back enormously. Krishna describes Brahma's day, a thousand <em>yuga</em>s long. Brahma's night, the same. The numbers are not meant as cosmology in the modern sense. They are meant as a sudden reframing of scale. Your life, your project, your urgent week, all of it sits inside something so much larger that ordinary urgency becomes embarrassing.
        </p>

        <p>
          What is the practical use of this? The Gita is doing what good astronomy still does. It is making your problems smaller without making them meaningless. The deadline at work matters. The argument with a friend matters. But against a thousand yugas of Brahma's day, the argument cannot also be cosmic. It must take its place. This is how the Gita reduces anxiety, not by denying the importance of things, but by setting them inside a frame so large that no single thing can be allowed to feel infinite.
        </p>

                <ShlokaCard
          verseRef="Bhagavad Gita 8.17"
          speaker="Krishna"
          sanskrit="सहस्रयुगपर्यन्तमहर्यद्ब्रह्मणो विदुः । रात्रिं युगसहस्रान्तां तेऽहोरात्रविदो जनाः ॥"
          iast="sahasra-yuga-paryantam ahar yad brahmaṇo viduḥ | rātriṃ yuga-sahasrāntāṃ te'ho-rātra-vido janāḥ ||"
          meaning="Those who know that Brahma's day lasts a thousand yugas, and his night lasts a thousand yugas, they truly know day and night."
          insightLabel="The therapeutic use of scale"
          insight="The verse is not asking you to do anything with Brahma's day. It is asking you to know it. Knowing puts the week's panic in scale. The therapy is structural: you cannot suffer with the same intensity inside the right frame. The Gita's cosmology is, partly, a deliberate widening of frame for a frantic mind."
          essence="Cosmic time reveals how small ordinary urgency is."
        />

        {/* DIVIDER */}
        <div className="section-divider">
          <div className="section-divider-line"></div>
          <div className="section-divider-label">
            Verse 8.21 · The Supreme Abode
          </div>
          <div className="section-divider-line"></div>
        </div>

        <h2 id="beyond-return">The Path That Does Not Return</h2>

        <p>
          After the cosmology, Krishna names the destination. He calls it <em>akṣaram</em>, the imperishable, and says: those who reach it do not return. The Sanskrit phrase is <em>yaṃ prāpya na nivartante</em>. Having reached it, they do not come back. This is the Gita's deepest claim about liberation. It is not a better next life. It is the end of the cycle of needing a next life.
        </p>

        <p>
          Modern readers sometimes find this troubling. Doesn't "not coming back" mean leaving everything behind? The Gita's answer, implicit across the chapter, is that what you leave behind is the compulsion to return, the unfinished wanting, the unresolved grief, the unspent attachment. The verse is not promising annihilation. It is promising completion. The pearls are still on the thread. You have just stopped being a pearl.
        </p>

                <ShlokaCard
          verseRef="Bhagavad Gita 8.21"
          speaker="Krishna"
          sanskrit="अव्यक्तोऽक्षर इत्युक्तस्तमाहुः परमां गतिम् । यं प्राप्य न निवर्तन्ते तद्धाम परमं मम ॥"
          iast="avyakto'kṣara ity uktas tam āhuḥ paramāṃ gatim | yaṃ prāpya na nivartante tad dhāma paramaṃ mama ||"
          meaning="That which is called the unmanifest, the imperishable, they call it the supreme destination. Having reached it, beings do not return. That is my supreme abode."
          insightLabel="What completion means here"
          insight="The phrase tad dhāma paramaṃ mama, &quot;that is my supreme home&quot;, is intimate. Krishna is not pointing at an abstract beyond. He is pointing at where he himself lives. The destination is a relationship as much as a place. To reach it is to come home, not to be erased."
          essence="The highest arrival is beyond return."
        />

        {/* DIVIDER */}
        <div className="section-divider">
          <div className="section-divider-line"></div>
          <div className="section-divider-label">
            Verse 8.28 · The Closing Word
          </div>
          <div className="section-divider-line"></div>
        </div>

        <h2 id="two-paths">Beyond Merit: The Chapter's Final Word</h2>

        <p>
          Chapter 8 ends with a quiet sentence that subverts much of the earlier conversation. Krishna says: the yogi who knows the two paths (of light and of darkness, of returning and of not returning) <em>goes beyond all the fruits of Vedas, sacrifices, austerities, and gifts</em>. The yogi attains the primal supreme abode.
        </p>

        <p>
          Notice what just happened. Krishna has spent the chapter teaching practice, training, remembrance. Then at the end he says, the truly understanding yogi has surpassed even the merit accumulated by sacrifices and austerities. The point is not that practice is wasted. The point is that practice is not a transaction. You are not stacking up cosmic merit points. You are becoming something, and the something has its own destination that does not need the merit. The Gita is, here, undercutting transactional spirituality even while teaching it.
        </p>

                <ShlokaCard
          verseRef="Bhagavad Gita 8.28"
          speaker="Krishna"
          sanskrit="वेदेषु यज्ञेषु तपःसु चैव दानेषु यत्पुण्यफलं प्रदिष्टम् । अत्येति तत्सर्वमिदं विदित्वा योगी परं स्थानमुपैति चाद्यम् ॥"
          iast="vedeṣu yajñeṣu tapaḥsu caiva dāneṣu yat puṇya-phalaṃ pradiṣṭam | atyeti tat sarvam idaṃ viditvā yogī paraṃ sthānam upaiti cādyam ||"
          meaning="Whatever merit is promised in the Vedas, in sacrifices, in austerities, and in gifts, the yogi who knows this transcends all of it, and reaches the primal supreme abode."
          insightLabel="Why the Gita undercuts merit at the end"
          insight="Merit is a useful frame for beginners. But at a certain depth, accumulating merit becomes another form of clinging. The yogi who has actually understood the chapter does not need the merit because they no longer need any return. The closing verse retires the transaction quietly, without dismissing it."
          essence="Knowing the way beyond rewards leads to the highest home."
        />

        <div className="highlight-box">
          <p>
            <strong>How Chapter 8 ends:</strong> Not with a triumph. Not with a technique. With a quiet redirection. The yogi who has truly understood the chapter no longer needs the ladder of merit they have been climbing. The end-state has nothing to do with what you have accumulated. It has to do with what you have become.
          </p>
        </div>

        {/* DIVIDER */}
        <div className="section-divider">
          <div className="section-divider-line"></div>
          <div className="section-divider-label">
            All 28 Verses At a Glance
          </div>
          <div className="section-divider-line"></div>
        </div>

        <h2 id="all-verses">The Complete Verse Reference</h2>

        <table className="verse-table">
          <thead>
            <tr><th>Verse</th><th>Speaker</th><th>Teaching Essence</th></tr>
          </thead>
          <tbody>
            <tr><td>8.1</td><td>Arjuna</td><td>Clear seeing starts by asking what each word truly means</td></tr>
            <tr><td>8.2</td><td>Arjuna</td><td>Real understanding begins by asking what remains when life is ending</td></tr>
            <tr><td>8.3</td><td>Krishna</td><td>What lasts, what you are, and what you do are not the same</td></tr>
            <tr><td>8.4</td><td>Krishna</td><td>The changing world, the cosmic order, and the inner witness are not separate</td></tr>
            <tr><td>8.5</td><td>Krishna</td><td>The last remembered presence shapes the next state of being</td></tr>
            <tr><td>8.6</td><td>Krishna</td><td>The end follows the state you have trained</td></tr>
            <tr><td>8.7</td><td>Krishna</td><td>Action and remembrance can happen together without conflict</td></tr>
            <tr><td>8.8</td><td>Krishna</td><td>What the mind has practiced most will claim you at the end</td></tr>
            <tr><td>8.9</td><td>Krishna</td><td>Hold the ungraspable source in mind, not the passing form</td></tr>
            <tr><td>8.10</td><td>Krishna</td><td>Steady devotion carries awareness beyond the body's final threshold</td></tr>
            <tr><td>8.11</td><td>Krishna</td><td>The imperishable is reached by giving up desire, not by feeding it</td></tr>
            <tr><td>8.12</td><td>Krishna</td><td>Mastery of senses and mind prepares one for the final passage</td></tr>
            <tr><td>8.13</td><td>Krishna</td><td>Final remembrance can carry consciousness beyond the body</td></tr>
            <tr><td>8.14</td><td>Krishna</td><td>Constant remembrance makes the divine easy to reach</td></tr>
            <tr><td>8.15</td><td>Krishna</td><td>True arrival ends the need to come back</td></tr>
            <tr><td>8.16</td><td>Krishna</td><td>Even the highest attainments return; only union with Krishna does not</td></tr>
            <tr><td>8.17</td><td>Krishna</td><td>Cosmic time reveals how small ordinary urgency is</td></tr>
            <tr><td>8.18</td><td>Krishna</td><td>Everything formed returns to the unmanifest in time</td></tr>
            <tr><td>8.19</td><td>Krishna</td><td>All formed things return and rise again under nature's compulsion</td></tr>
            <tr><td>8.20</td><td>Krishna</td><td>What is deepest in reality cannot be destroyed by any ending</td></tr>
            <tr><td>8.21</td><td>Krishna</td><td>The highest arrival is beyond return</td></tr>
            <tr><td>8.22</td><td>Krishna</td><td>Undivided devotion reaches the one presence that holds all beings</td></tr>
            <tr><td>8.23</td><td>Krishna</td><td>Not every departure leads the same way; some return, others do not</td></tr>
            <tr><td>8.24</td><td>Krishna</td><td>The final passage opens for those who know the supreme reality</td></tr>
            <tr><td>8.25</td><td>Krishna</td><td>Some routes only delay return; they do not end the cycle</td></tr>
            <tr><td>8.26</td><td>Krishna</td><td>Some choices free you from the cycle; others send you back into it</td></tr>
            <tr><td>8.27</td><td>Krishna</td><td>Understanding the two paths keeps the mind unshaken</td></tr>
            <tr><td>8.28</td><td>Krishna</td><td>Knowing the way beyond rewards leads to the highest home</td></tr>
          </tbody>
        </table>

        <div className="chapter-nav">
          <div>
            <div className="ch-nav-label">Previous</div>
            <a href="/blogs/bhagwat-geeta-chapter-7" className="ch-nav-title">Chapter 7, Jnana Vijnana Yoga</a>
          </div>
          <div style={{ textAlign: 'right' }}>
            <div className="ch-nav-label">Next</div>
            <a href="/blogs/bhagwat-geeta-chapter-9" className="ch-nav-title">Chapter 9, Raja Vidya Raja Guhya Yoga</a>
          </div>
        </div>

      <FeedbackWidget pageType="blog" />

        {/* DIVIDER */}
        <div className="section-divider">
          <div className="section-divider-line"></div>
          <div className="section-divider-label">
            Frequently Asked Questions
          </div>
          <div className="section-divider-line"></div>
        </div>


        <div className="faq-section" id="faq">
          <div className="faq-header">
            <div className="faq-header-label">Common questions</div>
            <h2>Frequently Asked Questions</h2>
          </div>
          <div className="faq-item">
            <div className="faq-q">What is Bhagavad Gita Chapter 8 about?</div>
            <div className="faq-a">
              Chapter 8 (Akshara Brahma Yoga) is the Gita's chapter on death, and therefore on every moment that is not yet death. Krishna defines seven key spiritual terms, then teaches that the state of mind at the end of life is the cumulative output of everything the mind has practiced. The chapter contains the famous teaching of 8.6, that whatever state a person remembers at the end is the state they reach. It also introduces Brahma's day and night, the imperishable destination from which one does not return, and the two paths after death.
            </div>
          </div>
          <div className="faq-item">
            <div className="faq-q">What does Bhagavad Gita 8.6 mean?</div>
            <div className="faq-a">
              Verse 8.6 says, 'Whatever state of being one remembers when leaving the body, that state one attains, because the mind has long been shaped by it.' It is not a verse about being dramatic in the final moment. It is a verse about training. The mind at the end is the mind you have trained, by what it has repeatedly returned to in life. The end is the cumulative output of practice, not a separate event.
            </div>
          </div>
          <div className="faq-item">
            <div className="faq-q">What is the meaning of antakale ca mam eva smaran?</div>
            <div className="faq-a">
              This is the opening phrase of verse 8.5, 'at the end, remembering me alone.' Krishna says one who departs while remembering him reaches his state. But the very next verse clarifies that this end-remembrance is only possible for the mind that has long practiced it. You cannot install a new attention pattern at the last moment. The teaching is about lifelong rehearsal, not a deathbed manoeuvre.
            </div>
          </div>
          <div className="faq-item">
            <div className="faq-q">What are Brahma's day and night in the Bhagavad Gita?</div>
            <div className="faq-a">
              In verses 8.17-19, Krishna describes Brahma's day as lasting a thousand yugas, and his night as lasting another thousand. At the start of Brahma's day, all beings emerge from the unmanifest. At nightfall, they dissolve back. The teaching is partly cosmology and partly therapeutic, it widens the frame so that ordinary urgency stops feeling cosmic. The Gita uses scale to dissolve panic.
            </div>
          </div>
          <div className="faq-item">
            <div className="faq-q">What is the supreme abode (paramam dhama) in the Bhagavad Gita?</div>
            <div className="faq-a">
              Verse 8.21 calls the supreme abode the unmanifest, the imperishable, and says those who reach it do not return. It is described as Krishna's own home (tad dhāma paramaṃ mama). The phrase means liberation from the cycle of return. It is not annihilation but completion, the cessation of the compulsions that bring consciousness back into embodied life.
            </div>
          </div>
          <div className="faq-item">
            <div className="faq-q">Is Chapter 8 saying we should only think of Bhagavan at death?</div>
            <div className="faq-a">
              Read carefully, no. Chapter 8 is teaching that the state at death is the trained state, and the trained state is the lifelong outcome of where your attention has gone. The chapter is not a special instruction for the final moment. It is a general instruction about how attention shapes being, death just makes the consequences of attention more visible.
            </div>
          </div>
        </div>

        <div className="related-reading" id="related-reading">
          <div className="related-reading-label">Continue reading</div>
          <h2>Related Reading</h2>
          <div className="related-grid">
          <a href="/blogs/bhagavad-gita-anxiety-mental-peace" className="related-card">
            <div className="related-card-label">Topic Guide</div>
            <div className="related-card-title">What the Gita says about anxiety & death</div>
          </a>
          <a href="/blogs/bhagavad-gita-complete-structure-all-chapters" className="related-card">
            <div className="related-card-label">Topic Guide</div>
            <div className="related-card-title">All 18 chapters, the full arc</div>
          </a>
          <a href="/blogs/bhagwat-geeta-chapter-7" className="related-card">
            <div className="related-card-label">Chapter 7</div>
            <div className="related-card-title">Jnana Vijnana Yoga, Knowing About vs. Knowing Through</div>
          </a>
          <a href="/blogs/bhagwat-geeta-chapter-9" className="related-card">
            <div className="related-card-label">Chapter 9</div>
            <div className="related-card-title">Raja Vidya Raja Guhya Yoga, The Royal Secret</div>
          </a>
          <a href="/blogs/bhagwat-geeta-chapter-15" className="related-card">
            <div className="related-card-label">Chapter 15</div>
            <div className="related-card-title">Purushottama Yoga, Cut the Tree, Find the Source</div>
          </a>
          </div>
        </div>

          <VerseFunnelCTA variant="chapter" locale="en" pageName={"Bhagwat Geeta Chapter 8"} />

        </article>
      </div>

      {/* FOOTER */}
      <footer>
        <p>
          Wisdom © 2026. Part of a{' '}
          <a
            href={appStoreUrl('web_blog_footer')}
            target="_blank"
            rel="noopener"
            data-mp-location="footer"
          >free iPhone app</a>{' '}
          that tunes the Bhagavad Gita to your life, one verse a day. Made with reverence.
        </p>
        <p style={{ marginTop: '8px' }}>
          <a href="/">wisdomquotes.in</a> · <a href="/privacy">Privacy</a> · <a href="/terms">Terms</a> · <a href="mailto:work.ankurshukla@gmail.com">Support</a>
        </p>
      </footer>

      <BlogTracker pageName="Bhagwat Geeta Chapter 8" />
    </>
  )
}
