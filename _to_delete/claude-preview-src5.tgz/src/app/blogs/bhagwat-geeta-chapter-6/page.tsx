import type { Metadata } from 'next'
import BlogTracker from '@/components/BlogTracker'
import FeedbackWidget from '@/components/FeedbackWidget'
import ShlokaCard from '@/components/gita/ShlokaCard'
import VerseFunnelCTA from '@/components/funnel/VerseFunnelCTA'
import { appStoreUrl } from '@/lib/app'

export const metadata: Metadata = {
  title: "Bhagavad Gita Chapter 6 Summary – Key Verses & Meaning (Dhyana Yoga)",
  description: "The mind is harder to tame than the wind — here's how to do it. Bhagavad Gita Chapter 6 (Dhyana Yoga): Krishna's complete guide to meditation, the restless mind, and the lamp-in-windless-place. All 47 verses in Sanskrit, Hindi and English.",
  keywords: "bhagwat geeta chapter 6, bhagavad gita dhyana yoga, bhagwat geeta adhyay 6, lamp in windless place gita, uddharedatmanatmanam, abhyasa vairagya meaning, gita on meditation, restless mind gita, how to meditate bhagavad gita, Dhyana Yoga summary, Bhagavad Gita 6.5 meaning, Bhagavad Gita 6.34 the mind is like the wind, abhyasa vairagya meaning, lamp in windless place Bhagavad Gita, how to meditate according to Bhagavad Gita",
  openGraph: {
    title: "Bhagavad Gita Chapter 6 Summary – Key Verses & Meaning (Dhyana Yoga)",
    description: "All 47 verses of Bhagavad Gita Chapter 6, meditation, the restless mind, and the lamp that does not flicker.",
    type: 'article',
    url: "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-6",
    siteName: 'Wisdom',
    locale: 'en_IN',
    images: [{ url: "https://wisdomquotes.in/assets/chapter6.webp", width: 1200, height: 675, alt: "A yogi seated in meditation at the edge of dawn, the mind, lamp-like, no longer flickers. Chapter 6 of the Bhagavad Gita teaches Dhyana Yoga, the path of meditation." }],
  },
  twitter: {
    card: 'summary_large_image',
    title: "Bhagavad Gita Chapter 6 Summary – Key Verses & Meaning (Dhyana Yoga)",
    description: "All 47 verses of Bhagavad Gita Chapter 6, meditation, the restless mind, and the lamp that does not flicker.",
    images: ["https://wisdomquotes.in/assets/chapter6.webp"],
  },
  alternates: { canonical: "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-6", languages: { 'x-default': 'https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-6' } },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, 'max-image-preview': 'large', 'max-snippet': -1 },
  },
  other: { "rel=prev": "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-5", "rel=next": "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-7" },
}

const pageCSS = `

      :root {
        --maroon: #3d0c0c;
        --maroon-mid: #5c1a1a;
        --gold: #c8881e;
        --gold-light: #f5c96a;
        --gold-pale: #fdf3dc;
        --gold-border: #e8c97a;
        --gold-dim: rgba(200, 136, 30, 0.15);
        --text: #f5e8cc;
        --text-dim: rgba(245, 232, 204, 0.65);
        --text-dimmer: rgba(245, 232, 204, 0.35);
        --muted-2: rgba(245, 232, 204, 0.35);
        --border: rgba(200, 136, 30, 0.2);
        --bg: #120505;
        --bg-warm: #190707;
        --bg-alt: #0f0404;
        --bg-card: rgba(255, 255, 255, 0.04);
        --bg-card-hover: rgba(255, 255, 255, 0.07);
        --max: 780px;
      }

      *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
      html { scroll-behavior: smooth; scroll-padding-top: 88px; }

      body {
        font-family: "Inter", system-ui, -apple-system, sans-serif;
        background: var(--bg);
        color: var(--text);
        line-height: 1.7;
        -webkit-font-smoothing: antialiased;
      }

      a { color: inherit; text-decoration: none; }
      img { display: block; max-width: 100%; }

      .breadcrumb { background: var(--bg-alt); border-bottom: 1px solid var(--border); }
      .breadcrumb-inner { max-width: 1100px; margin: 0 auto; padding: 10px 28px;
        font-size: 12px; color: var(--text-dimmer); display: flex; gap: 8px; align-items: center; }
      .breadcrumb-inner a { color: var(--text-dimmer); transition: color 0.15s; }
      .breadcrumb-inner a:hover { color: var(--gold-light); }
      .bc-sep { opacity: 0.4; }

      .article-hero {
        background: var(--bg-warm); padding: 64px 28px 56px;
        border-bottom: 1px solid var(--border); position: relative; overflow: hidden;
      }
      .article-hero::before {
        content: "अध्याय ६";
        position: absolute; right: -10px; bottom: -20px;
        font-family: "Noto Sans Devanagari", serif; font-size: 180px;
        color: rgba(200, 136, 30, 0.04); line-height: 1; pointer-events: none; user-select: none;
      }
      .article-hero-inner { max-width: 1100px; margin: 0 auto; position: relative; z-index: 2; }

      .chapter-badge { display: inline-flex; align-items: center; gap: 8px;
        background: rgba(200, 136, 30, 0.1); border: 1px solid rgba(200, 136, 30, 0.28);
        color: var(--gold-light); font-size: 11px; font-weight: 700; letter-spacing: 0.12em;
        text-transform: uppercase; padding: 5px 14px; border-radius: 100px; margin-bottom: 20px; }
      .chapter-badge-dot { width: 5px; height: 5px; border-radius: 50%; background: var(--gold);
        box-shadow: 0 0 6px var(--gold); flex-shrink: 0; }
      .article-title { font-family: "Playfair Display", Georgia, serif;
        font-size: clamp(28px, 4vw, 48px); font-weight: 700; color: var(--gold-light);
        line-height: 1.15; letter-spacing: -0.5px; margin-bottom: 12px; }
      .article-title em { font-style: italic; color: #fff; }
      .article-subtitle { font-size: 17px; color: var(--text-dim); font-weight: 300;
        margin-bottom: 32px; line-height: 1.65; max-width: 580px; }
      .article-meta { display: flex; align-items: center; gap: 16px; flex-wrap: wrap; }
      .meta-item { font-size: 12px; color: var(--text-dimmer); letter-spacing: 0.04em; }
      .meta-sep { color: var(--border); }

      .article-wrap { max-width: var(--max); margin: 0 auto; padding: 60px 28px 80px; }

      .chapter-image {
        margin: 0 0 36px;
        border-radius: 14px;
        overflow: hidden;
        border: 1px solid var(--border);
        background: var(--bg-warm);
        box-shadow: 0 24px 48px rgba(0, 0, 0, 0.4);
      }
      .chapter-image img { display: block; width: 100%; height: auto; aspect-ratio: 16 / 9; object-fit: cover; }

      .prose h2 { font-family: "Playfair Display", Georgia, serif; font-size: 26px; font-weight: 700;
        color: var(--gold-light); margin: 52px 0 16px; line-height: 1.25; }
      .prose h2[id], .faq-section[id], .related-reading[id] { scroll-margin-top: 88px; }
      .prose h2 em { font-style: italic; color: #fff; }

      .prose h3 { font-family: "Playfair Display", Georgia, serif; font-size: 19px; font-weight: 700;
        color: var(--text); margin: 32px 0 12px; }

      .prose p { font-size: 16.5px; line-height: 1.78; color: var(--text-dim); margin-bottom: 20px; }
      .prose p:last-child { margin-bottom: 0; }
      .prose strong { font-weight: 600; color: var(--text); }
      .prose em { font-style: italic; }
      .lead { font-size: 19px; line-height: 1.7; color: var(--text); font-weight: 300; margin-bottom: 28px; }

      .toc { background: var(--bg-card); border: 1px solid var(--border);
        border-left: 3px solid var(--gold); border-radius: 0 12px 12px 0;
        padding: 20px 24px; margin: 36px 0 40px; }
      .toc-label { font-size: 9.5px; letter-spacing: 0.18em; text-transform: uppercase;
        font-weight: 700; color: var(--gold); margin-bottom: 12px; }
      .toc-list { list-style: none; display: flex; flex-direction: column; gap: 7px; counter-reset: toc-counter; }
      .toc-list li { counter-increment: toc-counter; display: flex; align-items: baseline; gap: 10px; }
      .toc-list li::before { content: counter(toc-counter); font-family: "Inter", sans-serif;
        font-size: 10px; font-variant-numeric: tabular-nums; color: var(--text-dimmer); min-width: 14px; }
      .toc-list a { font-size: 13.5px; color: var(--text-dim); line-height: 1.4; transition: color 0.15s; }
      .toc-list a:hover { color: var(--gold-light); }

      .pull-quote { margin: 40px 0; padding: 28px 32px; border-left: 3px solid var(--gold);
        background: rgba(200, 136, 30, 0.05); border-radius: 0 12px 12px 0; }
      .pull-quote blockquote { font-family: "Playfair Display", serif; font-size: 21px;
        font-style: italic; color: var(--gold-light); line-height: 1.5; margin-bottom: 10px; }
      .pull-quote cite { font-size: 12px; letter-spacing: 0.1em; text-transform: uppercase;
        color: var(--gold); font-style: normal; font-weight: 600; }

      .section-divider { display: flex; align-items: center; gap: 16px; margin: 56px 0 40px; }
      .section-divider-line { flex: 1; height: 1px; background: var(--border); }
      .section-divider-label { font-size: 10px; letter-spacing: 0.18em; text-transform: uppercase;
        color: var(--text-dimmer); white-space: nowrap; font-weight: 600; }

      .highlight-box { background: rgba(200, 136, 30, 0.05); border: 1px solid var(--border);
        border-left: 3px solid var(--gold); border-radius: 0 10px 10px 0;
        padding: 20px 24px; margin: 28px 0; }
      .highlight-box p { font-size: 15px; line-height: 1.7; color: var(--text-dim); }
      .highlight-box strong { color: var(--gold-light); }

      .verse-table { width: 100%; border-collapse: collapse; font-size: 13.5px;
        margin: 28px 0 40px; border: 1px solid var(--border); border-radius: 10px; overflow: hidden; }
      .verse-table thead tr { background: rgba(200, 136, 30, 0.08); }
      .verse-table thead th { text-align: left; padding: 12px 16px; font-size: 9.5px;
        letter-spacing: 0.15em; text-transform: uppercase; color: var(--gold); font-weight: 700; }
      .verse-table tbody td { padding: 10px 16px; border-bottom: 1px solid var(--border);
        vertical-align: top; line-height: 1.55; color: var(--text-dim); }
      .verse-table tbody tr:last-child td { border-bottom: none; }
      .verse-table tbody tr:hover { background: var(--bg-card); }
      .verse-table td:first-child { font-size: 12px; color: var(--gold); font-weight: 600; white-space: nowrap; }

      .faq-section { background: var(--bg-card); border: 1px solid var(--border);
        border-top: 2px solid var(--gold); border-radius: 14px; overflow: hidden; margin: 48px 0; }
      .faq-header { padding: 28px 32px 20px; border-bottom: 1px solid var(--border); }
      .faq-header-label { font-size: 10px; letter-spacing: 0.2em; text-transform: uppercase;
        color: var(--gold); font-weight: 700; margin-bottom: 6px; }
      .faq-header h2 { font-family: "Playfair Display", serif; font-size: 22px; font-weight: 700;
        color: var(--gold-light); line-height: 1.3; margin: 0; }
      .faq-item { padding: 22px 32px; border-bottom: 1px solid var(--border); }
      .faq-item:last-child { border-bottom: none; }
      .faq-q { font-size: 15px; font-weight: 600; color: var(--text); margin-bottom: 10px; line-height: 1.4; }
      .faq-a { font-size: 14.5px; line-height: 1.72; color: var(--text-dim); }

      .related-reading { background: var(--bg-card); border: 1px solid var(--border);
        border-top: 2px solid var(--gold); border-radius: 14px; padding: 28px 32px;
        margin: 48px 0; }
      .related-reading-label { font-size: 10px; letter-spacing: 0.2em; text-transform: uppercase;
        color: var(--gold); font-weight: 700; margin-bottom: 6px; }
      .related-reading h2 { font-family: "Playfair Display", serif; font-size: 22px; font-weight: 700;
        color: var(--gold-light); line-height: 1.3; margin: 0 0 18px; }
      .related-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
      .related-card { display: block; background: var(--bg); border: 1px solid var(--border);
        border-radius: 10px; padding: 14px 18px; transition: border-color 0.15s, background 0.15s, transform 0.15s; }
      .related-card:hover { border-color: var(--gold); background: var(--bg-card-hover); transform: translateY(-2px); }
      .related-card-label { font-size: 10px; letter-spacing: 0.15em; text-transform: uppercase;
        color: var(--text-dimmer); font-weight: 600; margin-bottom: 4px; }
      .related-card-title { font-size: 14px; font-weight: 600; color: var(--text); line-height: 1.4; }

      .app-cta { background: linear-gradient(160deg, #2d0a0a 0%, #1a0606 100%);
        border: 1px solid rgba(200, 136, 30, 0.25); border-top: 3px solid var(--gold);
        border-radius: 20px; padding: 44px 48px 40px; margin: 48px 0 60px;
        text-align: center; position: relative; overflow: hidden; }
      .app-cta::before { content: "ध्यान"; position: absolute; top: -14px; right: -8px;
        font-family: "Noto Sans Devanagari", sans-serif; font-size: 130px;
        color: rgba(200, 136, 30, 0.05); line-height: 1; pointer-events: none; user-select: none; }
      .app-cta-eyebrow { display: inline-flex; align-items: center; background: rgba(200, 136, 30, 0.12);
        border: 1px solid rgba(200, 136, 30, 0.35); color: var(--gold-light); font-size: 11px;
        font-weight: 600; letter-spacing: 0.14em; text-transform: uppercase; padding: 5px 14px;
        border-radius: 20px; margin-bottom: 20px; }
      .app-cta-headline { font-family: "Playfair Display", serif;
        font-size: clamp(22px, 3vw, 30px); font-weight: 700; color: var(--text);
        line-height: 1.25; margin-bottom: 14px; }
      .app-cta-desc { font-size: 15px; color: var(--text-dim); line-height: 1.7;
        max-width: 480px; margin: 0 auto 22px; }
      .app-cta-features { display: flex; gap: 6px 18px; justify-content: center;
        flex-wrap: wrap; margin-bottom: 28px; }
      .app-cta-features span { font-size: 13px; color: var(--gold-light); opacity: 0.8; }
      .app-cta-btn { display: inline-flex; align-items: center; gap: 10px;
        background: var(--gold); color: #120505; text-decoration: none;
        padding: 15px 34px; border-radius: 12px; font-size: 16px; font-weight: 700;
        letter-spacing: -0.01em; transition: all 0.2s;
        box-shadow: 0 4px 22px rgba(200, 136, 30, 0.3); }
      .app-cta-btn:hover { background: var(--gold-light); transform: translateY(-2px);
        box-shadow: 0 8px 32px rgba(200, 136, 30, 0.5); }
      .app-cta-sub { font-size: 12px; color: rgba(245, 232, 204, 0.35); margin-top: 14px; letter-spacing: 0.04em; }

      .chapter-nav { display: flex; justify-content: space-between; align-items: center;
        gap: 16px; padding: 20px 0; border-top: 1px solid var(--border);
        border-bottom: 1px solid var(--border); margin: 0 0 40px; }
      .ch-nav-label { font-size: 11px; letter-spacing: 0.1em; text-transform: uppercase;
        color: var(--text-dimmer); font-weight: 600; margin-bottom: 4px; }
      .ch-nav-title { font-size: 14px; font-weight: 600; color: var(--text); }

      footer { background: var(--bg-alt); border-top: 1px solid var(--border);
        padding: 32px 28px; text-align: center; font-size: 12px;
        letter-spacing: 0.06em; color: var(--text-dimmer); }
      footer a { color: var(--text-dimmer); transition: color 0.15s; }
      footer a:hover { color: var(--gold-light); }
      footer span { color: var(--gold); }

      @media (max-width: 700px) {
        .article-hero { padding: 44px 20px 40px; }
        .article-wrap { padding: 40px 20px 60px; }
        .app-cta { padding: 32px 24px; }
        .pull-quote { padding: 22px 24px; }
        .faq-header, .faq-item { padding-left: 20px; padding-right: 20px; }
        .related-grid { grid-template-columns: 1fr; }
      }

`

const schemas = [
  {
    "@context": "https://schema.org",
    "@type": [
      "Article",
      "LearningResource"
    ],
    "headline": "Bhagavad Gita Chapter 6 — Dhyana Yoga: The Lamp That Does Not Flicker",
    "description": "Bhagavad Gita Chapter 6 — Dhyana Yoga (Meditation). All 47 verses with Sanskrit, transliteration, meaning, and the lamp-in-windless-place teaching.",
    "alternativeHeadline": "Bhagavad Gita Chapter 6 (Dhyana Yoga) — Summary & Verses",
    "author": {
    "@type": "Person",
    "name": "Ankur Shukla",
    "url": "https://wisdomquotes.in/about",
    "sameAs": [
      "https://www.linkedin.com/in/thisisashukla/",
      "https://x.com/thisisashukla"
    ]
  },
    "publisher": {
      "@type": "Organization",
      "name": "Wisdom",
      "url": "https://wisdomquotes.in",
      "logo": {
        "@type": "ImageObject",
        "url": "https://wisdomquotes.in/assets/new-light-logo.webp"
      }
    },
    "image": {
      "@type": "ImageObject",
      "url": "https://wisdomquotes.in/assets/chapter6.webp",
      "width": 1200,
      "height": 675
    },
    "datePublished": "2026-05-18",
    "dateModified": "2026-05-18",
    "mainEntityOfPage": {
      "@type": "WebPage",
      "@id": "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-6"
    },
    "about": [
      {
        "@type": "Book",
        "name": "Bhagavad Gita",
        "author": {
          "@type": "Person",
          "name": "Ved Vyasa"
        },
        "url": "https://wisdomquotes.in/gita"
      },
      {
        "@type": "Person",
        "name": "Krishna",
        "url": "https://en.wikipedia.org/wiki/Krishna"
      },
      {
        "@type": "Person",
        "name": "Arjuna",
        "url": "https://en.wikipedia.org/wiki/Arjuna"
      }
    ],
    "keywords": "bhagwat geeta chapter 6, bhagavad gita dhyana yoga, bhagwat geeta adhyay 6, lamp in windless place gita, uddharedatmanatmanam, abhyasa vairagya meaning, gita on meditation, restless mind gita, how to meditate bhagavad gita, Dhyana Yoga summary, Bhagavad Gita 6.5 meaning, Bhagavad Gita 6.34 the mind is like the wind, abhyasa vairagya meaning, lamp in windless place Bhagavad Gita, how to meditate according to Bhagavad Gita",
    "articleSection": "Bhagavad Gita",
    "wordCount": 2820,
    "inLanguage": "en",
    "isAccessibleForFree": true,
    "learningResourceType": "Article",
    "educationalLevel": "General",
    "speakable": {
      "@type": "SpeakableSpecification",
      "cssSelector": [
        ".lead",
        ".shloka-meaning",
        ".shloka-essence"
      ]
    }
  },
  {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [
      {
        "@type": "ListItem",
        "position": 1,
        "name": "Wisdom",
        "item": "https://wisdomquotes.in/"
      },
      {
        "@type": "ListItem",
        "position": 2,
        "name": "Blog",
        "item": "https://wisdomquotes.in/blogs"
      },
      {
        "@type": "ListItem",
        "position": 3,
        "name": "Bhagavad Gita Chapter 6 — Dhyana Yoga",
        "item": "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-6"
      }
    ]
  },
  {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": "What is Bhagavad Gita Chapter 6 about?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Chapter 6, called Dhyana Yoga (the Yoga of Meditation), is the Gita's most practical chapter on inner discipline. Across 47 verses, Krishna teaches Arjuna how to actually meditate — where to sit, what to eat, what to do when the mind wanders, and how to deal with the inevitable feeling that the practice is too hard. It contains the famous lamp-in-windless-place metaphor (6.19), Arjuna's honest objection that the mind is like the wind (6.34), and Krishna's reply that practice and detachment (abhyāsa and vairāgya) are the only working tools."
        }
      },
      {
        "@type": "Question",
        "name": "What does Bhagavad Gita 6.5 mean?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Verse 6.5 says, 'Lift yourself by yourself; do not let yourself fall. The self alone is the friend of the self, and the self alone is its enemy.' It is one of the most personally challenging verses in the Gita because it refuses to outsource the work of self-mastery. The same self that can elevate you is the only thing that can drag you down. There is no external rescuer in this verse — and also no external blocker."
        }
      },
      {
        "@type": "Question",
        "name": "What is the lamp in a windless place metaphor?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Found in verse 6.19, this is one of the Gita's most quoted images. Krishna compares the disciplined mind of a yogi to a lamp placed where no wind blows — it does not flicker. The metaphor describes the felt experience of a steady mind: not a forced suppression of thought, but the natural stillness that arises when the conditions that cause flickering are removed."
        }
      },
      {
        "@type": "Question",
        "name": "What did Arjuna object to in Chapter 6?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "In verses 6.33 and 6.34, Arjuna interrupts Krishna and says the teaching is impractical — the mind is too restless, like the wind. He gives every reader permission to admit the same thing. Krishna's response in 6.35 is one of the most important verses in the Gita: yes, the mind is hard to control, but it is held by abhyāsa (practice) and vairāgya (detachment). Repeated practice without attachment to the result is the only method that has ever worked."
        }
      },
      {
        "@type": "Question",
        "name": "What happens if you fail at yoga according to Chapter 6?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Verses 6.40 through 6.45 are the Gita's most reassuring passage on incomplete spiritual effort. Krishna tells Arjuna that no one who has done sincere good is ever destroyed. A person who falls from the path of yoga is not lost — they return to it, either in this life or the next, picking up where they left off. The Gita treats sincere effort as cumulative: nothing you put in is wasted."
        }
      },
      {
        "@type": "Question",
        "name": "Is meditation in the Bhagavad Gita similar to modern mindfulness?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "There is real overlap. Modern mindfulness practices — noticing when the mind wanders, returning attention without judgement, building gradual stability — are exactly what verse 6.26 describes. But the Gita's framing is wider: meditation is not just stress-reduction, it is the training of the entire self toward a stable, equal-visioned, devotionally-anchored way of being. Verse 6.47 makes clear that the deepest yoga is not technique alone but trust."
        }
      }
    ]
  },
  {
    "@context": "https://schema.org",
    "@type": "Quotation",
    "@id": "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-6#verse-6.5",
    "text": "Lift yourself by yourself; do not let yourself fall. The self alone is the friend of the self, and the self alone is its enemy.",
    "spokenByCharacter": {
      "@type": "Person",
      "name": "Krishna"
    },
    "creator": {
      "@type": "Person",
      "name": "Krishna"
    },
    "isPartOf": {
      "@type": "Book",
      "name": "Bhagavad Gita, Chapter 6, Verse 5"
    },
    "inLanguage": [
      "sa",
      "en"
    ],
    "alternateName": [
      "उद्धरेदात्मनाऽऽत्मानं नात्मानमवसादयेत् । / आत्मैव ह्यात्मनो बन्धुरात्मैव रिपुरात्मनः ॥",
      "uddhared ātmanā''tmānaṃ nātmānam avasādayet | / ātmaiva hyātmano bandhur ātmaiva ripur ātmanaḥ ||"
    ],
    "url": "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-6#verse-6.5"
  },
  {
    "@context": "https://schema.org",
    "@type": "Quotation",
    "@id": "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-6#verse-6.19",
    "text": "As a lamp in a windless place does not flicker — that is the comparison given for the disciplined mind of a yogi united in meditation.",
    "spokenByCharacter": {
      "@type": "Person",
      "name": "Krishna"
    },
    "creator": {
      "@type": "Person",
      "name": "Krishna"
    },
    "isPartOf": {
      "@type": "Book",
      "name": "Bhagavad Gita, Chapter 6, Verse 19"
    },
    "inLanguage": [
      "sa",
      "en"
    ],
    "alternateName": [
      "यथा दीपो निवातस्थो नेङ्गते सोपमा स्मृता । / योगिनो यतचित्तस्य युञ्जतो योगमात्मनः ॥",
      "yathā dīpo nivāta-stho neṅgate sopamā smṛtā | / yogino yatacittasya yuñjato yogam ātmanaḥ ||"
    ],
    "url": "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-6#verse-6.19"
  },
  {
    "@context": "https://schema.org",
    "@type": "Quotation",
    "@id": "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-6#verse-6.26",
    "text": "Whenever the restless, unsteady mind wanders out, from wherever it has gone, bring it back under the authority of the self.",
    "spokenByCharacter": {
      "@type": "Person",
      "name": "Krishna"
    },
    "creator": {
      "@type": "Person",
      "name": "Krishna"
    },
    "isPartOf": {
      "@type": "Book",
      "name": "Bhagavad Gita, Chapter 6, Verse 26"
    },
    "inLanguage": [
      "sa",
      "en"
    ],
    "alternateName": [
      "यतो यतो निश्चरति मनश्चञ्चलमस्थिरम् । / ततस्ततो नियम्यैतदात्मन्येव वशं नयेत् ॥",
      "yato yato niścarati manaścañcalam asthiram | / tatas tato niyamyaitad ātmany eva vaśaṃ nayet ||"
    ],
    "url": "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-6#verse-6.26"
  },
  {
    "@context": "https://schema.org",
    "@type": "Quotation",
    "@id": "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-6#verse-6.35",
    "text": "The Blessed One said: Undoubtedly, mighty-armed one, the mind is restless and hard to restrain. But by practice and detachment, it is held.",
    "spokenByCharacter": {
      "@type": "Person",
      "name": "Krishna"
    },
    "creator": {
      "@type": "Person",
      "name": "Krishna"
    },
    "isPartOf": {
      "@type": "Book",
      "name": "Bhagavad Gita, Chapter 6, Verse 35"
    },
    "inLanguage": [
      "sa",
      "en"
    ],
    "alternateName": [
      "श्रीभगवानुवाच / असंशयं महाबाहो मनो दुर्निग्रहं चलं । / अभ्यासेन तु कौन्तेय वैराग्येण च गृह्यते ॥",
      "śrī bhagavān uvāca | / asaṃśayaṃ mahābāho mano durnigrahaṃ calam | / abhyāsena tu kaunteya vairāgyeṇa ca gṛhyate ||"
    ],
    "url": "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-6#verse-6.35"
  },
  {
    "@context": "https://schema.org",
    "@type": "Quotation",
    "@id": "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-6#verse-6.47",
    "text": "Among all yogis, the one whose inner self has come to rest in me, who worships me with trust — that one I consider the most fully integrated.",
    "spokenByCharacter": {
      "@type": "Person",
      "name": "Krishna"
    },
    "creator": {
      "@type": "Person",
      "name": "Krishna"
    },
    "isPartOf": {
      "@type": "Book",
      "name": "Bhagavad Gita, Chapter 6, Verse 47"
    },
    "inLanguage": [
      "sa",
      "en"
    ],
    "alternateName": [
      "योगिनामपि सर्वेषां मद्गतेनान्तरात्मना । / श्रद्धावान्भजते यो मां स मे युक्ततमो मतः ॥",
      "yoginām api sarveṣāṃ madgatenāntar-ātmanā | / śraddhāvān bhajate yo māṃ sa me yuktatamo mataḥ ||"
    ],
    "url": "https://wisdomquotes.in/blogs/bhagwat-geeta-chapter-6#verse-6.47"
  }
]

export default function ChapterPage6() {
  return (
    <>
      <style dangerouslySetInnerHTML={{ __html: pageCSS }} />
      {schemas.map((s, i) => (
        <script key={i} type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(s) }} />
      ))}

      {/* ── BREADCRUMB ── */}
      <div className="breadcrumb">
        <div className="breadcrumb-inner">
          <a href="/">Wisdom</a>
          <span className="bc-sep">/</span>
          <a href="/blogs">Blog</a>
          <span className="bc-sep">/</span>
          Bhagavad Gita Chapter 6
        </div>
      </div>

      {/* ── HERO ── */}
      <div className="article-hero">
        <div className="article-hero-inner">
          <div className="chapter-badge">
            <div className="chapter-badge-dot"></div>
            Bhagavad Gita · Adhyay 6 · 47 Verses
            <div className="chapter-badge-dot"></div>
          </div>
          <h1 className="article-title">
            Bhagavad Gita Chapter 6 (Adhyay 6):<br />
            <em>Dhyana Yoga</em>
          </h1>
          <p className="article-subtitle">
            Krishna's most practical chapter, how to train a mind that won't sit still. The lamp in a windless place. The friend and enemy inside you. And the steadiness that no argument, message, or memory can shake.
          </p>
          <div className="article-meta">
            <span className="meta-item">By <a href="/about" rel="author" data-mp-location="byline_author" style={{ color: 'var(--gold-light)', borderBottom: '1px solid rgba(200,136,30,0.35)' }}>Ankur Shukla</a></span>
          <span className="meta-sep">·</span>
          <span className="meta-item">47 verses · Dhyana Yoga</span>
            <span className="meta-sep">·</span>
            <span className="meta-item">~14 min read</span>
            <span className="meta-sep">·</span>
            <span className="meta-item">Chapter 6 of 18</span>
          <span className="meta-sep">·</span>
          <span className="meta-item" style={{ fontStyle: 'italic' }}>Wisdom translation, edited by Ankur Shukla. Commentary AI-drafted, human-reviewed. Reviewed June 2026. <a href="/methodology" style={{ color: 'var(--gold-light)', borderBottom: '1px solid rgba(200,136,30,0.3)' }}>Methodology →</a></span>
          </div>
        </div>
      </div>

      {/* ── ARTICLE ── */}
      <div className="article-wrap">
        <article className="prose">
          <figure className="chapter-image">
            <img
              src="/assets/chapter6.webp"
              alt="A yogi seated in meditation at the edge of dawn, the mind, lamp-like, no longer flickers. Chapter 6 of the Bhagavad Gita teaches Dhyana Yoga, the path of meditation."
              width="1200"
              height="675"
              loading="eager"
            />
          </figure>

        <p className="lead">
          By Chapter 6, the Gita stops talking about meditation in the abstract and starts giving instructions. Where to sit. How to sit. What to eat. What to do when the mind, on cue, refuses to cooperate. This is the most practical chapter in the Gita, and it is the one most often skipped by people who want the philosophy without the seat. That is a mistake. Chapter 6 is where Krishna meets you exactly where most attempts at the inner life actually break, at the part where you try to be still, and you can't.
        </p>

        <p>
          Arjuna will be honest enough in this chapter to interrupt Krishna and say: this is impossible. The mind is wind. Trying to hold it is trying to hold the air. Krishna does not deny it. He agrees. Yes, the mind is restless. And then he gives the only answer that has ever worked, in any tradition, anywhere: abhyāsa and vairāgya. Practice and detachment. Repeated return, with diminishing emotional weight. That is the whole technology of inner change, and Chapter 6 is its source text.
        </p>

        <nav className="toc" aria-label="Table of contents">
          <div className="toc-label">In this article</div>
          <ol className="toc-list">
            <li><a href="#lift-yourself">Lift yourself by yourself, 6.5</a></li>
            <li><a href="#friend-enemy">The friend and the enemy are the same person</a></li>
            <li><a href="#seat-balance">The seat, the food, the sleep, the body matters</a></li>
            <li><a href="#lamp">The lamp in a windless place, what steadiness looks like</a></li>
            <li><a href="#wandering-mind">The wandering mind and the practice of return</a></li>
            <li><a href="#arjuna-objects">Arjuna interrupts, "the mind is like the wind"</a></li>
            <li><a href="#nothing-lost">Nothing sincere is ever wasted, 6.40 to 6.45</a></li>
            <li><a href="#highest-yogi">The chapter's final word, trust</a></li>
            <li><a href="#all-verses">All verses at a glance</a></li>
            <li><a href="#faq">Frequently asked questions</a></li>
            <li><a href="#related-reading">Related reading</a></li>
          </ol>
        </nav>

        {/* DIVIDER */}
        <div className="section-divider">
          <div className="section-divider-line"></div>
          <div className="section-divider-label">
            Verses 6.5–6.6 · Self as Friend, Self as Enemy
          </div>
          <div className="section-divider-line"></div>
        </div>

        <h2 id="lift-yourself">Lift Yourself By Yourself, The Most Honest Verse in the Gita</h2>

        <p>
          Chapter 6 opens by clarifying what renunciation actually means, and then, in verse 5, Krishna says something that has no equivalent in any other scripture. The exact translation is blunt: lift yourself, by yourself; do not let yourself fall. The same self that can carry you upward is the only thing that can also drag you down. There is no external rescuer in this verse. There is just you, and the part of you that decides whether to rise.
        </p>

        <p>
          Most spiritual teaching softens this point. The Gita does not. It puts the responsibility back in your hands at the very moment you would most like to outsource it, the moment when you are tired, ashamed, or stuck. The Gita's view is unsentimental: nobody else can do the lifting. But also, and this is the same verse, nobody else needs to. You already contain what is required.
        </p>

                <ShlokaCard
          verseRef="Bhagavad Gita 6.5"
          speaker="Krishna"
          sanskrit="उद्धरेदात्मनाऽऽत्मानं नात्मानमवसादयेत् । आत्मैव ह्यात्मनो बन्धुरात्मैव रिपुरात्मनः ॥"
          iast="uddhared ātmanā''tmānaṃ nātmānam avasādayet | ātmaiva hyātmano bandhur ātmaiva ripur ātmanaḥ ||"
          essence="Your own inner handling makes you rise or collapse."
        />

                <ShlokaCard
          verseRef="Bhagavad Gita 6.6"
          speaker="Krishna"
          sanskrit="बन्धुरात्माऽऽत्मनस्तस्य येनात्मैवात्मना जितः । अनात्मनस्तु शत्रुत्वे वर्तेतात्मैव शत्रुवत् ॥"
          iast="bandhur ātmā''tmanas tasya yenātmaivātmanā jitaḥ | anātmanas tu śatrutve vartetātmaiva śatruvat ||"
          essence="The same inner nature that frees you can also fight you."
        />

        <div className="highlight-box">
          <p>
            <strong>Why this is the chapter's emotional centre:</strong> Most of us quit practices because we feel like the effort isn't working. Chapter 6 is the Gita's response to that despair. The effort is working. You cannot see it yet because you are inside it. But it is being recorded. It is changing what you are. And if you fall, you will start the next attempt from where you fell, not from zero.
          </p>
        </div>

        {/* DIVIDER */}
        <div className="section-divider">
          <div className="section-divider-line"></div>
          <div className="section-divider-label">
            Verse 6.47 · The Final Hierarchy
          </div>
          <div className="section-divider-line"></div>
        </div>

        <h2 id="highest-yogi">The Chapter's Surprising Final Word: Trust</h2>

        <p>
          After 46 verses on meditation, posture, breath, balance, and discipline, the chapter ends somewhere unexpected. Krishna says the highest yogi is not the one with the steadiest seat or the longest practice. It is the one whose inner self rests in him, in trust, with love. Bhakti, devotion, quietly takes the crown that one would have expected to go to discipline.
        </p>

        <p>
          This sets up the rest of the Gita. Chapters 7 through 12 will go deep into devotion as a practice. But it begins here, at the end of the meditation chapter, with Krishna refusing to let the reader believe that technique is the whole story. The deepest steadiness, he says, comes not from controlling the mind but from giving it somewhere to rest. Trust is the final yoga.
        </p>

                <ShlokaCard
          verseRef="Bhagavad Gita 6.47"
          speaker="Krishna"
          sanskrit="योगिनामपि सर्वेषां मद्गतेनान्तरात्मना । श्रद्धावान्भजते यो मां स मे युक्ततमो मतः ॥"
          iast="yoginām api sarveṣāṃ madgatenāntar-ātmanā | śraddhāvān bhajate yo māṃ sa me yuktatamo mataḥ ||"
          essence="Trusting devotion is the highest integration of yoga."
        />

        <div className="pull-quote">
          <blockquote>
            "Among all yogis, the one whose inner self rests in me, with trust, that one is the most fully united."
          </blockquote>
          <cite>Bhagavad Gita 6.47</cite>
        </div>

        {/* DIVIDER */}
        <div className="section-divider">
          <div className="section-divider-line"></div>
          <div className="section-divider-label">
            All 47 Verses At a Glance
          </div>
          <div className="section-divider-line"></div>
        </div>

        <h2 id="all-verses">The Complete Verse Reference</h2>

        <table className="verse-table">
          <thead>
            <tr><th>Verse</th><th>Speaker</th><th>Teaching Essence</th></tr>
          </thead>
          <tbody>
            <tr><td>6.1</td><td>Krishna</td><td>Renunciation means acting without owning the result</td></tr>
            <tr><td>6.2</td><td>Krishna</td><td>Yoga begins when the mind stops clutching its own agenda</td></tr>
            <tr><td>6.3</td><td>Krishna</td><td>You reach steadiness through action, then preserve it through stillness</td></tr>
            <tr><td>6.4</td><td>Krishna</td><td>Yoga begins when neither pleasure nor action can hook you</td></tr>
            <tr><td>6.5</td><td>Krishna</td><td>Your own inner handling makes you rise or collapse</td></tr>
            <tr><td>6.6</td><td>Krishna</td><td>The same inner nature that frees you can also fight you</td></tr>
            <tr><td>6.7</td><td>Krishna</td><td>Steadiness makes the highest reality feel near in every opposite</td></tr>
            <tr><td>6.8</td><td>Krishna</td><td>True mastery makes gold and dust feel identical</td></tr>
            <tr><td>6.9</td><td>Krishna</td><td>Equal vision toward all people marks the highest steadiness</td></tr>
            <tr><td>6.10</td><td>Krishna</td><td>Steady inward practice begins when desire and possessiveness end</td></tr>
            <tr><td>6.11</td><td>Krishna</td><td>A steady mind begins with a steady seat</td></tr>
            <tr><td>6.12</td><td>Krishna</td><td>Meditation begins by gathering the mind and training the senses</td></tr>
            <tr><td>6.13</td><td>Krishna</td><td>Steady posture is the first gate to a steady mind</td></tr>
            <tr><td>6.14</td><td>Krishna</td><td>A disciplined mind can rest in devotion without fear</td></tr>
            <tr><td>6.15</td><td>Krishna</td><td>A steady mind reaches the peace that restlessness can never touch</td></tr>
            <tr><td>6.16</td><td>Krishna</td><td>Balance makes meditation possible; extremes break it</td></tr>
            <tr><td>6.17</td><td>Krishna</td><td>Balanced living makes inner practice possible</td></tr>
            <tr><td>6.18</td><td>Krishna</td><td>Yoga begins when craving loses its grip and the mind comes home</td></tr>
            <tr><td>6.19</td><td>Krishna</td><td>A trained mind becomes steady enough to stop flickering</td></tr>
            <tr><td>6.20</td><td>Krishna</td><td>Stillness reveals a completeness that no outside thing can improve</td></tr>
            <tr><td>6.21</td><td>Krishna</td><td>True joy is deeper than sensation and keeps you from wavering</td></tr>
            <tr><td>6.22</td><td>Krishna</td><td>True fulfillment leaves nothing more to chase, nothing strong enough to unsettle</td></tr>
            <tr><td>6.23</td><td>Krishna</td><td>Yoga is the breaking of suffering's grip, practiced steadily</td></tr>
            <tr><td>6.24</td><td>Krishna</td><td>Desire loses power when the mind stops feeding it</td></tr>
            <tr><td>6.25</td><td>Krishna</td><td>Stillness comes by degrees when the mind stops feeding itself</td></tr>
            <tr><td>6.26</td><td>Krishna</td><td>The mind is mastered by repeated return, not by force</td></tr>
            <tr><td>6.27</td><td>Krishna</td><td>Joy comes when the restless mind finally becomes still</td></tr>
            <tr><td>6.28</td><td>Krishna</td><td>Repeated union with the supreme yields effortless, lasting joy</td></tr>
            <tr><td>6.29</td><td>Krishna</td><td>Equal vision dissolves the illusion of separation</td></tr>
            <tr><td>6.30</td><td>Krishna</td><td>Seeing the divine everywhere ends separation</td></tr>
            <tr><td>6.31</td><td>Krishna</td><td>Unity turns every action into abiding presence</td></tr>
            <tr><td>6.32</td><td>Krishna</td><td>Equal vision makes you unshaken by pleasure or pain</td></tr>
            <tr><td>6.33</td><td>Arjuna</td><td>Restlessness makes even clear teaching feel unreachable</td></tr>
            <tr><td>6.34</td><td>Arjuna</td><td>The mind resists control like wind resists the hand</td></tr>
            <tr><td>6.35</td><td>Krishna</td><td>Practice and detachment together master the restless mind</td></tr>
            <tr><td>6.36</td><td>Krishna</td><td>Yoga becomes reachable when the mind is trained, not merely hoped for</td></tr>
            <tr><td>6.37</td><td>Arjuna</td><td>Faith without completion still deserves a clear answer</td></tr>
            <tr><td>6.38</td><td>Arjuna</td><td>Half-finished striving can feel like total ruin</td></tr>
            <tr><td>6.39</td><td>Arjuna</td><td>Only clear seeing can end confusion completely</td></tr>
            <tr><td>6.40</td><td>Krishna</td><td>Sincere effort toward the good cannot end in ruin</td></tr>
            <tr><td>6.41</td><td>Krishna</td><td>A fall from yoga still carries you forward</td></tr>
            <tr><td>6.42</td><td>Krishna</td><td>A fallen practitioner is not lost; the next birth restarts the work</td></tr>
            <tr><td>6.43</td><td>Krishna</td><td>Nothing gained in sincere practice is ever truly lost</td></tr>
            <tr><td>6.44</td><td>Krishna</td><td>Earlier practice keeps pulling you forward, even against resistance</td></tr>
            <tr><td>6.45</td><td>Krishna</td><td>Persistent striving eventually ripens into the highest fulfillment</td></tr>
            <tr><td>6.46</td><td>Krishna</td><td>Inner mastery outranks every outer path</td></tr>
            <tr><td>6.47</td><td>Krishna</td><td>Trusting devotion is the highest integration of yoga</td></tr>
          </tbody>
        </table>

        <div className="chapter-nav">
          <div>
            <div className="ch-nav-label">Previous</div>
            <a href="/blogs/bhagwat-geeta-chapter-5" className="ch-nav-title">Chapter 5, Karma Sanyasa Yoga</a>
          </div>
          <div style={{ textAlign: 'right' }}>
            <div className="ch-nav-label">Next</div>
            <a href="/blogs/bhagwat-geeta-chapter-7" className="ch-nav-title">Chapter 7, Jnana Vijnana Yoga</a>
          </div>
        </div>

      <FeedbackWidget pageType="blog" />

        {/* DIVIDER */}
        <div className="section-divider">
          <div className="section-divider-line"></div>
          <div className="section-divider-label">
            Frequently Asked Questions
          </div>
          <div className="section-divider-line"></div>
        </div>


        <div className="faq-section" id="faq">
          <div className="faq-header">
            <div className="faq-header-label">Common questions</div>
            <h2>Frequently Asked Questions</h2>
          </div>
          <div className="faq-item">
            <div className="faq-q">What is Bhagavad Gita Chapter 6 about?</div>
            <div className="faq-a">
              Chapter 6, called Dhyana Yoga (the Yoga of Meditation), is the Gita's most practical chapter on inner discipline. Across 47 verses, Krishna teaches Arjuna how to actually meditate, where to sit, what to eat, what to do when the mind wanders, and how to deal with the inevitable feeling that the practice is too hard. It contains the famous lamp-in-windless-place metaphor (6.19), Arjuna's honest objection that the mind is like the wind (6.34), and Krishna's reply that practice and detachment (abhyāsa and vairāgya) are the only working tools.
            </div>
          </div>
          <div className="faq-item">
            <div className="faq-q">What does Bhagavad Gita 6.5 mean?</div>
            <div className="faq-a">
              Verse 6.5 says, 'Lift yourself by yourself; do not let yourself fall. The self alone is the friend of the self, and the self alone is its enemy.' It is one of the most personally challenging verses in the Gita because it refuses to outsource the work of self-mastery. The same self that can elevate you is the only thing that can drag you down. There is no external rescuer in this verse, and also no external blocker.
            </div>
          </div>
          <div className="faq-item">
            <div className="faq-q">What is the lamp in a windless place metaphor?</div>
            <div className="faq-a">
              Found in verse 6.19, this is one of the Gita's most quoted images. Krishna compares the disciplined mind of a yogi to a lamp placed where no wind blows, it does not flicker. The metaphor describes the felt experience of a steady mind: not a forced suppression of thought, but the natural stillness that arises when the conditions that cause flickering are removed.
            </div>
          </div>
          <div className="faq-item">
            <div className="faq-q">What did Arjuna object to in Chapter 6?</div>
            <div className="faq-a">
              In verses 6.33 and 6.34, Arjuna interrupts Krishna and says the teaching is impractical, the mind is too restless, like the wind. He gives every reader permission to admit the same thing. Krishna's response in 6.35 is one of the most important verses in the Gita: yes, the mind is hard to control, but it is held by abhyāsa (practice) and vairāgya (detachment). Repeated practice without attachment to the result is the only method that has ever worked.
            </div>
          </div>
          <div className="faq-item">
            <div className="faq-q">What happens if you fail at yoga according to Chapter 6?</div>
            <div className="faq-a">
              Verses 6.40 through 6.45 are the Gita's most reassuring passage on incomplete spiritual effort. Krishna tells Arjuna that no one who has done sincere good is ever destroyed. A person who falls from the path of yoga is not lost, they return to it, either in this life or the next, picking up where they left off. The Gita treats sincere effort as cumulative: nothing you put in is wasted.
            </div>
          </div>
          <div className="faq-item">
            <div className="faq-q">Is meditation in the Bhagavad Gita similar to modern mindfulness?</div>
            <div className="faq-a">
              There is real overlap. Modern mindfulness practices, noticing when the mind wanders, returning attention without judgement, building gradual stability, are exactly what verse 6.26 describes. But the Gita's framing is wider: meditation is not just stress-reduction, it is the training of the entire self toward a stable, equal-visioned, devotionally-anchored way of being. Verse 6.47 makes clear that the deepest yoga is not technique alone but trust.
            </div>
          </div>
        </div>

        <div className="related-reading" id="related-reading">
          <div className="related-reading-label">Continue reading</div>
          <h2>Related Reading</h2>
          <div className="related-grid">
          <a href="/blogs/bhagavad-gita-anxiety-mental-peace" className="related-card">
            <div className="related-card-label">Topic Guide</div>
            <div className="related-card-title">What the Gita says about anxiety & mental peace</div>
          </a>
          <a href="/blogs/bhagavad-gita-karma-meaning" className="related-card">
            <div className="related-card-label">Topic Guide</div>
            <div className="related-card-title">Karma, what it actually means in the Gita</div>
          </a>
          <a href="/blogs/bhagwat-geeta-chapter-5" className="related-card">
            <div className="related-card-label">Chapter 5</div>
            <div className="related-card-title">Karma Sanyasa Yoga, Acting Without Being Touched</div>
          </a>
          <a href="/blogs/bhagwat-geeta-chapter-12" className="related-card">
            <div className="related-card-label">Chapter 12</div>
            <div className="related-card-title">Bhakti Yoga, How a Devotee Actually Lives</div>
          </a>
          <a href="/blogs/bhagwat-geeta-chapter-14" className="related-card">
            <div className="related-card-label">Chapter 14</div>
            <div className="related-card-title">Gunatraya Vibhaga, The Three Forces</div>
          </a>
          </div>
        </div>

          <VerseFunnelCTA variant="chapter" locale="en" pageName={"Bhagwat Geeta Chapter 6"} />

        </article>
      </div>

      {/* FOOTER */}
      <footer>
        <p>
          Wisdom © 2026. Part of a{' '}
          <a
            href={appStoreUrl('web_blog_footer')}
            target="_blank"
            rel="noopener"
            data-mp-location="footer"
          >free iPhone app</a>{' '}
          that tunes the Bhagavad Gita to your life, one verse a day. Made with reverence.
        </p>
        <p style={{ marginTop: '8px' }}>
          <a href="/">wisdomquotes.in</a> · <a href="/privacy">Privacy</a> · <a href="/terms">Terms</a> · <a href="mailto:work.ankurshukla@gmail.com">Support</a>
        </p>
      </footer>

      <BlogTracker pageName="Bhagwat Geeta Chapter 6" />
    </>
  )
}
