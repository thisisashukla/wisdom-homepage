import type { Metadata } from 'next'
import React from 'react'
import schemas from '@/lib/homeSchemas'
import BlogTracker from '@/components/BlogTracker'
import HomeAnimations from '@/components/HomeAnimations'
import Nav from '@/components/Nav'
import YourVerse from '@/components/funnel/YourVerse'
import { getAllChapters, getAllVerseRefs, getVerse, getVerseAudio, chapterImage } from '@/lib/gita'
import { appStoreUrl, WEB_PLAN_PRICE_INR } from '@/lib/app'
import { GITA_FOR } from '@/lib/gitaFor'
import VerseAudioPlayer from '@/components/gita/VerseAudioPlayer'
import './home.css'
import './home-v3.css'

// Revalidate hourly so the daily verse rolls over without a manual rebuild
export const revalidate = 3600

function todaysVerseRef() {
  const refs = getAllVerseRefs()
  if (!refs.length) return null
  const utc = new Date()
  const dayOfYear = Math.floor(
    (Date.UTC(utc.getUTCFullYear(), utc.getUTCMonth(), utc.getUTCDate()) -
      Date.UTC(utc.getUTCFullYear(), 0, 0)) / 86400000
  )
  return refs[(utc.getUTCFullYear() * 1000 + dayOfYear) % refs.length]
}

const TITLE = 'Bhagavad Gita Online: 700 Verses in Hindi, English | Wisdom'
const DESCRIPTION =
  "Read all 700 Bhagavad Gita verses free in Sanskrit, Hindi and English. Or get a 7-day reading plan from the Gita for what's on your mind."

export const metadata: Metadata = {
  title: { absolute: TITLE },
  description: DESCRIPTION,
  keywords:
    'bhagavad gita online, bhagavad gita in hindi, bhagavad gita in english, gita verses with meaning, bhagavad gita for anxiety, gita verse of the day, bhagavad gita app',
  openGraph: {
    title: "The Bhagavad Gita, tuned to your life",
    description: DESCRIPTION,
    type: 'website',
    url: 'https://wisdomquotes.in',
    siteName: 'Wisdom',
    images: [{ url: 'https://wisdomquotes.in/og-image.webp', width: 1200, height: 630, alt: 'Wisdom: the Bhagavad Gita verse for what you are going through' }],
  },
  alternates: { canonical: 'https://wisdomquotes.in' },
}

const ICONIC_VERSES = [
  { ref: '2.47', chapter: 2, verse: 47, label: 'Karmanye vadhikaraste' },
  { ref: '4.7', chapter: 4, verse: 7, label: 'Yada yada hi dharmasya' },
  { ref: '2.20', chapter: 2, verse: 20, label: 'The atman never dies' },
  { ref: '18.66', chapter: 18, verse: 66, label: 'Surrender' },
  { ref: '6.5', chapter: 6, verse: 5, label: 'Raise yourself' },
  { ref: '2.62', chapter: 2, verse: 62, label: 'How anger starts' },
]

// Unedited output of POST /api/v1/recommend/depth for bg.2.47 (19 Oct 2026),
// one call per note. Source of truth: lp/05-copy.md → three-notes.
const NOTES = [
  {
    note: 'My board exams are in two weeks and I keep imagining failing and disappointing my parents. I cannot focus.',
    reply:
      "You are staring at the textbook but the pages blur with the image of your parents' disappointment. The exam is two weeks away and you are already rehearsing the moment you fail, letting that imagined future take up all the space in the room.",
    practice:
      "Set a timer for twenty-five minutes and read only one page, then close the book and step away. Do not let yourself think about the grade or your parents' reaction during that time.",
  },
  {
    note: 'I have a promotion review on Friday. My manager keeps moving the goalposts and I lie awake replaying every meeting.',
    reply:
      'Your manager is shifting the goalposts for Friday, and you are lying awake replaying every past conversation, trying to find the right words to prove you are good enough.',
    practice:
      'When the mind starts replaying a meeting, name the thought as thinking and gently return your attention to your breath for one minute.',
  },
  {
    note: 'My son moved to Canada for work. He does not call much and I keep worrying about his choices and whether I did enough.',
    reply:
      "You sit in the quiet of your home, the phone silent, and feel the weight of your son's silence as a measure of your own worth as a mother.",
    practice: 'Send him one message about your day, not asking for his. Share a small truth without waiting for his reply.',
  },
]

const BLOGS = [
  { slug: 'best-bhagavad-gita-translation', title: 'The best Bhagavad Gita translation in English, compared', dek: 'Easwaran, Prabhupada, Gandhi, Sargeant and more: which one to read first.' },
  { slug: 'krishna-quotes', title: '50 Krishna quotes from the Bhagavad Gita', dek: 'His best-known lines, with the Sanskrit and what each one means.' },
  { slug: 'karma-quotes-bhagavad-gita', title: 'Karma quotes from the Bhagavad Gita', dek: 'What the Gita actually says about action and its results.' },
]

const FAQ = [
  {
    q: 'Can I read the Bhagavad Gita online for free?',
    a: 'Yes. All 18 chapters and 700 verses, in Sanskrit, Hindi and English with meaning and commentary, are free on this site. No login and no ads.',
  },
  {
    q: 'How does the reading plan work?',
    a: "You tell us what's on your mind in one tap. Wisdom picks seven verses for it from a library of 1,743 across the Gita, Ramayana, Mahabharata and Upanishads: one a day, each with the Sanskrit and what it means for you. Day 1 opens straight away and is free. On iPhone the rest of week 1 is free in the app; on Android and computers it's ₹89 a week, and you sign in with Google first.",
  },
  {
    q: 'Which translation do you use? Is it ISKCON?',
    a: 'No. The Sanskrit and Hindi come from traditional sources. English is our own, checked against Shankara, Ramanuja and modern acharyas rather than one tradition. The Methodology page explains how.',
  },
  {
    q: 'Is the Gita available in Hindi?',
    a: 'Yes. Every verse has a Hindi-first page at /hi/gita with the shloka, Hindi anuvad and vistrit arth.',
  },
  {
    q: 'Which verse should I read first?',
    a: "If something is on your mind, start with your verse above. If you want the whole text, begin at 1.1. Arjuna's despair in chapter 1 is where Krishna's teaching starts. The most quoted verse is 2.47.",
  },
  {
    q: 'What does it cost?',
    a: `Reading is free. On iPhone, week 1 of a plan is free and Pro opens weeks 2 and 3. On the web, a plan is ₹${WEB_PLAN_PRICE_INR} a week. Your bank sends a notice before each charge and you can cancel from your plan.`,
  },
  {
    q: 'Is this a substitute for therapy?',
    a: "No. Many people read the Gita alongside therapy. If you're thinking about harming yourself, please call Tele-MANAS on 14416 (India, free, 24×7) or your local emergency number.",
  },
]

export default async function HomePage() {
  const todayRef = todaysVerseRef()
  const todayVerse = todayRef ? await getVerse(todayRef.chapter, todayRef.verse) : null
  const todayAudio = todayRef ? getVerseAudio(todayRef.chapter, todayRef.verse) : null
  const chapters = getAllChapters()
  const appHome = appStoreUrl('web_home_app_section')

  return (
    <>
      {schemas.map((s, i) => (
        <script key={i} type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(s) }} />
      ))}

      {/* ── NAV + HERO: "your verse, right now" ── */}
      <div className="hero-shell">
        <Nav overlayHero pageName="Home" />

        <section className="hero hero-immersive hero-v3">
          <img
            src="/assets/chapter11.webp"
            alt="Krishna revealing his universal form to Arjuna on the battlefield of Kurukshetra"
            fetchPriority="high"
            className="hero-bg"
            aria-hidden="true"
          />
          <div className="hero-scrim" aria-hidden="true" />
          <div className="hero-glow" aria-hidden="true" />

          <div className="hero-inner">
            <div className="hero-content">
              <h1>
                The Bhagavad Gita, <em>tuned to your life.</em>
              </h1>
              <p className="hero-sub">
                Tell us what&apos;s on your mind. Get a 7-day reading plan from the Gita for it: one verse a day, in Sanskrit and plain English.
              </p>

              <YourVerse source="hero" pageName="Home" />


            </div>
          </div>
        </section>
      </div>

      {/* ── ONE VERSE, THREE NOTES (real output) ── */}
      <section className="section" data-mp-section="home_three_notes">
        <div className="wrap">
          <div className="sec-head rv">
            <div className="eyebrow">One verse, three notes</div>
            <h2 className="heading">Same verse. <em>Three different weeks.</em></h2>
            <p className="subtext">
              We gave Wisdom three notes and the same verse, 2.47: &ldquo;you have a right to the work, never to its
              fruits.&rdquo; These are its replies, unedited.
            </p>
          </div>
          <div className="notes-grid" data-stagger="90">
            {NOTES.map((n) => (
              <article key={n.note} className="note-card rv">
                <div className="note-label">The note</div>
                <p className="note-text">&ldquo;{n.note}&rdquo;</p>
                <div className="note-label">Wisdom&apos;s reply</div>
                <p className="note-reply">{n.reply}</p>
                <div className="note-label">Try this today</div>
                <p className="note-practice">{n.practice}</p>
              </article>
            ))}
          </div>
          <p className="notes-foot rv">
            Generated by Wisdom on 19 Oct 2026 from the notes shown. The verse text is never changed; only the line about
            your life is written for you.{' '}
            <a href="#your-verse" data-mp-location="home_notes_find_verse">Start my reading plan</a>
          </p>
        </div>
      </section>

      {/* ── SEVEN DAYS (plan + offer) ── */}
      <section className="section section-alt" id="app" data-mp-section="home_seven_days">
        <div className="wrap seven">
          <div className="seven-text rv">
            <div className="eyebrow">Your reading plan</div>
            <h2 className="heading">How the <em>seven days</em> work.</h2>
            <p className="subtext">One verse a day, chosen for your situation and read aloud, with the Sanskrit woven in.</p>
            <ol className="week" data-stagger="80">
              {[
                ['1–2', 'Days 1 and 2 help you see it clearly.'],
                ['3–4', 'Days 3 and 4 steady you.'],
                ['5–6', 'Days 5 and 6 are about what to do.'],
                ['7', 'Day 7 is a story from the Gita, the Ramayana or the Mahabharata.'],
              ].map(([n, t]) => (
                <li key={n} className="rv">
                  <span className="week-n" aria-hidden="true">{n}</span>
                  <span className="week-t">{t}</span>
                </li>
              ))}
            </ol>
            <div className="offers" data-stagger="90">
              <div className="offer rv">
                <h3>On iPhone</h3>
                <p>The Wisdom app, with today&apos;s shloka on your Lock Screen.</p>
                <p className="offer-price">Week 1 free. Pro opens weeks 2 and 3.</p>
                <a href={appHome} target="_blank" rel="noopener" className="btn-read-gita btn-read-gita-primary" data-mp-location="home_app_section_download">
                  Download on the App Store
                </a>
              </div>
              <div className="offer rv">
                <h3>On Android or a computer</h3>
                <p>Write what&apos;s going on in your own words and get the same seven days here.</p>
                <p className="offer-price">
                  ₹{WEB_PLAN_PRICE_INR} a week. Your bank tells you before every charge, and you can cancel from your plan in
                  one tap.
                </p>
                <a href="#your-verse" className="btn-hero-secondary" data-mp-location="home_app_section_web_plan">Start my reading plan</a>
              </div>
            </div>
            <p className="seven-note rv">No streaks, no badges. If you miss a day, the plan waits.</p>
          </div>
          <div className="seven-art rv">
            <img src="/assets/app-v3/store-2.webp" alt="Wisdom's 7-day plans for overthinking, sleep, being far from home and guilt, each read aloud" loading="lazy" width={640} height={1391} />
          </div>
        </div>
      </section>

      {/* ── SOURCES (whose Gita is this?) ── */}
      <section className="section" data-mp-section="home_sources">
        <div className="wrap">
          <div className="sec-head rv">
            <div className="eyebrow">Where the meanings come from</div>
            <h2 className="heading">Whose Gita is this?</h2>
          </div>
          <div className="sources-grid" data-stagger="90">
            <div className="rv">
              <h3>The verse, as it is</h3>
              <p>
                Every verse is shown with its original Sanskrit, from the Ramayana and Mahabharata too. We never trim a line
                to make it sound like a quote.
              </p>
            </div>
            <div className="rv">
              <h3>Read through Shankara and Ramanuja</h3>
              <p>
                Meanings follow the traditional commentaries and modern acharyas, not one sampradaya&apos;s translation. You
                don&apos;t need a guru&apos;s permission to open it.
              </p>
            </div>
            <div className="rv">
              <h3>What the AI does</h3>
              <p>
                It reads what you tell it, picks verses from a library of 1,743, and writes the line about your life. It
                doesn&apos;t write or change scripture. Commentary on the site is AI-drafted and reviewed by a person.{' '}
                <a href="/methodology" data-mp-location="home_sources_methodology">Methodology →</a>
              </p>
            </div>
          </div>
          <figure className="sources-review rv">
            <blockquote>
              &ldquo;I&apos;m not a very religious or spiritual person myself, but the impact of the Shlokas at various
              points during a stressful day has had a very positive influence.&rdquo;
            </blockquote>
            <figcaption>AbhimanyuDasgupta, App Store review</figcaption>
          </figure>
        </div>
      </section>

      {/* ── GITA FOR LIFE (problem pages) ── */}
      <section className="section" id="gita-for" data-mp-section="home_gita_for">
        <div className="wrap">
          <div className="sec-head rv">
            <div className="eyebrow">Gita for life</div>
            <h2 className="heading">What Krishna said about overthinking, grief, failure <em>and anger.</em></h2>
            <p className="subtext">Each page gathers the verses on one problem, with Sanskrit, Hindi and English.</p>
          </div>
          <div className="gita-for-grid" data-stagger="30">
            {GITA_FOR.map((p) => (
              <a key={p.slug} href={`/gita-for/${p.slug}`} className="gita-for-tile rv" data-mp-location={`home_gita_for_${p.slug}`}>
                <span className="gita-for-label">{p.label}</span>
                <span className="gita-for-count">{p.verses.length} verses →</span>
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* ── TODAY'S VERSE ── */}
      {todayVerse && todayRef && (
        <section className="section section-alt" data-mp-section="today_verse_card">
          <div className="wrap">
            <div className="today-verse-card rv" style={{ margin: '0 auto' }}>
              <div className="today-verse-head">
                <div className="today-verse-eyebrow">
                  <span className="today-verse-dot" aria-hidden="true" />
                  Verse of the day
                </div>
                <div className="today-verse-ref">Bhagavad Gita {todayRef.chapter}.{todayRef.verse}</div>
              </div>
              {todayAudio && todayVerse.sanskrit ? (
                <VerseAudioPlayer
                  audioSrc={todayAudio.audio}
                  timestamps={todayAudio.timestamps}
                  text={todayVerse.sanskrit}
                  chapter={todayRef.chapter}
                  verse={todayRef.verse}
                />
              ) : (
                todayVerse.sanskrit && <p className="today-verse-sanskrit">{todayVerse.sanskrit}</p>
              )}
              <blockquote className="today-verse-meaning">
                &ldquo;{todayVerse.simpleMeaning || todayVerse.englishTranslation}&rdquo;
              </blockquote>
              {todayVerse.simpleInsight && <p className="today-verse-insight">{todayVerse.simpleInsight}</p>}
              <div className="today-verse-footer">
                <div className="today-verse-hint">
                  <span aria-hidden="true">▶</span> Press play and follow the Sanskrit word by word.
                </div>
              </div>
              <div className="today-actions">
                <a
                  href={`/gita/chapter/${todayRef.chapter}/verse/${todayRef.verse}`}
                  className="btn-read-gita btn-read-gita-primary"
                  data-mp-location="home_today_verse_go_deeper"
                  data-mp-event="Today Verse CTA Clicked"
                  data-mp-props={JSON.stringify({ verse: `${todayRef.chapter}.${todayRef.verse}` })}
                >
                  Read this verse in full →
                </a>
                <a href={appStoreUrl('web_home_today_lockscreen')} target="_blank" rel="noopener" className="btn-ghost" data-mp-location="home_today_lockscreen">
                  Put it on your Lock Screen
                </a>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* ── READ THE GITA (compact library) ── */}
      <section className="section" id="chapters">
        <div className="wrap">
          <div className="sec-head rv">
            <div className="eyebrow">Read the Bhagavad Gita online</div>
            <h2 className="heading">All 18 chapters, 700 verses. <em>Free, in Sanskrit, Hindi and English.</em></h2>
            <p className="subtext">
              One verse per page, with the shloka in Devanagari, Hindi anuvad, an English translation and commentary.
            </p>
          </div>
          <div className="chapters-grid" data-stagger="25">
            {chapters.map((ch) => {
              const img = chapterImage(ch.number)
              return (
                <a key={ch.number} href={`/gita/chapter/${ch.number}`} data-mp-location={`home_chapter_grid_${ch.number}`} className="chapter-tile rv">
                  <img className="chapter-tile-img" src={img.src} alt={img.alt} loading="lazy" />
                  <div className="chapter-tile-body">
                    <div className="chapter-tile-num">Chapter {ch.number} · {ch.totalVerses} verses</div>
                    <div className="chapter-tile-name">{ch.enName}</div>
                    <div className="chapter-tile-title">{ch.enTitle}</div>
                  </div>
                </a>
              )
            })}
          </div>

          <div className="library-row rv">
            <span className="library-label">Most searched</span>
            {ICONIC_VERSES.map((v) => (
              <a key={v.ref} href={`/gita/chapter/${v.chapter}/verse/${v.verse}`} data-mp-location={`home_iconic_${v.ref.replace('.', '_')}`}>
                BG {v.ref}: {v.label}
              </a>
            ))}
          </div>

          <div className="hindi-callout rv">
            <div>
              <div className="eyebrow" style={{ marginBottom: 6 }}>हिंदी में</div>
              <p className="hindi-callout-head">भगवद् गीता के 700 श्लोक हिंदी में, अर्थ सहित।</p>
              <p className="hindi-callout-sub">संस्कृत श्लोक, हिंदी अनुवाद और विस्तृत अर्थ। सभी 18 अध्याय, निःशुल्क।</p>
            </div>
            <a href="/hi/gita" hrefLang="hi" className="btn-nav" data-mp-location="home_hindi_callout">हिंदी गीता खोलें →</a>
          </div>

          <div className="blog-row" data-stagger="80">
            {BLOGS.map((b) => (
              <a key={b.slug} href={`/blogs/${b.slug}`} className="blog-row-card rv" data-mp-location={`home_blog_${b.slug}`}>
                <h3>{b.title}</h3>
                <p>{b.dek}</p>
                <span>Read →</span>
              </a>
            ))}
          </div>
          <div className="t-center" style={{ marginTop: 24 }}>
            <a href="/gita" className="btn-ghost" data-mp-location="home_chapters_all">Open the full Gita index →</a>
          </div>
        </div>
      </section>

      {/* ── FAQ ── */}
      <section className="section section-alt" id="faq">
        <div className="wrap faq-split">
          <div className="sec-head rv">
            <div className="eyebrow">FAQ</div>
            <h2 className="heading">Before you start</h2>
          </div>
          <div className="faq-list rv" role="list">
            {FAQ.map((f) => (
              <div key={f.q} className="faq-item" role="listitem">
                <button className="faq-q" aria-expanded="false">
                  {f.q}
                  <svg className="faq-chevron" width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true">
                    <path d="M5 7.5l5 5 5-5" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </button>
                <div className="faq-a">{f.a}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── FINAL CTA ── */}
      <section className="final-band-wrap">
        <div className="final-band rv">
          <img src="/assets/chapter2.webp" alt="" aria-hidden="true" loading="lazy" className="final-band-art" />
          <div className="final-band-scrim" aria-hidden="true" />
          <div className="final-band-inner">
          <h2>Start with <em>Day 1, free.</em></h2>
          <p>Tell us what&apos;s on your mind. Your first verse is ready in about 30 seconds.</p>
          <div style={{ display: 'flex', gap: '14px', justifyContent: 'center', flexWrap: 'wrap' }}>
            <a href="#your-verse" className="btn-read-gita btn-read-gita-primary" data-mp-location="final_cta_find_verse">Start my reading plan</a>
          </div>
          </div>
        </div>
      </section>

      {/* ── FOOTER ── */}
      <footer>
        <div className="footer-inner">
          <div className="footer-logo" style={{ display: 'flex', alignItems: 'center', gap: '9px' }}>
            <img src="/assets/new-light-logo.webp" alt="Wisdom" loading="lazy" style={{ width: '30px', height: '30px', borderRadius: '50%', objectFit: 'cover', border: '1px solid rgba(200, 136, 30, 0.35)' }} />
            Wisdom
          </div>
          <p className="footer-copy">© 2026 Wisdom · Ankur Shukla · Bhagavad Gita, tuned to your life.</p>
          <p className="footer-crisis">In crisis? Call Tele-MANAS on 14416 (India, free, 24×7) or your local emergency number.</p>
          <p style={{ fontSize: '11px', color: 'var(--text-dimmer)', marginTop: '4px' }}>
            Wisdom editorial translations. Commentary AI-drafted, human-reviewed. <a href="/methodology" style={{ color: 'var(--text-dimmer)' }}>Methodology →</a>
          </p>
          <div style={{ display: 'flex', alignItems: 'center', gap: '20px', flexWrap: 'wrap' }}>
            <a href="https://x.com/sansearchapp" target="_blank" rel="noopener noreferrer" aria-label="Wisdom on X (Twitter)" style={{ color: 'var(--text-dimmer)', fontSize: '13px' }} data-mp-location="footer_twitter">𝕏</a>
            <a href="https://www.instagram.com/wisdomquoteapp/" target="_blank" rel="noopener noreferrer" aria-label="Wisdom on Instagram" style={{ color: 'var(--text-dimmer)', fontSize: '13px' }} data-mp-location="footer_instagram">Instagram</a>
            <ul className="footer-links">
              <li><a href="/gita">Read the Gita</a></li>
              <li><a href="/hi/gita" hrefLang="hi">हिंदी गीता</a></li>
              <li><a href="/gita-for">Gita for life</a></li>
              <li><a href="/app">iPhone app</a></li>
              <li><a href="/blogs">Blog</a></li>
              <li><a href="/privacy">Privacy</a></li>
              <li><a href="/terms">Terms</a></li>
              <li><a href="mailto:work.ankurshukla@gmail.com">Support</a></li>
            </ul>
          </div>
        </div>
      </footer>

      <BlogTracker pageName="Home" />
      <HomeAnimations />
    </>
  )
}
